package com.iplay.fmx33d;

// $VF: renamed from: a
public final class class_0 {
   private class_21[] a;
   private class_21[] b;
   // $VF: renamed from: a byte[]
   private byte[] field_0;
   // $VF: renamed from: b int[]
   private int[] field_1;
   private int[] c;
   private int[] d;
   // $VF: renamed from: a v
   private class_21 field_2 = new class_21();
   // $VF: renamed from: b int
   private int field_3;
   // $VF: renamed from: a int
   public int field_4;
   // $VF: renamed from: a int[]
   public int[] field_5;

   public class_0() {
      this.a = new class_21[256];
      this.b = new class_21[256];

      for (int var1 = 0; var1 < 256; var1++) {
         this.a[var1] = new class_21();
         this.b[var1] = new class_21();
      }

      this.field_1 = new int[256];
      this.c = new int[256];
      this.field_0 = new byte[256];
      this.d = new int[256];
      this.field_5 = class_5.method_10(321);
      this.a();
   }

   public final void a() {
      int[] var1 = this.c;

      for (int var2 = 0; var2 < 256; var2++) {
         var1[var2] = -1;
      }
   }

   public final void a(int var1, int var2, int var3, int var4, int var5, int var6, int var7) {
      int var8 = var1 * 12;
      int var9 = this.field_5[1 + var8];

      for (int var10 = 0; var10 < var9; var10++) {
         int var11 = this.field_3++;
         if (this.field_3 >= 256) {
            this.field_3 = 0;
         }

         class_21 var12 = this.a[var11];
         class_21 var13 = this.b[var11];
         this.field_0[var11] = (byte)var1;
         this.field_1[var11] = this.field_5[3 + var8];
         this.c[var11] = this.field_5[4 + var8];
         int var14 = this.field_5[8 + var8];
         int var15 = this.field_5[9 + var8];
         this.d[var11] = class_18.method_110(var14, var15);
         int var16 = this.field_5[10 + var8];
         int var17 = this.field_5[11 + var8];
         int var18 = class_18.method_110(var16, var17);
         if (var9 > 1) {
            int var19;
            int var20 = class_18.d(var19 = 1024 / var9 * var10);
            int var21 = class_18.e(var19);
            var5 += var21 * var18 >> 10;
            var7 += var20 * var18 >> 10;
         }

         var12.a(var2, var3, var4);
         var13.a(var2 - var5, var3 - var6, var4 - var7);
      }
   }

   public final void b() {
      this.field_4 = 0;
      int[] var1 = this.c;

      for (int var2 = 0; var2 < 256; var2++) {
         if (var1[var2] > 0) {
            var1[var2]--;
            class_21 var3 = this.a[var2];
            class_21 var4 = this.b[var2];
            this.field_2.a(var3, var4);
            this.field_2.a(this.d[var2]);
            class_21 var10000 = this.field_2;
            var10000.field_279 = var10000.field_279 + this.field_1[var2];
            var4.a(var3);
            var3.b(this.field_2);
            this.field_4++;
         }
      }
   }

   public final void a(class_8 var1) {
      int[] var2 = this.c;

      for (int var3 = 0; var3 < 256; var3++) {
         int var4;
         if ((var4 = var2[var3]) > 0) {
            byte var5 = this.field_0[var3];
            int var6 = 12 * var5;
            int var7 = this.field_5[0 + var6];
            int var8 = this.field_5[4 + var6];
            int var9 = this.field_5[2 + var6];
            int var10 = this.field_5[5 + var6];
            int var11 = this.field_5[6 + var6];
            int var12 = this.field_5[7 + var6];
            int var13 = var11 >= 0 ? Math.min(var9, var10 + var11 * (var8 - var4)) : Math.max(var10, var9 + var11 * (var8 - var4));
            int var14 = 255;
            if (var12 != 0) {
               var14 = var4 * var12;
            }

            class_21 var15 = this.a[var3];
            var1.a(var7, var15.field_278, var15.field_279, var15.field_280, var13, var14, true);
         }
      }
   }
}
