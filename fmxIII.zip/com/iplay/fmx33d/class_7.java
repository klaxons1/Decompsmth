package com.iplay.fmx33d;

import javax.microedition.lcdui.Graphics;
import javax.microedition.midlet.MIDlet;

// $VF: renamed from: g
public final class class_7 {
   private static final int[] a = new int[4];

   public static final boolean a(MIDlet var0, String var1) throws Exception {
      return var0.platformRequest(var1);
   }

   public static final void a(Graphics var0, int[] var1, int var2, int var3, int var4, int var5, int var6, boolean var7, int var8) {
      if ((var8 & 8) != 0) {
         var2 -= var4;
      }

      if ((var8 & 32) != 0) {
         var3 -= var5;
      }

      if ((var8 & 1) != 0) {
         var2 -= var4 >> 1;
      }

      if ((var8 & 2) != 0) {
         var3 -= var5 >> 1;
      }

      int var9 = var0.getTranslateX();
      int var10 = var0.getTranslateY();
      var0.translate(-var9, -var10);
      var2 += var9;
      var3 += var10;
      int[] var11;
      class_5.a(var11 = a, var0.getClipX(), var0.getClipY(), var0.getClipWidth(), var0.getClipHeight());
      class_5.b(var11, var2, var3, var4, var5);
      if (!class_5.a(var11)) {
         int var12 = var11[0];
         int var13 = var11[1];
         var4 = var11[2] - var12;
         var5 = var11[3] - var13;
         int var14 = var12 - var2 + (var13 - var3) * var6;

         try {
            var0.drawRGB(var1, var14, var6, var12, var13, var4, var5, var7);
         } catch (Exception var16) {
         }
      }

      var0.translate(var9, var10);
   }
}
