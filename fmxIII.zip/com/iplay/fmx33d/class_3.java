package com.iplay.fmx33d;

import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;

// $VF: renamed from: r
public class class_3 extends MIDlet {
   public static final int MBOOSTER_MAX_INSTANCES = 0;
   public static class_3 a;

   public void startApp() throws MIDletStateChangeException {
      if (a == null) {
         a = this;
         class_18.a(this);
         a();
      }

      class_15.a(this);
   }

   public static final void a() {
      class_15.i();
      class_15.method_64();
   }

   public void pauseApp() {
      class_18.method_132();
      class_15.j();
   }

   public void destroyApp(boolean var1) throws MIDletStateChangeException {
      class_15.j();
      class_15.method_67();
   }
}
