package com.iplay.fmx33d;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import javax.microedition.lcdui.Font;
import javax.microedition.lcdui.Image;
import javax.microedition.rms.RecordEnumeration;
import javax.microedition.rms.RecordStore;
import javax.microedition.rms.RecordStoreFullException;
import javax.microedition.rms.RecordStoreNotFoundException;

// $VF: renamed from: e
public final class class_5 {
   public static final int MBOOSTER_MAX_INSTANCES = 0;
   private static short[] a;
   private static short[] b;
   // $VF: renamed from: a byte[]
   private static byte[] field_49;
   // $VF: renamed from: a java.lang.Object[]
   private static Object[] field_50;
   // $VF: renamed from: b int
   private static int field_51;
   private static int c;
   private static int d;
   // $VF: renamed from: a java.lang.String[]
   private static String[] field_52;
   // $VF: renamed from: a java.lang.String
   public static String field_53;
   // $VF: renamed from: a int
   public static int field_54;
   // $VF: renamed from: b java.lang.String[]
   private static String[] field_55;
   // $VF: renamed from: c java.lang.String[]
   private static String[] field_56;
   // $VF: renamed from: d java.lang.String[]
   private static String[] field_57;
   private static int e;
   // $VF: renamed from: e java.lang.String[]
   private static String[] field_58;
   private static int f;
   // $VF: renamed from: f java.lang.String[]
   private static String[] field_59;
   // $VF: renamed from: a byte[][]
   private static byte[][] field_60;
   private static int g;
   private static int h;
   // $VF: renamed from: a int[]
   private static final int[] field_61 = new int[4];

   // $VF: renamed from: a () int
   public static int method_3() {
      return c;
   }

   // $VF: renamed from: b () int
   public static int method_4() {
      return d;
   }

   public static final String a(int var0) {
      if (field_55 == null) {
         return null;
      }

      if (var0 == -1) {
         return null;
      }

      if (var0 < 0) {
         var0 &= 255;
      }

      return field_55[var0];
   }

   public static final String b(int var0) {
      return var0 == -1 ? null : field_57[var0];
   }

   public static final int c() {
      return field_55.length;
   }

   public static final String c(int var0) {
      if (var0 < 0) {
         var0 &= 255;
      }

      return var0 < 44 ? field_56[var0] : field_55[var0];
   }

   public static final void a(String var0, int var1, int var2, Font var3) {
      if (field_58 == null) {
         field_58 = new String[24];
      }

      String[] var10000;
      int var10001;
      String var10002;
      if (class_18.a(var0, var3) <= var2) {
         var10000 = field_58;
         var10001 = var1;
         var10002 = var0;
      } else {
         int var5 = var2 - class_18.a('.', var3) * 3;
         int var6 = var0.length();
         int var7 = 0;

         while (var7 < var6 && class_18.a(var0, 0, var7, var3) < var5) {
            var7++;
         }

         var10000 = field_58;
         var10001 = var1;
         var10002 = var0.substring(0, var7 - 1) + "...";
      }

      var10000[var10001] = var10002;
   }

   public static final String d(int var0) {
      return field_58[var0];
   }

   private static int a(StringBuffer var0, String[] var1) {
      int var2 = 0;
      int var3 = var1.length;

      for (int var4 = 0; var4 < var0.length() - 1 && var2 < var3; var4++) {
         if (var0.charAt(var4) == '%' && Character.isDigit(var0.charAt(var4 + 1))) {
            int var5 = var0.charAt(var4 + 1) - '0' - 1;
            var0.deleteCharAt(var4);
            var0.deleteCharAt(var4);
            if (var1[var5] != null) {
               var0.insert(var4, var1[var5]);
            }

            var2++;
         }
      }

      return var2;
   }

   public static final void a(int var0, String var1) {
      a(var0, new String[]{var1});
   }

   public static final void a(int var0, String var1, String var2) {
      a(var0, new String[]{var1, var2});
   }

   public static final void a(int var0, String[] var1) {
      StringBuffer var2;
      a(var2 = new StringBuffer(field_56[var0]), var1);
      b(var0, var2.toString());
   }

   public static final void b(int var0, String var1) {
      field_55[var0] = var1;
   }

   // $VF: renamed from: a (int) void
   public static final void method_5(int var0) {
      e = 0;
      field_57 = var0 > 0 ? new String[var0] : null;
   }

   public static final int a(String var0) {
      if (var0 != null && var0.length() != 0) {
         field_57[e] = var0;
         return e++;
      } else {
         return -1;
      }
   }

   // $VF: renamed from: b (int) void
   public static void method_13(int var0) {
      method_23(field_52[var0]);
   }

   // $VF: renamed from: a (java.lang.String) void
   public static void method_23(String var0) {
      if (field_53 == null || !field_53.equals(var0)) {
         field_55 = null;
         field_56 = null;
         DataInputStream var1 = method_24("/res/text.lng");

         try {
            var1.readShort();
            var1.readByte();
            int var2 = var1.readUnsignedByte();
            short var3 = var1.readShort();
            boolean var4 = false;
            int var5 = 0;

            for (int var6 = 0; var6 < var2; var6++) {
               var1.readByte();
               var1.readByte();
               if (!var0.equals(field_52[var6]) && var2 != 1) {
                  var1.read();
                  var1.read();
               } else {
                  var4 = true;
                  field_54 = var6;
                  var5 = var1.readShort() & '\uffff';
               }
            }

            if (var4) {
               if (field_55 == null) {
                  field_55 = new String[var3];
               }

               field_53 = var0;
               var1.skipBytes(var5);

               for (int var12 = 0; var12 < var3; var12++) {
                  field_55[var12] = var1.readUTF();
               }
            }
         } catch (Exception var10) {
         } finally {
            a((InputStream)var1);
         }

         field_56 = new String[44];
         System.arraycopy(field_55, 0, field_56, 0, 44);
      }
   }

   public static final String e(int var0) {
      int var1 = class_18.g(var0);
      int var2 = class_18.h(var0);
      int var3 = class_18.i(var0);
      String var4 = var1 < 10 ? '0' + String.valueOf(var1) : String.valueOf(var1);
      String var5 = var2 < 10 ? '0' + String.valueOf(var2) : String.valueOf(var2);
      String var6 = var3 < 10 ? '0' + String.valueOf(var3) : String.valueOf(var3);
      a(42, new String[]{var4, var5, var6});
      return a(42);
   }

   // $VF: renamed from: a (int) javax.microedition.lcdui.Image
   public static final Image method_6(int var0) {
      return (Image)method_12(var0);
   }

   private static final Image a(byte[] var0) {
      Object var1 = null;
      return Image.createImage(var0, 0, var0.length);
   }

   // $VF: renamed from: a (int) int
   public static final int method_7(int var0) {
      return field_49[var0] & 63;
   }

   // $VF: renamed from: a (int) byte[]
   public static final byte[] method_8(int var0) {
      return (byte[])method_12(var0);
   }

   // $VF: renamed from: b (int) byte[]
   private static byte[] method_14(int var0) {
      return (byte[])method_12(var0);
   }

   // $VF: renamed from: a (int) short[]
   public static final short[] method_9(int var0) {
      return (short[])method_12(var0);
   }

   // $VF: renamed from: a (int) int[]
   public static final int[] method_10(int var0) {
      return (int[])method_12(var0);
   }

   // $VF: renamed from: a (int) boolean
   public static final boolean method_11(int var0) {
      return var0 >= 0 && field_50 != null && field_50[var0] != null;
   }

   // $VF: renamed from: a (int) java.lang.Object
   private static final Object method_12(int var0) {
      Object var1;
      if ((var1 = field_50[var0]) == null && (field_49[var0] & 128) != 0) {
         a(method_22(var0, ".bin"), var0);
         var1 = field_50[var0];
      }

      return var1;
   }

   // $VF: renamed from: a (int, java.lang.String) java.lang.String
   public static final String method_22(int var0, String var1) {
      return (field_49[var0] & 128) != 0 ? "/res/r" + var0 + var1 : null;
   }

   // $VF: renamed from: c (int) void
   public static final void method_19(int var0) {
      field_50[var0] = null;
      System.gc();
   }

   // $VF: renamed from: b (int) int
   public static final int method_15(int var0) {
      return a[var0] & 65535;
   }

   // $VF: renamed from: c (int) int
   public static final int method_20(int var0) {
      return b[var0] & 65535;
   }

   public static final void a() {
      DataInputStream var0 = method_24("/res/res.bin");

      try {
         c = var0.readShort();
         field_51 = c + 16;
         field_49 = new byte[field_51];
         a = new short[field_51];
         b = new short[field_51];
         field_50 = new Object[field_51];
         class_15.f(c);
         d = 0;

         for (int var1 = 0; var1 < c; var1++) {
            byte var2 = var0.readByte();
            a(var0, d, var2);
            d++;
            class_15.g(d);
         }
      } catch (OutOfMemoryError var7) {
      } catch (Exception var8) {
      } finally {
         a((InputStream)var0);
      }

      System.gc();
      class_15.method_106();
   }

   private static final void a(String var0, int var1) {
      DataInputStream var2 = method_24(var0);

      try {
         byte var3 = var2.readByte();
         a(var2, var1, var3);
         return;
      } catch (Exception var7) {
      } finally {
         a((InputStream)var2);
      }
   }

   // $VF: renamed from: d (int) void
   public static final void method_21(int var0) {
      method_12(var0);
   }

   private static final void a(DataInputStream var0, int var1, byte var2) throws IOException {
      int var3 = 0;
      int var4 = 0;
      Image var6 = null;
      if ((var2 & 64) != 0) {
         field_49[var1] = var2;
      } else {
         if ((var2 & 128) == 0) {
            if (var2 == 1) {
               byte[] var5 = new byte[var0.readUnsignedShort()];
               a(var0, var5);
               var3 = (var6 = a(var5)).getWidth();
               var4 = var6.getHeight();
               field_50[var1] = var6;
            }

            if (var2 == 2 || var2 == 9) {
               var3 = var0.readUnsignedShort();
               var4 = var0.readUnsignedShort();
               byte[] var17 = new byte[var3 * var4];
               a(var0, var17);
               field_50[var1] = var17;
            }

            if (var2 == 3) {
               var3 = var0.readUnsignedShort();
               var4 = var0.readUnsignedShort();
               int var7;
               short[] var8 = new short[var7 = var3 * var4];
               a(var0, var8);
               field_50[var1] = var8;
            }

            if (var2 == 4) {
               var3 = var0.readUnsignedShort();
               var4 = var0.readUnsignedShort();
               int var19;
               int[] var20 = new int[var19 = var3 * var4];
               a(var0, var20);
               field_50[var1] = var20;
            }

            if (var2 == 7) {
               int var21;
               byte[][] var9 = new byte[var21 = var0.readUnsignedByte()][4];

               for (int var10 = 0; var10 < var21; var10++) {
                  a(var0, var9[var10]);
               }

               class_18.field_238 = var9;
               byte[] var24 = new byte[var0.readUnsignedByte()];
               a(var0, var24);
               class_15.field_173 = var24;
               byte[][] var11 = new byte[var21 = var0.readUnsignedByte()][2];

               for (int var12 = 0; var12 < var21; var12++) {
                  a(var0, var11[var12]);
               }

               class_15.field_174 = var11;
               byte var23;
               byte[][] var25 = new byte[var23 = var0.readByte()][6];

               for (int var13 = 0; var13 < var23; var13++) {
                  a(var0, var25[var13]);
               }

               class_15.field_171 = var25;
               byte[][][] var26 = new byte[var23][][];

               for (int var14 = 0; var14 < var23; var14++) {
                  byte var15 = var0.readByte();
                  var26[var14] = new byte[var15][7];

                  for (int var16 = 0; var16 < var15; var16++) {
                     a(var0, var26[var14][var16]);
                  }
               }

               class_15.field_172 = var26;
            }
         }

         if (field_49[var1] == 0) {
            field_49[var1] = var2;
         }

         a[var1] = (short)var3;
         b[var1] = (short)var4;
      }
   }

   public static final int a(byte[] var0, int var1) {
      byte var2 = var0[var1];
      int var3 = var0[var1 + 1] & 255;
      return var2 << 8 | var3;
   }

   public static final int a(DataInputStream var0, byte[] var1) throws IOException {
      return a(var0, var1, 0, var1.length);
   }

   private static int a(DataInputStream var0, byte[] var1, int var2, int var3) throws IOException {
      boolean var4 = false;

      int var5;
      while ((var5 = var0.read(var1, var2, var3 - var2)) != -1 && (var2 += var5) < var3) {
      }

      return var2;
   }

   private static void a(DataInputStream var0, int[] var1) throws IOException {
      int var2 = var1.length;

      for (int var3 = 0; var3 < var2; var3++) {
         var1[var3] = var0.readInt();
      }
   }

   private static void a(DataInputStream var0, short[] var1) throws IOException {
      int var2 = var1.length;

      for (int var3 = 0; var3 < var2; var3++) {
         var1[var3] = var0.readShort();
      }
   }

   // $VF: renamed from: a (java.lang.String) java.io.DataInputStream
   private static DataInputStream method_24(String var0) {
      InputStream var1 = class_3.a.getClass().getResourceAsStream(var0);
      return new DataInputStream(var1);
   }

   public static final int a(int var0, int var1, int var2) {
      switch (method_7(var0)) {
         case 2:
            return method_8(var0)[var1 * method_15(var0) + var2];
         case 3:
            return method_9(var0)[var1 * method_15(var0) + var2];
         case 4:
            return method_10(var0)[var1 * method_15(var0) + var2];
         case 5:
         case 6:
         case 7:
         case 8:
         default:
            return 0;
         case 9:
            return method_14(var0)[var1 * method_15(var0) + var2] & 0xFF;
      }
   }

   public static final int a(int var0, int var1) {
      switch (method_7(var0)) {
         case 2:
            return method_8(var0)[var1];
         case 3:
            return method_9(var0)[var1];
         case 4:
            return method_10(var0)[var1];
         case 5:
         case 6:
         case 7:
         case 8:
         default:
            return 0;
         case 9:
            return method_14(var0)[var1] & 0xFF;
      }
   }

   public static final int b(int var0, int var1, int var2) {
      int var3 = method_20(var0);

      for (int var4 = 0; var4 < var3; var4++) {
         if (var2 == a(var0, var4, var1)) {
            return var4;
         }
      }

      return -1;
   }

   // $VF: renamed from: a (byte[]) java.io.DataInputStream
   public static final DataInputStream method_27(byte[] var0) {
      ByteArrayInputStream var1 = new ByteArrayInputStream(var0);
      return new DataInputStream((InputStream)var1);
   }

   public static final void a(InputStream var0) {
      try {
         var0.close();
      } catch (Exception var2) {
      }
   }

   public static final void a(OutputStream var0) {
      try {
         var0.close();
      } catch (Exception var2) {
      }
   }

   public static final void a(String[] var0) {
      field_59 = var0;
      field_60 = new byte[field_59.length][];
   }

   // $VF: renamed from: e (int) void
   public static final void method_26(int var0) {
      h |= 1 << var0;
   }

   public static final int d() {
      int var0 = f;
      f = 0;
      return var0;
   }

   public static final byte[] a(int var0, boolean var1) {
      int var2 = 1 << var0;
      if ((g & var2) == 0) {
         field_60[var0] = method_25(field_59[var0]);
         if (f == 0) {
            g |= var2;
         }
      }

      if (var1) {
         method_26(var0);
      }

      return field_60[var0];
   }

   // $VF: renamed from: b (int) int[]
   public static final int[] method_16(int var0) {
      int[] var1 = null;
      byte[] var2 = a(var0, false);
      if (f == 0) {
         DataInputStream var3 = method_27(var2);
         var1 = new int[var2.length >> 2];

         try {
            a(var3, var1);
         } catch (Exception var9) {
         } finally {
            a((InputStream)var3);
         }

         field_60[var0] = null;
      }

      return var1;
   }

   public static final void a(int var0, byte[] var1) {
      int var2 = 1 << var0;
      boolean var3 = false;
      if (field_60[var0] == null && var1 != null) {
         var3 = true;
      }

      if (field_60[var0] != null && var1 == null) {
         var3 = true;
      }

      if (field_60[var0] != null && var1 != null && field_60[var0].length != var1.length) {
         var3 = true;
      }

      if (!var3 && field_60[var0] != null && var1 != null && field_60[var0].length == var1.length) {
         int var4 = var1.length;

         for (int var5 = 0; var5 < var4; var5++) {
            if (field_60[var0][var5] != var1[var5]) {
               var3 = true;
               break;
            }
         }
      }

      field_60[var0] = var1;
      if (var3) {
         h |= var2;
      }

      g |= var2;
   }

   public static final void a(int var0, int[] var1) {
      a(var0, method_28(var1));
   }

   // $VF: renamed from: a (int[]) byte[]
   private static byte[] method_28(int[] var0) {
      int var1 = var0.length;
      ByteArrayOutputStream var2 = new ByteArrayOutputStream(var1 << 2);
      DataOutputStream var3 = new DataOutputStream((OutputStream)var2);

      try {
         for (int var4 = 0; var4 < var1; var4++) {
            var3.writeInt(var0[var4]);
         }
      } catch (Exception var8) {
      } finally {
         a((OutputStream)var3);
      }

      return var2.toByteArray();
   }

   public static final void f(int var0) {
      if (method_17(var0)) {
         a(field_59[var0], field_60[var0]);
         if (f == 0) {
            h &= ~(1 << var0);
         }
      }
   }

   // $VF: renamed from: b (int) boolean
   private static boolean method_17(int var0) {
      int var1 = 1 << var0;
      return (h & g & var1) != 0;
   }

   private static final void a(String var0, byte[] var1) {
      f = 0;
      RecordStore var2 = null;
      if (var1 != null) {
         try {
            if (false) {
               throw (RecordStoreFullException)null;
            }

            if ((var2 = RecordStore.openRecordStore(var0, true)).getNumRecords() == 0) {
               var2.addRecord(var1, 0, var1.length);
            } else {
               RecordEnumeration var3;
               int var4 = (var3 = var2.enumerateRecords(null, null, false)).nextRecordId();
               var3.destroy();
               var2.setRecord(var4, var1, 0, var1.length);
            }

            return;
         } catch (RecordStoreFullException var15) {
            f = 2;
            return;
         } catch (Exception var16) {
            f = 3;
         } finally {
            if (var2 != null) {
               try {
                  var2.closeRecordStore();
               } catch (Exception var14) {
               }
            }
         }
      }
   }

   // $VF: renamed from: a (java.lang.String) byte[]
   private static final byte[] method_25(String var0) {
      f = 0;
      byte[] var1 = null;
      RecordStore var2 = null;

      try {
         if (false) {
            throw (RecordStoreNotFoundException)null;
         }

         if (false) {
            throw (RecordStoreFullException)null;
         }

         if ((var2 = RecordStore.openRecordStore(var0, false)).getNumRecords() == 0) {
            f = 1;
         } else {
            var1 = var2.getRecord(1);
         }
      } catch (RecordStoreNotFoundException var16) {
         f = 1;
      } catch (RecordStoreFullException var17) {
         f = 2;
      } catch (Exception var18) {
         f = 3;
      } finally {
         if (var2 != null) {
            try {
               var2.closeRecordStore();
            } catch (Exception var15) {
            }
         }
      }

      return var1;
   }

   private static final void b(String var0) {
      if (var0 != null) {
         try {
            RecordStore.deleteRecordStore(var0);
            return;
         } catch (Exception var2) {
         }
      }
   }

   public static final void b() {
      int var0 = field_59.length;

      for (int var1 = 0; var1 < var0; var1++) {
         f(var1);
      }
   }

   public static final void g(int var0) {
      b(field_59[var0]);
      field_60[var0] = null;
      int var1 = 1 << var0;
      h &= ~var1;
      g &= ~var1;
   }

   // $VF: renamed from: c () void
   public static final void method_18() {
      int var0 = field_59.length;

      for (int var1 = 0; var1 < var0; var1++) {
         g(var1);
      }
   }

   public static final void a(int[] var0, int var1, int var2, int var3, int var4) {
      var0[0] = var1;
      var0[2] = var1 + var3;
      var0[1] = var2;
      var0[3] = var2 + var4;
   }

   public static final void a(int[] var0, int[] var1) {
      System.arraycopy(var1, 0, var0, 0, 4);
   }

   public static final void b(int[] var0, int var1, int var2, int var3, int var4) {
      a(field_61, var1, var2, var3, var4);
      c(var0, field_61);
   }

   private static void c(int[] var0, int[] var1) {
      if (var0[0] < var1[0]) {
         var0[0] = var1[0];
      }

      if (var0[1] < var1[1]) {
         var0[1] = var1[1];
      }

      if (var0[2] > var1[2]) {
         var0[2] = var1[2];
      }

      if (var0[3] > var1[3]) {
         var0[3] = var1[3];
      }
   }

   public static final void b(int[] var0, int[] var1) {
      if (var0[0] > var1[0]) {
         var0[0] = var1[0];
      }

      if (var0[1] > var1[1]) {
         var0[1] = var1[1];
      }

      if (var0[2] < var1[2]) {
         var0[2] = var1[2];
      }

      if (var0[3] < var1[3]) {
         var0[3] = var1[3];
      }
   }

   public static final boolean a(int[] var0) {
      return var0[2] <= var0[0] || var0[3] <= var0[1];
   }

   // $VF: widened method access to satisfy Java override rules
   static {
      field_52 = new String[]{"EN", "FR", "IT", "DE", "ES"};
   }
}
