package com.iplay.fmx33d;

// $VF: renamed from: c
public final class class_2 {
   private class_21 d;
   public class_21 a;
   // $VF: renamed from: a u
   public class_20 field_35;
   public class_21 b;
   public class_21 c;
   // $VF: renamed from: a v[]
   public class_21[] field_36;
   // $VF: renamed from: b v[]
   public class_21[] field_37;
   // $VF: renamed from: a int[]
   private int[] field_38;
   // $VF: renamed from: a byte[]
   public byte[] field_39;
   // $VF: renamed from: c int
   private int field_40;
   private static final class_21 e = new class_21();
   // $VF: renamed from: a int
   public static int field_41;
   // $VF: renamed from: b int
   public static int field_42;

   public class_2(int var1) {
      this.field_40 = var1;
      this.a = new class_21();
      this.d = new class_21();
      this.field_35 = new class_20();
      this.b = new class_21();
      this.c = new class_21();
      this.field_39 = new byte[8];
      this.a(class_21.a, class_20.field_275, class_21.a, class_20.field_275);
      this.c();
   }

   public final void a(class_21 var1, class_20 var2, class_21 var3, class_20 var4) {
      if (this.field_36 == null) {
         this.field_36 = new class_21[8];
         this.field_37 = new class_21[8];

         for (int var5 = 0; var5 < 8; var5++) {
            this.field_36[var5] = new class_21();
            this.field_37[var5] = new class_21();
         }
      }

      int[] var9 = class_5.method_10(this.field_40);
      class_21 var6 = class_21.g;
      int var7 = 0;

      for (int var8 = 0; var8 < 8; var8++) {
         var6.a(var9, var7);
         var7 += 3;
         var4.a(var6);
         var6.b(var3);
         this.field_37[var8].a(var6);
      }

      var7 = 0;

      for (int var11 = 0; var11 < 8; var11++) {
         var6.a(var9, var7);
         var7 += 3;
         var2.a(var6);
         var6.b(var1);
         this.field_36[var11].a(var6);
      }

      this.b();
   }

   private void b() {
      this.field_35.a(this.field_36[6], this.field_36[7], this.field_36[4], this.field_36[0]);
      this.field_35.a.c(2);
      this.field_35.b.c(2);
      this.field_35.c.c(2);
      this.field_35.b();
      this.d.a(this.field_37[4]);
      this.d.b(this.field_37[2]);
      this.d.b(this.field_37[5]);
      this.d.b(this.field_37[3]);
      this.d.c(2);
      this.a.a(this.field_36[4]);
      this.a.b(this.field_36[2]);
      this.a.b(this.field_36[5]);
      this.a.b(this.field_36[3]);
      this.a.c(2);
      this.b.a(this.field_36[6]);
      this.b.b(this.field_36[0]);
      this.b.c(1);
      this.c.a(this.field_36[7]);
      this.c.b(this.field_36[1]);
      this.c.c(1);
   }

   public final void a() {
      this.d();
      this.e();
      this.e();
      this.b();
   }

   private void c() {
      if (this.field_38 == null) {
         this.field_38 = new int[28];
      }

      class_21 var1 = class_21.g;
      int var2 = 0;

      for (int var3 = 0; var3 < 7; var3++) {
         for (int var4 = var3 + 1; var4 < 8; var4++) {
            var1.a(this.field_36[var3], this.field_36[var4]);
            int var5 = var1.b();
            this.field_38[var2++] = var5;
         }
      }
   }

   private void d() {
      class_21 var1 = class_21.g;
      class_21 var2 = class_21.h;

      for (int var3 = 0; var3 < 8; var3++) {
         class_21 var4 = this.field_36[var3];
         class_21 var5 = this.field_37[var3];
         var1.a(var4);
         var2.a(var4, var5);
         var2.field_279 -= 256;
         var4.b(var2);
         if (var4.field_278 < field_41) {
            var4.field_278 = field_41;
         }

         if (var4.field_278 > field_42) {
            var4.field_278 = field_42;
         }

         this.field_37[var3].a(var1);
      }
   }

   private final void a(int var1, int var2) {
      this.field_39[var1] = (byte)var2;
   }

   private final void b(int var1, int var2) {
      if ((class_19.a & 1) == 0) {
         this.a(var1, var2);
      }
   }

   private void e() {
      class_8 var1 = class_19.a();

      for (int var2 = 0; var2 < 8; var2++) {
         class_21 var3 = this.field_36[var2];
         class_21 var4 = this.field_37[var2];
         int var5;
         if ((var5 = var1.a(var3, var4, e, 256, 512)) < 0 && var5 < -64) {
            this.b(var2, 1);
         }
      }

      class_21 var13 = class_21.g;
      int var14 = 0;

      for (int var15 = 0; var15 < 7; var15++) {
         for (int var16 = var15 + 1; var16 < 8; var16++) {
            class_21 var6 = this.field_36[var15];
            class_21 var7 = this.field_36[var16];
            var13.a(var7, var6);
            long var8 = this.field_38[var14++];
            long var10 = var13.b();
            int var12 = (int)((var8 << 10) / (var10 + var8)) - 512;
            var13.a(var12);
            var6.c(var13);
            var7.b(var13);
         }
      }
   }
}
