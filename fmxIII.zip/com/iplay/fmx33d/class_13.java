package com.iplay.fmx33d;

import com.nokia.mid.ui.FullCanvas;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Graphics;

// $VF: renamed from: m
public final class class_13 extends FullCanvas {
   public static final int MBOOSTER_MAX_INSTANCES = 0;

   public class_13() {
      class_18.b(((Displayable)this).getWidth(), ((Displayable)this).getHeight());
   }

   public final void paint(Graphics var1) {
      class_18.a(var1);
   }

   public final void keyPressed(int var1) {
      if (var1 != -10) {
         class_18.method_121(var1);
      }
   }

   public final void keyReleased(int var1) {
      if (var1 != -10) {
         class_18.b(var1);
      }
   }

   public final void hideNotify() {
      class_18.method_132();
   }

   public final void showNotify() {
   }

   public final void sizeChanged(int var1, int var2) {
      class_18.b(var1, var2);
   }
}
