package com.iplay.fmx33d;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

// $VF: renamed from: f
public final class class_6 {
   public static final int MBOOSTER_MAX_INSTANCES = 2;
   public final int[] a = new int[18];
   public final int[] b = new int[18];
   // $VF: renamed from: a int
   public int field_62;
   private final int[] g = new int[5];
   private int M;
   // $VF: renamed from: b int
   public int field_63;
   public int c;
   public int d;
   // $VF: renamed from: a byte[]
   public byte[] field_64;
   private static final int[] h = new int[]{4, 5, 6, 7, 8, 9};
   private static final int N = h.length * 2;
   private int[] i;
   public int e;
   public int f;
   // $VF: renamed from: g int
   public int field_65;
   // $VF: renamed from: h int
   public int field_66;
   // $VF: renamed from: a boolean
   public boolean field_67;
   // $VF: renamed from: b boolean
   public boolean field_68;
   private int O;
   private int P;
   // $VF: renamed from: i int
   public int field_69;
   public int j;
   private int Q;
   // $VF: renamed from: h boolean
   private boolean field_70;
   public int k;
   public int l;
   // $VF: renamed from: j int[]
   private final int[] field_71 = new int[]{0, 1, 0, 1024, 1, 0, 0, 1024, 0, 2, 0, 1024, 1, 3, 0, 1024, 2, 1, 0, 980, 0, 3, 0, 1000};
   // $VF: renamed from: k int[]
   private static final int[] field_72 = new int[]{
      4, 9, 0, 1024, 4, 6, 0, 1024, 4, 5, 0, 1024, 5, 8, 0, 1024, 8, 7, 0, 1024, 9, 5, 0, 512, 4, 8, 0, 128, 5, 7, 0, 128, 4, 7, 0, 128
   };
   // $VF: renamed from: l int[]
   private static final int[] field_73 = new int[]{0, 2, 0, 0, 7680, 1, 3, 0, 0, 7680};
   private static final int[] m = new int[0];
   private static final int[] n = new int[0];
   private static final int[] o = new int[]{8, 5, 7, 0, 128, 5, 8, 4, 0, 128, 6, 4, 7, 0, 128, 9, 4, 5, 0, 128, 4, 5, 8, 0, 2048};
   // $VF: renamed from: a int[][]
   public int[][] field_74;
   private int[] p = new int[2];
   private int[] q = new int[2];
   private int[] r = new int[2];
   // $VF: renamed from: i boolean
   private boolean field_75;
   // $VF: renamed from: j boolean
   private boolean field_76;
   // $VF: renamed from: m int
   public int field_77;
   // $VF: renamed from: c boolean
   public boolean field_78;
   // $VF: renamed from: n int
   public int field_79;
   // $VF: renamed from: o int
   public int field_80 = 1;
   // $VF: renamed from: k boolean
   private boolean field_81;
   // $VF: renamed from: l boolean
   private boolean field_82;
   // $VF: renamed from: c int[]
   public int[] field_83;
   private int R;
   private int S;
   // $VF: renamed from: p int
   public int field_84;
   // $VF: renamed from: a long
   public long field_85;
   // $VF: renamed from: q int
   public int field_86;
   // $VF: renamed from: r int
   public int field_87;
   public int s;
   // $VF: renamed from: d boolean
   public boolean field_88;
   // $VF: renamed from: d int[]
   public final int[] field_89 = new int[4];
   // $VF: renamed from: e int[]
   public final int[] field_90 = new int[4];
   // $VF: renamed from: f int[]
   public final int[] field_91 = new int[4];
   public int t;
   public int u;
   public int v;
   public int w;
   public int x;
   public int y;
   public int z;
   public int A;
   private int T;
   private int U;
   public int B;
   public int C;
   public int D;
   public int E;
   public static int F;
   public static int G;
   public int H;
   private int V;
   private int W;
   // $VF: renamed from: e boolean
   public boolean field_92;
   public int I;
   public int J;
   public int K;
   private int X;
   private int Y;
   // $VF: renamed from: f boolean
   public boolean field_93;
   private int Z;
   private int aa;
   private int ab;
   private int ac;
   private int ad;
   // $VF: renamed from: b byte[]
   public byte[] field_94;
   public int L;
   // $VF: renamed from: a java.io.ByteArrayOutputStream
   private ByteArrayOutputStream field_95;
   // $VF: renamed from: a java.io.DataOutputStream
   private DataOutputStream field_96;
   // $VF: renamed from: a java.io.DataInputStream
   private DataInputStream field_97;
   // $VF: renamed from: s int[]
   private int[] field_98 = new int[5];
   // $VF: renamed from: a short[][]
   public static final short[][] field_99 = new short[][]{{103, 150}, {101, 10}, {102, 50}, {104, 80}, {-1, 15}};
   // $VF: renamed from: g boolean
   public boolean field_100;

   public class_6() {
      this.field_64 = new byte[10];
   }

   public final void a() {
      this.field_83 = new int[7];
      int var1 = class_5.method_20(560);
      this.field_74 = new int[var1][7];

      for (int var2 = 0; var2 < var1; var2++) {
         int[] var3 = this.field_74[var2];
         int var4 = class_5.a(560, var2, 0);
         int var5 = class_5.a(560, var2, 1);
         int var6 = class_5.a(560, var2, 2);
         var3[0] = var4 << 10;
         var3[1] = var5 << 10;
         var3[6] = var6;
      }

      this.a(this.field_71, field_73, n);
      this.a(field_72, m, o);
      this.i = new int[N];
   }

   public final void a(int var1) {
      this.Y = var1;
      this.field_80 = 1;
      this.k = 0;
      this.field_81 = false;
      this.field_77 = 1;
      this.field_78 = false;
      this.field_65 = 0;
      this.f = 0;
      this.I = 0;
      this.field_66 = 0;
      this.H = 0;
      this.L = 0;
      this.field_68 = false;
      this.field_85 = 0L;
      this.b(false);
   }

   public final void b(int var1) {
      this.X = var1;

      for (int var2 = 0; var2 < 7; var2++) {
         this.field_83[var2] = class_5.a(563, var1, var2);
      }
   }

   public final void b() {
      this.field_68 = true;
      if (this.method_44() && this.Z == 2) {
         this.t();
      }
   }

   // $VF: renamed from: a () boolean
   public final boolean method_29() {
      return this.j != 9 && this.j != 12;
   }

   // $VF: renamed from: b () boolean
   public final boolean method_35() {
      return this.j == 9;
   }

   private void a(int[] var1, int[] var2, int[] var3) {
      int var6 = var1.length;

      for (int var7 = 0; var7 < var6; var7 += 4) {
         int[] var4 = this.field_74[var1[var7]];
         int[] var5 = this.field_74[var1[var7 + 1]];
         int var8 = var5[0] - var4[0];
         int var9 = var5[1] - var4[1];
         int var10 = var8 * var8 + var9 * var9 >> 10;
         var1[var7 + 2] = var10;
      }

      var6 = var2.length;

      for (int var19 = 0; var19 < var6; var19 += 5) {
         int[] var13 = this.field_74[var2[var19]];
         int[] var15 = this.field_74[var2[var19 + 1]];
         int var21 = var15[0] - var13[0];
         int var23 = var15[1] - var13[1];
         int var25 = class_18.method_131(var21 * var21 + var23 * var23 >> 10);
         int var11 = (var23 << 10) / var25;
         int var12 = -((var21 << 10) / var25);
         var2[var19 + 2] = var11;
         var2[var19 + 3] = var12;
      }

      var6 = var3.length;

      for (int var26 = 0; var26 < var6; var26 += 5) {
         int[] var14 = this.field_74[var3[var26 + 1]];
         int[] var16 = this.field_74[var3[var26 + 2]];
         int var20 = var16[1] - var14[1];
         int var22 = var16[0] - var14[0];
         int var24 = class_18.method_136(var20, var22);
         var3[var26 + 3] = var24;
      }
   }

   public final void a(int var1, int var2) {
      int var3 = this.field_74.length;

      for (int var5 = 0; var5 < var3; var5++) {
         int[] var4 = this.field_74[var5];
         var4[0] += var1;
         var4[1] += var2;
         var4[2] += var1;
         var4[3] += var2;
      }
   }

   public final void c(int var1) {
      this.aa |= var1;
   }

   private void f(int var1) {
      this.R = 0;
      this.S = 512;
      int[] var3 = this.field_74[2];
      int var4 = var3[0] - var3[2];
      int var5 = var3[1] - var3[3];
      if (this.method_43()) {
         if ((var1 & 128) != 0) {
            if (this.field_75) {
               int var6;
               if ((var6 = this.q[0] * var4 + this.q[1] * var5 >> 10) < 0) {
                  var6 = -var6;
               }

               int var7 = this.field_83[5];
               int var8 = this.field_83[4];
               if ((var1 & 192) == 192 && this.H > 0) {
                  var8 += 500;
                  var7 += 4000;
                  this.H--;
                  this.a(2, 2, true);
               }

               int var9;
               int var13;
               class_6 var10000;
               int var10001;
               if ((var13 = (var9 = (var7 - var6 << 10) / var7) > 1024 ? 1024 : var9) > 756) {
                  var10000 = this;
                  var10001 = 512;
               } else {
                  var10000 = this;
                  var10001 = var13;
               }

               var10000.R = var10001 * var8 >> 10;
            }
         } else if ((var1 & 64) == 64) {
            this.S = 8192;
         }
      }

      if (this.field_98[1] > 0) {
         int var10 = this.z * 2048 >> 10;
         int var11 = this.A * 2048 >> 10;
         int[] var12 = this.field_74[0];
         var12[4] += var10;
         var12[5] += var11;
         int[] var14 = this.field_74[1];
         var14[4] += var10;
         var14[5] += var11;
         this.a(0, 2, true);
      }
   }

   private void g(int var1) {
      if (this.method_43()) {
         if (this.s * var1 < 0) {
            this.s = 0;
         }

         int var2 = var1 << 7;
         this.s += var2;
         if (this.field_98[2] > 0) {
            this.s += var2;
         }

         if (this.s < -1024) {
            this.s = -1024;
         }

         if (this.s > 1024) {
            this.s = 1024;
         }

         this.field_88 = true;
      }
   }

   public final void c() {
      this.field_75 = false;
      this.field_76 = false;
      this.k = 0;
      this.l = 0;
      this.field_86 = 0;
      this.field_87 = 0;
      this.M = -1;
      this.field_63 = 0;
      this.c = 0;
      this.d = 0;
      this.A = 0;
      this.z = 0;
      this.s = 0;
      this.field_88 = false;
      this.q[0] = 0;
      this.q[1] = 0;
      this.r[0] = 0;
      this.r[1] = 0;
      this.p[0] = 0;
      this.p[1] = 1;
      this.R = 0;
      this.S = 0;
      this.field_88 = false;
      this.m();
      this.u();
      this.b(true);
      this.H >>= 1;
      this.aa = 0;
      this.field_79 = class_18.method_137(this.field_79, F + 71680, G - 71680);
      int var1 = this.field_79;
      int[] var3 = this.field_74[2];
      int[] var4 = this.field_74[3];
      this.h(var1);
      var1 = var3[0];
      int var2 = var4[0];
      int var5 = var3[1];
      int var6 = var4[1];
      class_8 var7;
      int var8 = (var7 = class_19.a()).b(var1) + 512;
      int var9;
      int[] var10;
      int var11;
      int var12;
      int var10000;
      if ((var9 = var7.b(var2) + 512) <= var8) {
         var10 = var3;
         var11 = var1;
         var12 = var8;
         var10000 = var5;
      } else {
         var10 = var4;
         var11 = var2;
         var12 = var9;
         var10000 = var6;
      }

      int var13 = var10000;
      this.a(0, var12 - var13 + 512);
      this.o();
      var7.a(this);
      int var14 = 10;

      while (--var14 > 0) {
         var3[5] = -512;
         var4[5] = -512;
         var10[0] = var11;
         this.field_77 = 0;
         this.e();
         this.b(this.field_71, field_73, n);
         this.p();
      }

      for (int var15 = 0; var15 < 10; var15++) {
         var10 = this.field_74[var15];
         var10[2] = var10[0];
         var10[3] = var10[1];
      }

      this.field_77--;

      for (int var18 = 0; var18 < 10; var18++) {
         this.field_64[var18] = 0;
      }

      this.J = 0;
      this.K = 0;
      this.o();
      class_19.a().c(this);
   }

   private void h(int var1) {
      int var2 = class_5.a(560, 1, 0) - class_5.a(560, 0, 0) << 10 >> 1;

      for (int var3 = 0; var3 < 10; var3++) {
         int[] var4 = this.field_74[var3];
         int var5 = class_5.a(560, var3, 0) << 10;
         int var6 = class_5.a(560, var3, 1) << 10;
         if (this.field_80 < 0) {
            var5 = var2 + (var2 - var5);
         }

         var5 += var1;
         var4[0] = var4[2] = var5;
         var4[1] = var4[3] = var6;
         var4[4] = 0;
         var4[5] = 0;
      }
   }

   private void i() {
      int var1 = this.L - this.ad;
      if (this.L == 0 || this.aa != this.ab || var1 >= 255) {
         try {
            this.ad = this.L;
            if (var1 != 0) {
               this.field_96.writeByte(var1);
            }

            this.field_96.writeByte(this.aa);
         } catch (Exception var3) {
         }

         this.ab = this.aa;
      }
   }

   private void j() {
      if (this.field_77 < 0) {
         if (this.Z == 1) {
            this.i();
         } else if (this.Z == 2) {
            this.k();
         }

         this.L++;
      }

      int var1;
      if (((var1 = this.aa) & 15) != 0) {
         this.a(var1 & 15, false);
         this.aa &= -16;
      }

      this.f(this.aa & 192);
      if ((var1 & 32) != 0) {
         this.g(1);
      }

      if ((var1 & 16) != 0) {
         this.g(-1);
      }

      if (this.Z != 2) {
         this.aa = 0;
      }

      this.l();
   }

   private void k() {
      if (this.ac <= this.L) {
         try {
            this.aa = this.field_97.readUnsignedByte();
            this.ac = this.ac + this.field_97.readUnsignedByte();
            return;
         } catch (Exception var2) {
            this.ac = Integer.MAX_VALUE;
         }
      }
   }

   private final void l() {
      int[][] var7 = this.field_74;
      if (this.field_75) {
         int[] var8 = var7[2];
         var8[4] += this.R * this.field_80 * this.q[0] >> 10;
         var8[5] += this.R * this.field_80 * this.q[1] >> 10;
      }

      if (this.s != 0) {
         int[] var9 = var7[0];
         int[] var10 = var7[1];
         int var11 = -this.A;
         int var12 = this.z;
         int var13 = this.field_83[6] * this.s >> 10;
         int var20;
         var11 = (var20 = var11 * var13) >> 10;
         int var23;
         var12 = (var23 = var12 * var13) >> 10;
         var9[4] += var11;
         var9[5] += var12;
         var10[4] -= var11;
         var10[5] -= var12;
         if (!this.field_88) {
            this.s = this.s * 768 >> 10;
            this.s = this.s + (this.s < 0 ? 1 : 0);
         }

         this.field_88 = false;
      }

      int var18 = 0;
      int var19 = F;
      int var22 = G;
      int var25 = 256;
      if (this.field_98[3] > 0) {
         var25 = 128;
      }

      int var26 = 10;

      while (--var26 >= 0) {
         int[] var17 = var7[var18++];
         int var5;
         int var1 = var5 = var17[0];
         int var6;
         int var2 = var6 = var17[1];
         int var3 = var17[2];
         int var4 = var17[3];
         var1 += var1 - var3 + (var17[4] << 0);
         int var15;
         var2 = (var15 = var2 + var2 - var4 + (var17[5] << 0)) - var25;
         var17[4] = 0;
         var17[5] = 0;
         if (var1 < var19) {
            var1 = var19;
            this.J = 0;
         }

         if (var1 > var22) {
            var1 = var22;
            this.J = 0;
         }

         var17[0] = var1;
         var17[1] = var2;
         var17[2] = var5;
         var17[3] = var6;
      }
   }

   public final void d() {
      if (this.field_78) {
         this.field_77 = -1;
      } else {
         if (this.field_77 != 0 && --this.field_77 == 0) {
            this.c();
         }
      }
   }

   public final void e() {
      if (!this.field_68) {
         if (this.field_81) {
            this.y();
            this.field_81 = false;
         }

         if (this.field_82) {
            this.l = 0;
            this.k = 0;
            this.field_82 = false;
         }

         this.j();
         this.n();
         this.w();
         this.p();
         this.o();
         this.field_100 = false;

         for (int var1 = 0; var1 < 5; var1++) {
            if (this.field_98[var1] > 0) {
               this.field_98[var1]--;
               if (field_99[var1][0] != -1) {
                  this.field_100 = true;
               }
            }
         }
      }
   }

   public final void d(int var1) {
      this.field_98[var1] = field_99[var1][1];
   }

   // $VF: renamed from: a (int) int
   public final int method_32(int var1) {
      return this.field_98[var1];
   }

   private void m() {
      for (int var1 = 0; var1 < 5; var1++) {
         this.field_98[var1] = 0;
      }
   }

   private final void n() {
      this.b(this.field_71, field_73, n);
      if (!this.method_29()) {
         this.b(field_72, m, o);
      }
   }

   private void o() {
      this.B = this.x;
      this.C = this.y;
      this.D = this.v;
      this.E = this.w;
      this.U = this.z;
      this.T = this.A;
      int[][] var1 = this.field_74;
      int var6 = Integer.MAX_VALUE;
      int var5 = Integer.MAX_VALUE;
      int var8 = Integer.MIN_VALUE;
      int var7 = Integer.MIN_VALUE;

      for (int var9 = 0; var9 < 4; var9++) {
         int[] var2 = var1[var9];
         int var3 = var2[0];
         int var4 = var2[1];
         var5 = var3 < var5 ? var3 : var5;
         var7 = var3 > var7 ? var3 : var7;
         var6 = var4 < var6 ? var4 : var6;
         var8 = var4 > var8 ? var4 : var8;
      }

      class_5.a(this.field_90, var5, var6, var7 - var5, var8 - var6);
      var6 = Integer.MAX_VALUE;
      var5 = Integer.MAX_VALUE;
      var8 = Integer.MIN_VALUE;
      var7 = Integer.MIN_VALUE;

      for (int var18 = 4; var18 < 10; var18++) {
         int[] var11 = var1[var18];
         int var12 = var11[0];
         int var13 = var11[1];
         var5 = var12 < var5 ? var12 : var5;
         var7 = var12 > var7 ? var12 : var7;
         var6 = var13 < var6 ? var13 : var6;
         var8 = var13 > var8 ? var13 : var8;
      }

      class_5.a(this.field_89, var5, var6, var7 - var5, var8 - var6);
      class_5.a(this.field_91, this.field_90);
      class_5.b(this.field_91, this.field_89);
      this.t = this.field_90[0] + this.field_90[2] >> 1;
      this.u = this.field_90[1] + this.field_90[3] >> 1;
      this.v = this.field_89[0] + this.field_89[2] >> 1;
      this.w = this.field_89[1] + this.field_89[3] >> 1;
      int[] var19 = var1[0];
      int[] var10 = var1[1];
      this.x = var10[0] + var19[0] >> 1;
      this.y = var10[1] + var19[1] >> 1;
   }

   private void b(int[] var1, int[] var2, int[] var3) {
      this.c(var1);
      this.b(var2);
      this.a(var3);
      this.c(var1);
      this.b(var2);
      this.a(var3);
   }

   private void a(int[] var1) {
      int var2 = 0;
      int[][] var3 = this.field_74;
      int var4 = var1.length;

      while (var2 < var4) {
         int[] var5 = var3[var1[var2++]];
         int[] var6 = var3[var1[var2++]];
         int[] var7 = var3[var1[var2++]];
         long var8 = var1[var2++];
         long var10 = var1[var2++];
         long var12 = var6[0] - var5[0];
         long var14 = var6[1] - var5[1];
         long var16 = -(var6[1] - var7[1]) * var8 >> 10;
         long var18 = (var6[0] - var7[0]) * var8 >> 10;
         long var20;
         if ((var20 = (var12 * var16 + var14 * var18 >> 10) - var10) * this.field_80 < 0L) {
            var5[0] = (int)(var5[0] + (var20 * var16 >> 10));
            var5[1] = (int)(var5[1] + (var20 * var18 >> 10));
         }
      }
   }

   private void b(int[] var1) {
      this.r();
      int var2 = this.z;
      int var3 = this.A;
      int[][] var4 = this.field_74;
      int var5 = 0;
      int var6 = var1.length;

      while (var5 < var6) {
         int[] var7 = var4[var1[var5++]];
         int[] var8 = var4[var1[var5++]];
         int var9 = var1[var5++] * this.field_80;
         int var10 = var1[var5++];
         int var11 = var1[var5++];
         int var12 = var9 * var2 - var10 * var3 >> 10;
         int var13 = var9 * var3 + var10 * var2 >> 10;
         long var14 = var8[0] - var7[0];
         long var16 = var8[1] - var7[1];
         long var18 = var14 * var12 + var16 * var13 >> 10;
         int var20 = (int)(var12 * var18 >> 11);
         int var21 = (int)(var13 * var18 >> 11);
         var7[0] += var20;
         var7[1] += var21;
         var8[0] -= var20;
         var8[1] -= var21;
         var20 = -var13;
         var21 = var12;
         var14 = var8[0] - var7[0];
         var16 = var8[1] - var7[1];
         if ((var18 = (var14 * var20 + var16 * var21 >> 10) - var11) < 0L) {
            var20 = (int)var18 * var20 >> 11;
            var21 = (int)var18 * var21 >> 11;
            var7[0] += var20;
            var7[1] += var21;
            var8[0] -= var20;
            var8[1] -= var21;
         }
      }
   }

   private void c(int[] var1) {
      int var2 = 0;
      int var3 = var1.length;
      int[][] var4 = this.field_74;

      while (var2 < var3) {
         int[] var5 = var4[var1[var2++]];
         int[] var6 = var4[var1[var2++]];
         long var7 = var1[var2++];
         int var9 = var1[var2++];
         long var10 = var6[0] - var5[0];
         long var12 = var6[1] - var5[1];
         long var14 = var10 * var10 + var12 * var12 >> 10;
         int var16 = (int)((var7 << 10) / (var14 + var7)) - 512;
         int var17 = var5[6];
         int var18 = var6[6];
         if (var17 != var18) {
            var16 /= var17 + var18;
         } else {
            var17 = 1;
            var18 = 1;
         }

         if (var9 != 1024) {
            int var26;
            var16 = (var26 = var16 * var9) >> 10;
         }

         long var22;
         var10 = (var22 = var10 * var16) >> 10;
         long var24;
         var12 = (var24 = var12 * var16) >> 10;
         var5[0] -= (int)var10 * var17;
         var5[1] -= (int)var12 * var17;
         var6[0] += (int)var10 * var18;
         var6[1] += (int)var12 * var18;
      }
   }

   private void p() {
      class_8 var5 = class_19.a();
      int var6 = this.j != 9 ? 5 : 10;

      for (int var7 = 0; var7 < var6; var7++) {
         if (var7 != 9) {
            boolean var4;
            int[] var8;
            label95: {
               var4 = var7 == 2 || var7 == 3;
               var8 = this.p;
               int[] var10000;
               if (var7 == 2) {
                  var10000 = this.q;
               } else {
                  if (var7 != 3) {
                     break label95;
                  }

                  var10000 = this.r;
               }

               var8 = var10000;
            }

            int var3 = var4 ? this.S : 512;
            if (var7 >= 5) {
               var3 <<= 3;
            }

            int var2;
            if ((var2 = -var5.a(this.field_74[var7], var8, var3 >> 5, 1024)) != 0 && var2 > 32) {
               this.a(var7, 1, false);
            }

            boolean var1 = var2 > 0;
            if (var7 == 2) {
               this.field_75 = var1;
            }

            if (var7 == 3) {
               this.field_76 = var1;
            }

            if (var7 == 4 && var1 && this.field_77 < 0) {
               this.e(9);
            }
         }
      }

      this.field_84++;
      if (this.field_75 | this.field_76) {
         this.field_84 = 0;
      } else {
         this.z();
         this.A();
      }

      if (this.method_38() && this.field_70) {
         this.e(9);
      }

      if (this.j != 9) {
         if (this.field_75 && !this.field_76) {
            this.J++;
            this.K = 0;
         }

         if (!this.field_75 && this.field_76) {
            this.K++;
            this.J = 0;
         }

         if (this.field_75 && this.field_76) {
            this.q();
         }
      }
   }

   public final void f() {
      if (this.j == 12) {
         this.field_77 = 75;
         this.j = 9;
      }
   }

   private void q() {
      if (this.J > 35) {
         int var1 = this.J - 35;
         this.b[14] = var1;
      }

      if (this.K > 30) {
         int var2 = this.K - 30;
         this.b[15] = var2;
      }

      if (this.field_92) {
         int var3;
         if ((var3 = this.method_31()) > 0) {
            this.b[17] += var3;
         }

         if (var3 < 0) {
            this.b[16] -= var3;
         }
      }

      class_19.b(this);
      this.J = 0;
      this.K = 0;
      this.d = this.c;
      this.c = 0;
      this.field_63 = 0;
      this.field_62 = 0;
   }

   private void r() {
      int[] var3 = this.field_74[0];
      int[] var4 = this.field_74[1];
      int var1 = var4[0] - var3[0];
      int var2 = var4[1] - var3[1];
      int var5 = class_18.method_111(var1, var2);
      this.z = (var1 << 10) / var5;
      this.A = (var2 << 10) / var5;
      this.O = var3[0] + var4[0] >> 1;
      this.P = var3[1] + var4[1] >> 1;
   }

   // $VF: renamed from: g () boolean
   private boolean method_43() {
      return this.j != 9;
   }

   // $VF: renamed from: c () boolean
   public final boolean method_38() {
      return this.field_84 < 8;
   }

   // $VF: renamed from: d () boolean
   public final boolean method_39() {
      return this.field_84 >= 4;
   }

   // $VF: renamed from: e () boolean
   public final boolean method_40() {
      return this.j != 0;
   }

   private void s() {
      this.L = 0;
      this.ac = 0;
      this.ad = 0;
      this.aa = 0;
      this.ab = 0;
   }

   public final void g() {
      this.s();
      this.field_95 = new ByteArrayOutputStream();
      this.field_96 = new DataOutputStream((OutputStream)this.field_95);
      this.Z = 1;
   }

   public final void a(boolean var1) {
      if (this.Z == 1) {
         class_5.a((OutputStream)this.field_96);
         class_6 var10000;
         byte[] var10001;
         if (var1) {
            var10000 = this;
            var10001 = null;
         } else {
            var10000 = this;
            var10001 = this.field_95.toByteArray();
         }

         var10000.field_94 = var10001;
         this.field_96 = null;
         this.field_95 = null;
         this.Z = 0;
      }
   }

   public final void h() {
      if (this.method_44()) {
         this.s();
         this.field_97 = class_5.method_27(this.field_94);
         this.Z = 2;
      }
   }

   private void t() {
      this.Z = 0;
      if (this.method_44()) {
         class_5.a((InputStream)this.field_97);
      }

      this.field_97 = null;
      this.field_94 = null;
   }

   // $VF: renamed from: f () boolean
   public final boolean method_42() {
      return this.Z == 1;
   }

   // $VF: renamed from: h () boolean
   private boolean method_44() {
      return this.field_94 != null;
   }

   public final void a(byte[] var1) {
      this.Z = 0;
      DataInputStream var2 = class_5.method_27(var1);

      try {
         var2.readInt();
         this.Y = var2.readUnsignedByte();
         this.b(var2.readUnsignedByte());
         this.e = var2.readUnsignedByte();
         var2.readInt();
         int var3 = var2.readInt();
         this.field_94 = new byte[var3];
         class_5.a(var2, this.field_94);
         return;
      } catch (Exception var7) {
      } finally {
         class_5.a((InputStream)var2);
      }
   }

   // $VF: renamed from: a () byte[]
   public final byte[] method_30() {
      ByteArrayOutputStream var1 = new ByteArrayOutputStream();
      DataOutputStream var2 = new DataOutputStream((OutputStream)var1);

      try {
         var2.writeInt(1313822035);
         var2.writeByte(this.Y);
         var2.writeByte(this.X);
         var2.writeByte(this.e);
         var2.writeInt(this.f);
         int var3 = this.field_94.length;
         var2.writeInt(var3);
         ((OutputStream)var2).write(this.field_94);
      } catch (Exception var7) {
      } finally {
         class_5.a((OutputStream)var2);
      }

      this.field_94 = null;
      return var1.toByteArray();
   }

   public final void e(int var1) {
      if (this.field_77 < 0) {
         this.aa &= -16;
         this.aa |= var1;
      }
   }

   private void a(int var1, boolean var2) {
      if (this.method_29() || var1 == 9) {
         if (var1 == 7) {
            if (this.method_32(4) > 0) {
               return;
            }

            this.d(4);
            if (Math.abs(this.z) < 724) {
               return;
            }
         }

         boolean var3 = class_5.a(562, this.j, 6) != 0;
         boolean var4 = class_5.a(562, var1, 6) != 0;
         if (!var2) {
            boolean var5;
            if ((var5 = class_5.a(562, var1, 7) != 0) && this.M < 4) {
               this.field_63++;
            }

            if (var5 && this.method_29() && !var3 && !var4) {
               this.method_33(var1);
               return;
            }
         }

         if (var1 == 8) {
            this.k += 512;
         } else {
            if (this.j != var1) {
               if (var1 == 9) {
                  this.b(true);
                  this.m();
                  this.field_77 = 75;
                  if (this.k > this.l) {
                     this.field_82 = true;
                  }

                  this.field_79 = this.x;
                  class_19.a().b(this);
               } else if (var1 == 12) {
                  class_19.a().b(this);
               } else {
                  this.Q = method_41(var1);
               }

               this.j = var1;
               this.field_69 = 0;
            }
         }
      }
   }

   // $VF: renamed from: a (int) boolean
   private boolean method_33(int var1) {
      if (this.M < 4) {
         this.g[++this.M] = var1;
         return true;
      } else {
         return false;
      }
   }

   private void u() {
      this.j = 0;
      this.field_69 = 0;
      this.Q = method_41(this.j);
   }

   private void v() {
      if (this.M >= 0) {
         this.a(this.g[this.M], true);
         this.M--;
      }
   }

   private void w() {
      if (this.j >= 0) {
         if (this.j != 9) {
            if (this.j != 12) {
               int var1 = class_5.a(562, this.j, 3);
               int var2 = class_5.a(562, this.j, 5);
               int var3 = class_5.a(562, this.j, 9);
               if (this.j == 0) {
                  int var4 = this.s * this.field_80 + 1024 >> 1;
                  int var5 = this.Q - 1;
                  this.field_69 = var4 * var5;
               }

               int var6 = this.field_69 >> 10;
               int var7 = this.Q - 1;
               this.field_70 = var2 == 1 && var6 < var7 - var3;
               this.field_70 = this.field_70 | (this.k > 0 && this.l > 192 && this.k - this.l > 192);
               this.b(var1, var6);
               this.j(var6);
               this.x();
               this.i(var7);
            }
         }
      }
   }

   private void i(int var1) {
      if (this.j != 0) {
         this.field_69 += 1024;
         if (this.field_69 > var1 << 10) {
            this.b[this.j]++;
            this.field_62++;
            if (class_5.a(562, this.j, 10) > 0) {
               this.c(4, 3);
            }

            if (class_5.a(562, this.j, 7) != 0) {
               this.field_63--;
               this.c++;
            }

            if (this.j == 10 || this.j == 11) {
               class_19.b(this);
               this.u();
               this.field_79 = this.x;
               this.a(12, true);
               return;
            }

            this.u();
            this.v();
         }
      }
   }

   private void x() {
      if (this.k > this.l) {
         this.l += 32;
         if (this.field_98[2] > 0) {
            this.l += 32;
            return;
         }
      } else if (this.k > 0 && this.l >= this.k) {
         int var1;
         int var2 = (var1 = this.l >> 9) >> 1;
         int var3 = var1 & 1;
         this.field_81 = var3 != 0;
         this.field_82 = true;
         this.b[13] += var2;
         this.b[8] += var3;
         if (var1 > 0) {
            this.field_62++;
         }
      }
   }

   private void b(int var1, int var2) {
      if (var1 >= 0) {
         int[] var4 = this.i;
         int var5 = this.z * this.field_80;
         int var6 = this.A * this.field_80;
         int var7 = this.O;
         int var8 = this.P;
         short[] var9 = class_5.method_9(var1);
         short var10 = var9[0];
         short var11 = var9[var2 + 1];
         int var12 = var10 + 1 + var11 * N;
         int var15 = 0;
         int var16 = var12 + N;

         while (var12 < var16) {
            int var13 = var9[var12++] * this.field_80;
            int var14 = -var9[var12++];
            var4[var15++] = (var13 * var5 - var14 * var6 >> 9) + var7;
            var4[var15++] = (var13 * var6 + var14 * var5 >> 9) + var8;
         }

         int var21 = 0;
         int[] var22 = h;
         int[][] var23 = this.field_74;
         int var24 = var22.length;

         for (int var25 = 0; var25 < var24; var25++) {
            int[] var3 = var23[var22[var25]];
            int var17 = var3[0];
            int var18 = var3[1];
            int var19 = var4[var21++] - var17 >> 1;
            int var20 = var4[var21++] - var18;
            var17 += var19;
            var18 += var20;
            var3[0] = var17;
            var3[1] = var18;
         }
      }
   }

   private final void j(int var1) {
      int var2;
      if ((var2 = class_5.a(562, this.j, 4)) >= 0) {
         int var3 = class_5.a(561, var2, 0);
         if (var1 == var3) {
            int var4 = class_5.a(561, var2, 1);
            int var5 = class_5.a(561, var2, 2);
            this.field_74[var4][5] += var5 << 10;
         }

         var3 = class_5.a(561, var2, 3);
         if (var1 == var3) {
            int var8 = class_5.a(561, var2, 4);
            int var9 = class_5.a(561, var2, 5);
            this.field_74[var8][5] += var9 << 10;
         }
      }
   }

   private final void c(int var1, int var2) {
      this.field_64[var1] = (byte)var2;
   }

   private final void a(int var1, int var2, boolean var3) {
      if ((class_19.a & 1) == 0 && (!var3 || this.field_64[var1] == 0)) {
         this.c(var1, var2);
      }
   }

   private final void y() {
      this.field_80 *= -1;
      int[][] var1 = this.field_74;
      int var3 = var1[0][0] + var1[1][0] >> 1;
      int var4 = var1[0][1] + var1[1][1] >> 1;
      int var5 = -this.A;
      int var6 = this.z;

      for (int var9 = 0; var9 < 10; var9++) {
         int[] var2 = var1[var9];
         int var7 = var2[0] - var3;
         int var8 = var2[1] - var4;
         var2[0] = (var7 * var6 - var8 * var5 >> 10) + var3;
         var2[1] = (var7 * var5 + var8 * var6 >> 10) + var4;
         var7 = var2[2] - var3;
         var8 = var2[3] - var4;
         var2[2] = (var7 * var6 - var8 * var5 >> 10) + var3;
         var2[3] = (var7 * var5 + var8 * var6 >> 10) + var4;
      }

      int[] var33 = var1[0];
      int[] var10 = var1[1];
      int var11 = var33[0] + var10[0] >> 1;

      for (int var12 = 0; var12 < 10; var12++) {
         int[] var25 = var1[var12];
         var25[0] = var11 + (var11 - var25[0]);
      }

      var33 = var1[0];
      var10 = var1[1];
      int var36 = -(var33[0] + var10[0]) >> 1;
      int var13 = -(var33[1] + var10[1]) >> 1;
      var5 = this.A;
      var6 = this.z;
      int var14 = this.T;
      int var15 = this.U;
      int var16 = this.x;
      int var17 = this.y;
      int var18 = this.B;
      int var19 = this.C;

      for (int var24 = 0; var24 < 10; var24++) {
         int[] var26 = var1[var24];
         int var30 = var26[0] + var36;
         int var32 = var26[1] + var13;
         int var20 = var30 * var6 - var32 * var5 >> 10;
         int var21 = var30 * var5 + var32 * var6 >> 10;
         int var22 = var30 * var15 - var32 * var14 >> 10;
         int var23 = var30 * var14 + var32 * var15 >> 10;
         var20 += var16;
         var21 += var17;
         var22 += var18;
         var23 += var19;
         var26[0] = var20;
         var26[1] = var21;
         var26[2] = var22;
         var26[3] = var23;
      }
   }

   // $VF: renamed from: b (int) int
   public final int method_34(int var1) {
      return this.field_74[var1][0];
   }

   // $VF: renamed from: c (int) int
   public final int method_37(int var1) {
      return this.field_74[var1][1];
   }

   // $VF: renamed from: d (int) int
   private static int method_41(int var0) {
      return class_5.a(class_5.a(562, var0, 3), 0);
   }

   private void b(boolean var1) {
      this.field_92 = false;
      this.field_62 = 0;
      this.J = 0;
      this.K = 0;

      for (int var2 = 0; var2 < 18; var2++) {
         if (!var1) {
            this.a[var2] = 0;
         }

         this.b[var2] = 0;
      }
   }

   private void z() {
      if (!this.field_92) {
         this.W = 0;
         this.V = this.method_36();
         this.field_92 = true;
      }
   }

   private void A() {
      if (this.field_92) {
         int var1 = this.method_36();
         if (this.V != var1) {
            int var2;
            class_6 var10000;
            label18: {
               int var10002;
               if (Math.abs(var1 - this.V) == 1) {
                  var10000 = this;
                  var2 = this.W;
                  var10002 = (var1 - this.V) * this.field_80;
               } else {
                  if (var1 > this.V) {
                     var10000 = this;
                     var2 = this.W - this.field_80;
                     break label18;
                  }

                  var10000 = this;
                  var2 = this.W;
                  var10002 = this.field_80;
               }

               var2 += var10002;
            }

            var10000.W = var2;
            this.V = var1;
         }
      }
   }

   // $VF: renamed from: a () int
   private int method_31() {
      if (this.field_92) {
         this.field_92 = false;
         if (this.W > 0) {
            this.W++;
         }

         if (this.W < 0) {
            this.W--;
         }

         return this.W / 4;
      } else {
         return 0;
      }
   }

   // $VF: renamed from: b () int
   private final int method_36() {
      int[] var1 = this.field_74[2];
      int[] var2 = this.field_74[3];
      int var3 = var2[0] - var1[0];
      if (var2[1] - var1[1] <= 0) {
         return var3 >= 0 ? 0 : 1;
      } else {
         return var3 >= 0 ? 3 : 2;
      }
   }
}
