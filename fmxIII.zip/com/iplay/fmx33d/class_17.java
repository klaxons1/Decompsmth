package com.iplay.fmx33d;

// $VF: renamed from: q
public final class class_17 {
   public class_21 a;
   // $VF: renamed from: a u
   public class_20 field_222;
   private int c;
   private int d;
   private int e = 1024;
   private int f;
   private int g;
   // $VF: renamed from: a int
   public static int field_223 = 32768;
   private int h = 1024;
   public class_21 b;
   // $VF: renamed from: c v
   public class_21 field_224;
   // $VF: renamed from: b int
   public int field_225;
   // $VF: renamed from: a v[]
   private class_21[] field_226;
   // $VF: renamed from: b v[]
   private class_21[] field_227;
   // $VF: renamed from: c v[]
   private class_21[] field_228;
   // $VF: renamed from: a int[]
   private int[] field_229;

   public class_17() {
      this.a = new class_21();
      this.field_222 = new class_20();
      this.field_222.a.a(class_21.b);
      this.field_222.b.a(class_21.c);
      this.field_222.c.a(class_21.d);
      new class_21();
      new class_20();
      new class_21();
      new class_21();
      new class_21();
      this.field_226 = new class_21[6];
      this.field_227 = new class_21[6];
      this.field_228 = new class_21[6];

      for (int var1 = 0; var1 < 6; var1++) {
         this.field_226[var1] = new class_21();
         this.field_227[var1] = new class_21();
         this.field_228[var1] = new class_21();
      }

      this.field_229 = new int[6];
      this.field_224 = new class_21();
      this.b = new class_21();
   }

   public final void a(int var1, int var2) {
      this.c = var1;
      this.d = var2;
      int var3 = this.e >> 1;
      int var4 = (var2 << 10) / var1;
      this.f = var3;
      this.g = var3 * var4 >> 10;
      class_21 var5;
      (var5 = this.field_226[0]).a(-1024, 0, this.f);
      var5.a();
      (var5 = this.field_226[1]).a(1024, 0, this.f);
      var5.a();
      (var5 = this.field_226[3]).a(0, 1024, this.g);
      var5.a();
      (var5 = this.field_226[2]).a(0, -1024, this.g);
      var5.a();
      this.field_226[4].a(class_21.d);
      this.field_226[5].a(class_21.f);
   }

   private void a(class_21 var1, class_20 var2) {
      int var3 = var1.field_278;
      int var4 = var1.field_279;
      int var5 = var1.field_280;
      class_21 var6;
      int var7 = (var6 = var2.c).field_278;
      int var8 = var6.field_279;
      int var9 = var6.field_280;
      int var10 = this.h + (field_223 - this.h >> 1) >> 10;
      int var11 = var3 + var7 * var10;
      int var12 = var4 + var8 * var10;
      int var13 = var5 + var9 * var10;
      this.field_224.a(var11, var12, var13);
      class_21 var14;
      (var14 = this.b).a(this.f, this.g, 1024);
      var2.a(var14);
      var10 = field_223 >> 10;
      int var15 = var3 + var14.field_278 * var10;
      int var16 = var4 + var14.field_279 * var10;
      int var17 = var5 + var14.field_280 * var10;
      long var18 = var15 - var11;
      long var20 = var16 - var12;
      long var22 = var17 - var13;
      this.field_225 = (int)(var18 * var18 + var20 * var20 + var22 * var22 >> 10);
      this.b.a(var15, var16, var17);
   }

   public final void a(class_21 var1, class_21 var2) {
      this.a.a(var1);
      this.a(var2);
   }

   private void a(class_21 var1) {
      this.field_222.b(this.a, class_21.c, var1);
   }

   public final void a() {
      this.a(this.a, this.field_222);
      this.a(this.a, this.field_222, this.field_227, this.field_229);
   }

   private void a(class_21 var1, class_20 var2, class_21[] var3, int[] var4) {
      class_21[] var5 = this.field_226;

      for (int var6 = 0; var6 < 6; var6++) {
         var3[var6].a(var5[var6]);
         var2.a(var3[var6]);
         var4[var6] = var1.method_166(var3[var6]) + -64;
      }

      var4[4] += this.h;
      var4[5] -= field_223;
   }

   public final int a(class_21 var1, int var2, class_20 var3, class_21 var4) {
      var3.a(var1, var4);
      class_21 var5;
      long var6 = (var5 = this.field_224).field_278 - var1.field_278;
      long var8 = var5.field_279 - var1.field_279;
      long var10 = var5.field_280 - var1.field_280;
      int var12 = this.field_225 + var2;
      if ((int)(var6 * var6 + var8 * var8 + var10 * var10 >> 10) > var12) {
         return -1;
      }

      int var14 = var1.field_278;
      int var15 = var1.field_279;
      int var16 = var1.field_280;
      int var17 = 0;
      class_21[] var18 = this.field_227;
      int[] var19 = this.field_229;

      for (int var20 = 0; var20 < 6; var20++) {
         class_21 var21;
         int var22 = (var21 = var18[var20]).field_278;
         int var23 = var21.field_279;
         int var24 = var21.field_280;
         long var25;
         if ((var25 = (long)(var22 * var14 + var23 * var15 + var24 * var16 >> 10) - var19[var20]) * var25 >> 10 > var2) {
            if (var25 < 0L) {
               return -1;
            }
         } else {
            var17 |= 1 << var20;
         }
      }

      return var17;
   }
}
