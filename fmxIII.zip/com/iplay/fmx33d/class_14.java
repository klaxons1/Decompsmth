package com.iplay.fmx33d;

// $VF: renamed from: n
public final class class_14 {
   private int[] a;
   // $VF: renamed from: a v
   public class_21 field_156;
   public class_21 b;
   // $VF: renamed from: a byte[]
   public byte[] field_157;
   // $VF: renamed from: a v[]
   public class_21[] field_158;
   // $VF: renamed from: b v[]
   public class_21[] field_159;
   private class_21[] c;
   // $VF: renamed from: a u[]
   private class_20[] field_160;
   // $VF: renamed from: c v
   private static final class_21 field_161 = new class_21();
   // $VF: renamed from: b int[]
   private static final int[] field_162 = new int[]{0, 1, 2, 3, 5, 6};
   // $VF: renamed from: a f
   private class_6 field_163;
   // $VF: renamed from: c int
   private int field_164 = 256;
   // $VF: renamed from: a boolean
   private boolean field_165;
   // $VF: renamed from: a int
   public static int field_166 = Integer.MIN_VALUE;
   // $VF: renamed from: b int
   public static int field_167 = Integer.MAX_VALUE;

   public class_14() {
      this.field_156 = new class_21();
      this.b = new class_21();
      this.c = new class_21[8];
      this.field_160 = new class_20[8];

      for (int var1 = 0; var1 < 8; var1++) {
         this.c[var1] = new class_21();
         this.field_160[var1] = new class_20();
      }

      this.field_158 = new class_21[13];
      this.field_159 = new class_21[13];

      for (int var8 = 0; var8 < 13; var8++) {
         this.field_158[var8] = new class_21();
         this.field_159[var8] = new class_21();
      }

      this.field_157 = new byte[13];

      for (int var9 = 0; var9 < 13; var9++) {
         int var2 = class_5.a(577, var9, 0);
         int var3 = class_5.a(577, var9, 1) << 10;
         int var4 = class_5.a(560, var2, 0) << 10;
         int var5 = class_5.a(560, var2, 1) << 10;
         class_21 var6 = this.field_159[var9];
         this.field_158[var9].a(var4, var5, var3);
         var6.a(var4, var5, var3);
      }

      class_21 var10 = class_21.g;
      this.a = new int[42];

      for (int var11 = 0; var11 < 14; var11++) {
         int var12 = var11 * 3;
         int var13 = class_5.a(579, var11, 0);
         int var14 = class_5.a(579, var11, 1);
         class_21 var15 = this.field_158[var13];
         class_21 var7 = this.field_158[var14];
         var10.a(var15, var7);
         this.a[var12 + 0] = var13;
         this.a[var12 + 1] = var14;
         this.a[var12 + 2] = var10.b();
      }
   }

   private final void a(int var1, int var2) {
      this.field_157[var1] = (byte)var2;
   }

   private final void b(int var1, int var2) {
      if ((class_19.a & 1) == 0) {
         this.a(var1, var2);
      }
   }

   public final void a(class_6 var1, int var2, class_20 var3, class_20 var4) {
      this.field_163 = var1;
      int var5 = var1.v;
      int var6 = var1.w;
      int var7 = var1.D;
      int var8 = var1.E;
      int var9 = var1.field_80;
      this.field_156.a(var7, var8, var2);
      this.b.a(var7 - (var5 - var7), var8 - (var6 - var8), var2);
      int[][] var10 = var1.field_74;

      for (int var11 = 0; var11 < 13; var11++) {
         int var12 = class_5.a(577, var11, 0);
         int var13 = class_5.a(577, var11, 1) << 10;
         int var14 = var10[var12][0];
         int var15 = var10[var12][1];
         int var16 = var10[var12][2];
         int var17 = var10[var12][3];
         var14 -= var5;
         var15 -= var6;
         var16 -= var7;
         var17 -= var8;
         var14 *= var9;
         var16 *= var9;
         class_21 var18;
         (var18 = this.field_158[var11]).a(var14, var15, var13);
         var4.a(var18);
         var18.b(var5, var6, var2);
         class_21 var19;
         (var19 = this.field_159[var11]).a(var16, var17, var13);
         var3.a(var19);
         var19.b(var7, var8, var2);
      }
   }

   public final void a() {
      this.b();
      this.c();
      this.c();
      this.c();
      this.f();
   }

   private void b() {
      class_21 var1 = class_21.g;
      class_21 var2 = class_21.h;

      for (int var3 = 0; var3 < 13; var3++) {
         class_21 var4 = this.field_158[var3];
         class_21 var5 = this.field_159[var3];
         var1.a(var4);
         var2.a(var4, var5);
         var2.field_279 = var2.field_279 - this.field_164;
         var4.b(var2);
         if (var4.field_278 < field_166) {
            var4.field_278 = field_166;
         }

         if (var4.field_278 > field_167) {
            var4.field_278 = field_167;
         }

         this.field_159[var3].a(var1);
      }
   }

   private void c() {
      class_21 var1 = class_21.g;
      int var2 = 0;

      for (int var3 = 0; var3 < 14; var3++) {
         class_21 var4 = this.field_158[this.a[var2++]];
         class_21 var5 = this.field_158[this.a[var2++]];
         var1.a(var5, var4);
         long var6 = this.a[var2++];
         long var8 = var1.b();
         int var10 = (int)((var6 << 10) / (var8 + var6)) - 512;
         var1.a(var10);
         var4.c(var1);
         var5.b(var1);
      }

      if (!this.field_165) {
         this.d();
      }

      var2 = 0;

      for (int var16 = 0; var16 < 2; var16++) {
         class_21 var17 = this.field_158[field_162[var2++]];
         class_21 var18 = this.field_158[field_162[var2++]];
         class_21 var19 = this.field_158[field_162[var2++]];
         var17.a(var18);
         var17.b(var19);
         var17.c(1);
      }

      this.g();
      this.e();
   }

   private void d() {
      class_8 var1 = class_19.a();

      for (int var2 = 0; var2 < 13; var2++) {
         if (var2 != 3) {
            class_21 var3 = this.field_158[var2];
            class_21 var4 = this.field_159[var2];
            int var5;
            if ((var5 = var1.a(var3, var4, field_161, 48, 512)) < 0) {
               if (this.field_163 != null) {
                  this.field_163.f();
               }

               if (var5 < -64) {
                  this.b(var2, 1);
               }
            }
         }
      }
   }

   private void e() {
      class_21 var1 = class_21.g;
      class_21 var2 = class_21.h;
      int var3 = 0;
      int[] var4 = class_5.method_10(581);
      byte[] var5 = class_5.method_8(578);

      for (int var6 = 0; var6 < 7; var6++) {
         class_20 var7 = this.field_160[var4[var3 + 0]];
         int var8 = var4[var3 + 1];
         byte var9 = var5[var8 * 3 + 0];
         byte var10 = var5[var8 * 3 + 1];
         class_21 var11 = this.field_158[var9];
         class_21 var12 = this.field_158[var10];
         var1.a(var12, var11);
         var1.a();
         int var13;
         int[] var14 = class_5.method_10(var13 = var4[var3 + 2]);
         int var15 = class_5.method_20(var13);

         for (int var16 = 0; var16 < var15; var16++) {
            var2.a(var14, var16 * 3);
            var7.a(var2);
            int var17;
            if ((var17 = var2.method_166(var1) >> 1) < 0) {
               var2.a(var17);
               var12.c(var2);
               var11.b(var2);
            }
         }

         var3 += 3;
      }
   }

   private void f() {
      this.b.a(this.field_156);
      this.field_156.a(this.field_158[0]);

      for (int var1 = 0; var1 < 8; var1++) {
         int var2 = class_5.a(578, var1, 0);
         this.c[var1].a(this.field_158[var2]);
      }

      this.g();
   }

   private void g() {
      class_21 var1 = class_21.g;
      class_21 var2 = class_21.h;
      class_21 var3 = class_21.i;
      var1.a(this.field_158[1]);
      var1.c(this.field_158[0]);
      var2.a(this.field_158[3]);
      var2.c(this.field_158[0]);
      var3.b(var1, var2);
      int var4 = 0;
      int[] var5 = class_5.method_10(580);

      for (int var6 = 0; var6 < 8; var6++) {
         int var7 = var5[var4 + 0];
         int var8 = var5[var4 + 1];
         int var9 = var5[var4 + 2];
         int var10 = var5[var4 + 3];
         int var11 = var5[var4 + 4];
         int var12 = var5[var4 + 5];
         int var13 = var5[var4 + 6];
         class_20 var14 = this.field_160[var7];
         if (var8 >= 0) {
            var14.a.a(this.field_158[var9], this.field_158[var8]);
         } else {
            var14.a.a(var1);
         }

         if (var10 >= 0) {
            var14.b.a(this.field_158[var11], this.field_158[var10]);
         } else {
            var14.b.a(var2);
         }

         if (var12 >= 0) {
            var14.c.a(this.field_158[var13], this.field_158[var12]);
         } else {
            var14.c.a(var1);
         }

         try {
            var14.b();
         } catch (Exception var16) {
         }

         var4 += 7;
      }
   }

   public final class_21 a(int var1) {
      return this.c[var1];
   }

   // $VF: renamed from: a (int) u
   public final class_20 method_63(int var1) {
      return this.field_160[var1];
   }

   public final void a(class_6 var1, class_20 var2) {
      int var3 = var1.x;
      int var4 = var1.y;
      this.a(var1, var2, var3, var4);
      this.h();
   }

   private void h() {
      for (int var1 = 0; var1 < 8; var1++) {
         int var2 = class_5.a(578, var1, 0);
         int var3 = class_5.a(578, var1, 1);
         class_21 var4 = this.field_158[var2];
         class_21 var5 = this.field_158[var3];
         this.c[var1].a(var4);
         int var6 = var5.field_278 - var4.field_278;
         int var7 = var5.field_279 - var4.field_279;
         int var8;
         if ((var8 = class_18.method_111(var6, var7)) != 0) {
            int var9;
            var6 = (var9 = var6 << 10) / var8;
            int var10;
            var7 = (var10 = var7 << 10) / var8;
         }

         this.field_160[var1].b(var6, var7);
      }
   }

   private void a(class_6 var1, class_20 var2, int var3, int var4) {
      for (int var5 = 0; var5 < 13; var5++) {
         int var6 = class_5.a(577, var5, 0);
         int var7 = class_5.a(577, var5, 1) << 10;
         int var8 = var1.method_34(var6) - var3;
         int var9 = var1.method_37(var6) - var4;
         class_21 var10;
         (var10 = this.field_158[var5]).a(var8, var9, var7);
         var2.b(var10);
      }
   }

   public final void a(class_21 var1, class_20 var2) {
      for (int var3 = 0; var3 < 8; var3++) {
         class_21 var4 = this.c[var3];
         var2.a(var4, var1);
         this.field_160[var3].b(var2);
      }
   }
}
