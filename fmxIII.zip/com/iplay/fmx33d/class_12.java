package com.iplay.fmx33d;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import javax.microedition.media.Manager;
import javax.microedition.media.MediaException;
import javax.microedition.media.Player;
import javax.microedition.media.PlayerListener;

// $VF: renamed from: l
public final class class_12 implements PlayerListener {
   private Player a;
   // $VF: renamed from: a boolean
   private boolean field_152;
   private boolean b;
   // $VF: renamed from: a int
   private int field_153;
   // $VF: renamed from: b int
   private int field_154;
   private int c;
   // $VF: renamed from: a java.lang.String[]
   private static String[] field_155 = new String[10];

   public final void a(int var1, boolean var2, boolean var3) {
      this.a();
      this.field_152 = var3;
      this.b = var2;
      int var4 = var2 ? this.field_153 : this.field_154;
      this.a(var1, var4, 0);
   }

   private void a(int var1, int var2, int var3) {
      if (var2 > 0 && this.a == null) {
         try {
            this.a = this.method_62(var1, var3);
            if (this.a != null) {
               try {
                  this.a.setMediaTime(0L);
               } catch (Exception var5) {
               }

               this.a.start();
               this.d();
            }

            return;
         } catch (Exception var6) {
         }
      }
   }

   // $VF: renamed from: a (int, int) javax.microedition.media.Player
   private Player method_62(int var1, int var2) {
      ByteArrayInputStream var3 = null;
      Player var4 = null;

      try {
         if (!a(var4 = Manager.createPlayer((InputStream)(var3 = new ByteArrayInputStream(class_5.method_8(var1))), field_155[var2]))) {
            var4 = null;
         }

         if (var4 != null) {
            if (this.field_152) {
               var4.setLoopCount(-1);
            } else {
               var4.setLoopCount(1);
               var4.addPlayerListener(this);
            }

            var4.prefetch();
         }
      } catch (Exception var9) {
      } finally {
         class_5.a((InputStream)var3);
      }

      return var4;
   }

   private static final boolean a(Player var0) {
      boolean var1 = false;

      try {
         if (false) {
            throw (MediaException)null;
         }

         var0.realize();
         var1 = true;
      } catch (MediaException var3) {
         System.gc();
      }

      return var1;
   }

   public final void a() {
      if (this.a != null) {
         try {
            this.a.stop();
         } catch (Exception var2) {
         }

         this.c();
      }

      this.a = null;
   }

   private void c() {
      if (this.a != null) {
         try {
            this.a.deallocate();
         } catch (Exception var3) {
         }

         try {
            this.a.close();
         } catch (Exception var2) {
         }
      }

      this.a = null;
   }

   public final void a(int var1, int var2) {
      this.field_153 = var1;
      this.field_154 = var2;
      this.d();
   }

   private void d() {
      if (this.a != null && this.a.getState() == 400) {
         if ((this.b ? this.field_153 : this.field_154) > 0) {
            return;
         }

         this.a();
      }
   }

   public final void playerUpdate(Player var1, String var2, Object var3) {
      if (var2 == "endOfMedia") {
         this.a();
      }
   }

   public final void b() {
      if (this.c > 0) {
         this.a(this.c, this.b, this.field_152);
         this.c = 0;
      }
   }

   // $VF: widened method access to satisfy Java override rules
   static {
      field_155[0] = "audio/midi";
      field_155[1] = "audio/x-mid";
      field_155[2] = "audio/sp-midi";
      field_155[4] = "audio/amr";
      field_155[3] = "audio/x-wav";
      field_155[6] = "audio/mmf";
      field_155[9] = "audio/imelody";
   }
}
