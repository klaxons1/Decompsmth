package com.iplay.fmx33d;

import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;

// $VF: renamed from: h
public final class class_8 {
   public static final class_21 a = new class_21(256, -128, 500);
   public static final class_21 b = new class_21(0, 1000, 6000);
   public static final class_21 c = new class_21(0, 1000, 4500);
   public static final class_21 d = new class_21(0, 6800, 8800);
   public static final class_21 e = new class_21(0, 2800, 5800);
   public static final class_21 f = new class_21(0, 3000, 2800);
   public final class_21 g = new class_21();
   public final class_21 h = new class_21();
   public final class_21 i = new class_21();
   public final class_21 j = new class_21();
   public final class_21 k = new class_21();
   public final class_21 l = new class_21();
   public final class_21 m = new class_21();
   public final class_21 n = new class_21();
   // $VF: renamed from: a u
   public final class_20 field_101 = new class_20();
   // $VF: renamed from: b u
   public final class_20 field_102 = new class_20();
   // $VF: renamed from: a i
   public static class_9 field_103;
   // $VF: renamed from: a d[]
   public static class_4[] field_104;
   // $VF: renamed from: a a
   public static class_0 field_105;
   private int r;
   private int s;
   private int t;
   private int u;
   // $VF: renamed from: a int
   public int field_106 = -1;
   // $VF: renamed from: b int
   public int field_107;
   // $VF: renamed from: c int
   public int field_108;
   // $VF: renamed from: d int
   public int field_109;
   // $VF: renamed from: e int
   public int field_110;
   // $VF: renamed from: f int
   public int field_111;
   // $VF: renamed from: g int
   public int field_112;
   // $VF: renamed from: h int
   public int field_113;
   // $VF: renamed from: i int
   public int field_114;
   // $VF: renamed from: j int
   public int field_115;
   // $VF: renamed from: k int
   public int field_116;
   // $VF: renamed from: l int
   public int field_117;
   // $VF: renamed from: m int
   public int field_118;
   // $VF: renamed from: n int
   public int field_119;
   public int o;
   public int p;
   public int q;
   // $VF: renamed from: a int[]
   public int[] field_120;
   // $VF: renamed from: a long
   public long field_121;
   // $VF: renamed from: b int[]
   private static int[] field_122;
   // $VF: renamed from: a b
   private class_1 field_123;
   // $VF: renamed from: a boolean
   private boolean field_124;

   public final void a(Graphics var1) {
      this.a(var1, false);
   }

   private void a(Graphics var1, boolean var2) {
      this.b(var1);
      this.field_123.a(var1);
      this.method_50(this.field_119);
      this.a(this.field_112, (class_20)null);
      this.a(this.field_113, (class_20)null);
      this.field_101.a();
      this.n.a(this.p >> 5, this.b(this.p) >> 5, 0);
      this.a(37, this.field_101, this.n);
      this.field_101.a(512, -887);
      this.n.a(this.q >> 5, this.b(this.q) >> 5, 0);
      this.a(37, this.field_101, this.n);
      if (!var2) {
         this.e();
      }

      this.a(this.field_116, (class_20)null);
      this.a(this.field_114, (class_20)null);
      this.a(this.field_115, (class_20)null);
      if (this.field_117 >= 0) {
         int var3 = class_19.a << 6;
         this.field_102.a(class_18.e(var3), class_18.d(var3));
         this.a(this.field_117, this.field_102, this.field_121);
      }

      field_105.a(this);
      this.field_123.method_2();
   }

   private void e() {
      int var1 = class_19.method_145();

      for (int var2 = 0; var2 < var1; var2++) {
         field_103.b(var2);
      }

      for (int var4 = var1 - 1; var4 >= 0; var4--) {
         class_6 var3;
         if ((var3 = class_19.method_148(var4)).field_67 && !var3.field_93) {
            this.d(var4);
         }
      }

      for (int var5 = var1 - 1; var5 >= 0; var5--) {
         class_6 var7;
         if ((var7 = class_19.method_148(var5)).field_67) {
            this.a(var5, var7);
         }
      }

      for (int var6 = var1 - 1; var6 >= 0; var6--) {
         class_6 var8;
         if ((var8 = class_19.method_148(var6)).field_67) {
            this.field_123.a(var8.field_93);
            this.b(var6, var8);
            this.field_123.a(true);
         }
      }
   }

   // $VF: renamed from: a () q
   private class_17 method_45() {
      return this.field_123.a();
   }

   private void a(int var1, class_20 var2, class_21 var3) {
      this.field_123.a(var1, var2, var3);
   }

   private void b(int var1, class_20 var2, class_21 var3) {
      this.field_123.b(var1, var2, var3);
   }

   private void b(int var1, int var2, int var3, int var4, int var5, int var6, boolean var7) {
      this.field_123.a(var1, var5, var2, var3, var4);
   }

   public final void a(Graphics var1, int var2) {
      this.a(0, -18432, 0, 0, 0, 17);
      this.field_123.a(var1);
      int var3 = class_18.method_124() << 4;
      this.n.a(0, 0, 0);
      this.field_101.a();
      this.field_101.a(class_18.e(var3), -class_18.d(var3));
      this.a(var2, this.field_101, this.n);
      this.field_123.method_2();
   }

   private void b(Graphics var1) {
      this.c(var1);
   }

   private void c(Graphics var1) {
      int var2 = this.field_123.method_0();
      int var3 = this.field_123.b();
      class_21 var4 = this.field_123.a().a;
      class_20 var5 = this.field_123.a().field_222;
      int var6;
      Image var7 = class_5.method_6(var6 = this.field_111);
      int var8 = class_5.method_15(var6);
      int var9 = class_5.method_20(var6);
      int var10;
      if ((var10 = ((var5.b.field_279 - 1024 >> 2) + 16) * var3 >> 8) > 0) {
         int var11 = var10;
         if (var10 > var3) {
            var11 = var3;
         }

         int var12 = this.field_109;
         var1.setColor(var12);
         var1.fillRect(0, 0, var2, var11);
      }

      if (var10 + var9 < var3) {
         int var14 = var10 + var9;
         int var16 = var3 - var14;
         int var13 = this.field_110;
         var1.setColor(var13);
         var1.fillRect(0, var14, var2, var16);
      }

      if (var10 > -var9 && var10 < var3) {
         int var15;
         label32: {
            int var10000;
            if ((var15 = (-(var4.field_278 >> 8) + (var5.a.field_280 >> 2)) * var8 >> 6) <= -var8) {
               var10000 = var15 + -var15 / var8 * var8;
            } else {
               if (var15 <= 0 || (var15 -= var15 / var8 * var8) <= 0) {
                  break label32;
               }

               var10000 = var15 - var8;
            }

            var15 = var10000;
         }

         do {
            var1.drawImage(var7, var15, var10, 20);
         } while ((var15 += var8) < var2);
      }
   }

   public final void a() {
      field_103 = new class_9(5);
      field_104 = new class_4[2];

      for (int var1 = 0; var1 < 2; var1++) {
         field_104[var1] = new class_4(5);
      }

      field_104[0].a = true;
      field_105 = new class_0();
      int var4 = class_5.method_15(183);
      int var2 = class_5.method_20(183);
      int var3;
      field_122 = new int[var3 = var4 * var2];
      System.arraycopy(class_5.method_10(183), 0, field_122, 0, var3);
      this.field_123.method_1();
   }

   public final void a(int var1, int var2) {
      if (this.field_123 == null) {
         this.field_123 = new class_1();
      }

      this.field_123.a(var1, var2);
   }

   public final void a(int var1) {
      this.method_49(var1);
   }

   // $VF: renamed from: b (int) void
   private void method_49(int var1) {
      this.field_106 = var1;
      this.field_108 = class_5.a(570, var1, 2);
      this.field_117 = class_5.a(570, var1, 4);
      int var2 = class_5.a(570, var1, 5);
      this.field_112 = class_5.a(566, this.field_108, 2);
      this.field_113 = class_5.a(566, this.field_108, 3);
      this.field_115 = class_5.a(566, this.field_108, 4);
      this.field_114 = class_5.a(566, this.field_108, 5);
      this.field_119 = class_5.a(566, this.field_108, 1);
      this.o = class_5.a(566, this.field_108, 6);
      this.field_116 = class_5.a(566, this.field_108, 7);
      this.field_118 = class_5.a(566, this.field_108, 8);
      this.field_107 = class_5.a(566, this.field_108, 0);
      this.field_109 = class_5.a(565, this.field_107, 0);
      this.field_110 = class_5.a(565, this.field_107, 1);
      this.field_111 = class_5.a(565, this.field_107, 2);
      field_104[0].a(this.field_112, true);
      field_104[1].a(this.field_114, false);
      this.p = class_5.a(var2, 0, 0) << 5;
      this.q = class_5.a(var2, 1, 0) << 5;
      if (this.p > this.q) {
         int var3 = this.p;
         this.p = this.q;
         this.q = var3;
      }

      field_103.a(this.p, this.q);
      this.r = this.p + 8192;
      this.s = this.q - 8192;
      this.u = this.s + this.r >> 1;
      this.t = 1600;
   }

   public final void b() {
      field_105.a();
      this.a(true);
      this.field_121 = 0L;
      if (this.field_117 >= 0) {
         int var1 = class_5.method_20(this.field_117);
         this.field_120 = new int[var1];

         for (int var2 = 0; var2 < var1; var2++) {
            int var3 = class_5.a(this.field_117, var2, 0);
            int var5 = class_5.a(class_5.a(320, var3, 3), 3);
            this.field_120[var2] = var5;
         }
      }

      int var6 = class_19.method_145();
      field_103.a(var6);
      class_6.F = this.p;
      class_6.G = this.q;
   }

   private void a(class_21 var1, class_21 var2) {
      class_17 var3;
      (var3 = this.method_45()).a(var1, var2);
      var3.a();
   }

   public final void a(boolean var1) {
      class_6 var2;
      int var3 = class_19.method_161(var2 = class_19.method_143());
      int[][] var4 = var2.field_74;
      int var5;
      int var6;
      int var7;
      int var8;
      int var10000;
      int var10001;
      if (var2.method_29()) {
         int[] var10 = var4[0];
         int[] var11 = var4[1];
         int var12 = var10[0];
         int var13 = var10[1];
         int var14 = var11[0];
         int var15 = var11[1];
         var5 = var12 + var14 >> 1;
         var6 = var13 + var15 >> 1;
         var7 = 0;
         var8 = var2.x - var2.B;
         var10000 = var2.y;
         var10001 = var2.C;
      } else {
         class_21 var16;
         var5 = (var16 = field_103.method_53(var3)).field_278;
         var6 = var16.field_279;
         var7 = var16.field_280;
         var16 = field_103.method_55(var3);
         var8 = var5 - var16.field_278;
         var10000 = var6;
         var10001 = var16.field_279;
      }

      int var9 = var10000 - var10001;
      int var18 = var1 ? 1 : 0;
      if (var2.method_40()) {
         var18 |= 2;
      }

      if (var2.field_68) {
         var18 |= 32;
      }

      this.a(var5, var6, var7, var8, var9, var18);
   }

   public final void a(int[] var1) {
      var1[0] = this.l.field_278 << 5;
      var1[1] = this.l.field_279 << 5;
   }

   private void a(int var1, int var2, int var3, int var4, int var5, int var6) {
      var1 >>= 5;
      var2 >>= 5;
      var3 >>= 5;
      if ((var6 & 33) == 0) {
         var4 >>= 5;
         var5 >>= 5;
         var4 = class_18.method_137(var4 * 8000 >> 10, -4000, 4000);
         var5 = class_18.method_137(var5 * 8000 >> 10, -4000, 4000);
         var1 += var4;
         var2 += var5;
      }

      class_21 var7;
      label28: {
         this.l.a(var1, var2, var3);
         this.m.a(this.l);
         var7 = e;
         class_21 var10000;
         if ((var6 & 2) != 0) {
            var10000 = f;
         } else if ((var6 & 4) != 0) {
            var10000 = d;
         } else if ((var6 & 8) != 0) {
            var10000 = b;
         } else {
            if ((var6 & 16) == 0) {
               break label28;
            }

            var10000 = c;
         }

         var7 = var10000;
      }

      this.m.b(var7);
      if ((var6 & 1) == 0) {
         this.j.a(this.m, 950);
         this.k.a(this.l, 750);
      } else {
         this.j.a(this.m);
         this.k.a(this.l);
      }

      field_105.b();
      this.a(this.j, this.k);
   }

   // $VF: renamed from: a () int
   public final int method_46() {
      int var2 = class_19.method_161(class_19.method_143());
      return field_103.method_53(var2).field_278;
   }

   public final void c() {
      int var1 = class_19.method_145();

      for (int var2 = 0; var2 < var1; var2++) {
         class_6 var3;
         (var3 = class_19.method_148(var2)).d();
         if (var3.method_29()) {
            this.a(var3);
            this.d(var3);
            var3.e();
         } else {
            class_21 var4 = field_103.method_56(var2);
            a(0, var4.field_278, var4.field_279);
            var4 = field_103.method_53(var2);
            a(0, var4.field_278, var4.field_279);
            field_103.c(var2);
         }

         if (!var3.field_93) {
            this.a(var3, var2);
         }

         if (this.field_117 >= 0) {
            int var8;
            int var10000;
            if (var3.method_29()) {
               var8 = var3.x;
               var10000 = var3.y;
            } else {
               class_21 var6;
               var8 = (var6 = field_103.method_53(var2)).field_278;
               var10000 = var6.field_279;
            }

            int var5 = var10000;
            this.a(var3, var8, var5, this.field_117, this.field_120);
         }
      }
   }

   private void d(class_6 var1) {
      if (this.o >= 0) {
         int var2 = class_5.method_20(this.o);
         int[] var3 = class_5.method_10(this.o);
         int var4 = var1.x;
         int var5 = var1.y;
         int var6 = var4 - var1.B;
         int var7 = var5 - var1.C;
         var4 >>= 5;
         var5 >>= 5;
         var6 >>= 5;
         var7 >>= 5;
         boolean var8 = var1.method_38();
         int var9 = var1.field_84 - 9;
         boolean var10 = !var8 && var9 >= 0 && var9 < 5;
         int var11 = 0;

         for (int var12 = 0; var12 < var2; var12++) {
            label52: {
               int var13 = 1 << var12;
               class_6 var10000;
               int var10001;
               if ((var1.field_87 & var13) != 0) {
                  if (!var8) {
                     int var14 = var3[0 + var11];
                     int var15 = var3[1 + var11];
                     int var16 = var3[3 + var11];
                     int var17;
                     if ((var17 = (var4 * var14 + var5 * var15 >> 10) - var16) < -48) {
                        var17 = -48;
                     }

                     if (var17 > 48) {
                        var17 = 48;
                     }

                     int var25;
                     var14 = (var25 = var14 * var17) << 5 >> 10;
                     int var28;
                     var15 = (var28 = var15 * var17) << 5 >> 10;
                     var1.a(-var14, -var15);
                     break label52;
                  }

                  var10000 = var1;
                  var10001 = var1.field_87 & ~var13;
               } else {
                  if (!var10) {
                     break label52;
                  }

                  int var27 = var3[0 + var11];
                  int var30 = var3[1 + var11];
                  int var31 = var3[3 + var11];
                  int var32;
                  if ((var32 = (var4 * var27 + var5 * var30 >> 10) - var31) <= -1000 || var32 >= 1000) {
                     break label52;
                  }

                  int var18 = -var30;
                  int var19 = var27;
                  int var20;
                  if ((var20 = var18 * var6 + var19 * var7 >> 10) < 0) {
                     var20 = -var20;
                  }

                  if (var20 <= 180) {
                     break label52;
                  }

                  var10000 = var1;
                  var10001 = var1.field_87 | var13;
               }

               var10000.field_87 = var10001;
            }

            var11 += 4;
         }
      }
   }

   public final void a(class_6 var1) {
      var1.field_86 = a(var1.field_86, var1.x, var1.field_91[1]);
   }

   private static int a(int var0, int var1, int var2) {
      int var3 = 0;

      for (int var4 = 1; var4 < 2; var4++) {
         if (field_104[1].a((var0 & 2) != 0, var1, var2)) {
            var3 = 2;
         }
      }

      return var3;
   }

   public final void b(class_6 var1) {
      field_103.a(var1);
      class_19.a(var1);
   }

   public final void c(class_6 var1) {
      if (var1 == class_19.method_143()) {
         this.a(true);
      }
   }

   // $VF: renamed from: a (int) int
   public final int method_48(int var1) {
      int var2 = this.p;
      int var3 = this.q;
      var1 >>= 15;
      var2 >>= 15;
      var3 >>= 15;
      return (var1 - var2 << 10) / (var3 - var2);
   }

   public final int b(int var1) {
      return field_104[0].a(var1);
   }

   public final int a(class_21 var1, class_21 var2, class_21 var3, int var4, int var5) {
      a(var1);
      int var6 = a(var1, this.field_118, 0);

      for (int var7 = 0; var7 < 2; var7++) {
         int var8;
         if ((var8 = field_104[var7].a(var1, var3, var5)) < 0) {
            if (var4 != 0) {
               int var9 = var1.field_278 - var2.field_278;
               int var10 = var1.field_279 - var2.field_279;
               int var11 = var3.field_278;
               int var12 = var3.field_279;
               int var13 = (var9 * var11 + var10 * var12 >> 10) * var4 >> 10;
               var1.field_278 -= var11 * var13 >> 10;
               var1.field_279 -= var12 * var13 >> 10;
            }

            var6 += var8;
         }
      }

      return var6;
   }

   public final int a(int[] var1, int[] var2, int var3, int var4) {
      this.g.a(var1[0], var1[1], 0);
      this.h.a(var1[2], var1[3], 0);
      this.i.a(0, 0, 0);
      int var5;
      if ((var5 = this.a(this.g, this.h, this.i, var3, var4)) < 0) {
         var1[0] = this.g.field_278;
         var1[1] = this.g.field_279;
         var2[0] = this.i.field_278;
         var2[1] = this.i.field_279;
      }

      return var5;
   }

   private static int a(class_21 var0, int var1, int var2) {
      if (var1 < 0) {
         return 0;
      }

      int var3 = var0.field_278 >> 5;
      int var4 = var0.field_279 >> 5;
      int var5 = class_5.method_20(var1);
      int[] var6 = class_5.method_10(var1);
      int var7 = 0;
      int var8 = 0;

      for (int var9 = 0; var9 < var5; var9++) {
         int var10 = var6[var8 + 0];
         int var11 = var6[var8 + 1];
         int var12 = var6[var8 + 2];
         if (var2 == 0) {
            int[] var13 = class_5.method_10(var10);
            int var14 = var11 + var13[0];
            int var15 = var12 + var13[1];
            int var16 = var11 + var13[3];
            int var17 = var12 + var13[4];
            if (var3 >= var14 && var3 < var16 && var4 >= var15 && var4 < var17) {
               int var18 = var3 - var14;
               int var19 = var16 - var3;
               int var20 = var4 - var15;
               int var21 = var17 - var4;
               int var22 = var18 < var19 ? var18 : var19;
               int var23 = var20 < var21 ? var20 : var21;
               if (var22 < var23) {
                  var22 = (var22 == var18 ? -var22 : var22) << 5;
                  var0.field_278 += var22;
                  var7 = var22 > 0 ? -var22 : var22;
               } else {
                  var23 = (var23 == var20 ? -var23 : var23) << 5;
                  var0.field_279 += var23;
                  var7 = var23 > 0 ? -var23 : var23;
               }

               var7 >>= 5;
            }
         }

         var8 += 4;
      }

      return var7;
   }

   private static void a(class_21 var0) {
      int var1 = var0.field_280;
      char var2 = '耀';
      class_21 var10000;
      int var10001;
      if (var1 < -32768) {
         var10000 = var0;
         var10001 = var0.field_280 - ((var1 - var2) * 32 >> 10);
      } else {
         if (var1 <= var2) {
            return;
         }

         var10000 = var0;
         var10001 = var0.field_280 + ((var2 - var1) * 32 >> 10);
      }

      var10000.field_280 = var10001;
   }

   private void a(int var1, class_20 var2) {
      this.a(var1, var2, 0L);
   }

   private void a(int var1, class_20 var2, long var3) {
      if (var1 >= 0) {
         int[] var5 = class_5.method_10(var1);
         int var6 = class_5.method_20(var1);
         int var7 = 0;
         this.field_101.a(class_20.field_275);
         if (var2 != null) {
            this.field_101.b(var2);
         }

         for (int var8 = 0; var8 < var6; var8++) {
            if (var3 == 0L || (var3 & 1L << var8) == 0L) {
               int var9 = var5[0 + var7];
               this.n.a(var5, 1 + var7);
               this.a(var9, this.field_101, this.n);
            }

            var7 += 4;
         }
      }
   }

   // $VF: renamed from: c (int) void
   private void method_50(int var1) {
      if (var1 >= 0) {
         int[] var2 = class_5.method_10(var1);
         int var3 = class_5.method_20(var1);
         int var4 = 0;

         for (int var5 = 0; var5 < var3; var5++) {
            int var6 = var2[0 + var4];
            this.n.a(var2, 1 + var4);
            this.field_101.a(var2, 4 + var4);
            this.a(var6, this.field_101, this.n);
            var4 += 13;
         }
      }
   }

   private void d(int var1) {
      this.e(var1);
   }

   private void a(int var1, class_6 var2) {
      class_20 var3 = field_103.method_54(var1);
      int var4 = var2.field_93 ? 22 : 21;
      this.a(var4, var3, field_103.method_57(var1, false));
      this.a(var4, var3, field_103.method_57(var1, true));
   }

   private void b(int var1, class_6 var2) {
      int var3 = var2.e;
      int var4 = var2.field_83[3];
      class_21 var5 = field_103.d(var1);
      class_20 var6 = field_103.a(var1, false);
      this.a(var4, var6, var5);

      for (int var7 = 0; var7 < 8; var7++) {
         int var8 = class_5.a(578, var7, 2);
         int var9;
         if ((var9 = class_5.a(576, var3, var8)) >= 0) {
            this.g.a(field_103.method_51(var1, var7));
            this.g.field_279 += 2500;
            this.g.c(5);
            class_20 var10 = field_103.method_52(var1, var7);
            this.a(var9, var10, this.g);
         }
      }
   }

   public final void a(int var1, int var2, int var3, int var4, int var5, int var6, boolean var7) {
      this.b(var1, var2, var3, var4, var5, var6, var7);
   }

   private void a(class_6 var1, int var2, int var3, int var4, int[] var5) {
      int var6 = var2 >> 5;
      int var7 = var3 >> 5;
      long var8 = var1.field_85;
      int[] var10 = class_5.method_10(var4);
      int var11 = class_5.method_20(var4);
      int var12 = 0;

      for (int var13 = 0; var13 < var11; var13++) {
         long var14 = 1L << var13;
         if ((var8 & var14) == 0L) {
            int var16 = var5[var13];
            int var17 = var10[1 + var12];
            int var18 = var10[2 + var12];
            long var19 = var6 - var17;
            long var21 = var7 - var18;
            if (var19 * var19 + var21 * var21 >> 10 < var16 + 1024) {
               int var25 = var10[0 + var12];
               int var26 = 0;
               int var27;
               if ((var27 = class_5.b(574, 2, var25)) >= 0) {
                  var26 = class_5.a(574, var27, 3);
               }

               var8 |= var14;
               if (class_19.a(var1, var26)) {
                  this.field_121 |= var14;
                  field_105.a(4, var17, var18, 0, 0, 512, 0);
               }
            }
         }

         var12 += 4;
      }

      var1.field_85 = var8;
   }

   private void e(int var1) {
      class_21 var2 = field_103.d(var1);
      class_20 var3 = field_103.a(var1, true);
      this.a(var2, var3, 27, field_122);
      if (!class_19.method_148(var1).method_29()) {
         class_21 var4;
         (var4 = class_21.g).a(field_103.method_53(var1));
         var4.c(5);
         this.a(var4, class_20.field_275, 20, null);
      }
   }

   private void a(class_21 var1, class_20 var2, int var3, int[] var4) {
      class_4 var5;
      int var6 = (var5 = field_104[0]).a(var1.field_278 << 5) >> 5;
      int var7 = var1.field_279 - var6;
      this.g.a(var1);
      this.g.field_278 += var7;
      this.g.b(a);
      int var8 = var5.a(this.g.field_278 << 5) >> 5;
      int var9;
      int var10 = class_5.method_20(var9 = class_5.a(320, var3, 2));
      int[] var11 = class_5.method_10(var9);
      if (var4 != null) {
         var2.a(var4, 0, var11, 0, var10, 3);
      }

      int var12 = 0;
      int var13 = this.g.field_278;

      for (int var14 = 0; var14 < var10; var14++) {
         int var15 = var13 + var11[var12] << 5;
         int var16 = (var5.a(var15) >> 5) - var8;
         var11[var12 + 1] = var16;
         var12 += 3;
      }

      this.g.field_279 = var8;
      this.b(var3, class_20.field_275, this.g);
   }

   private void a(class_6 var1, int var2) {
      if (var1.method_29()) {
         a(var1.field_64, var1.field_74);
      } else {
         field_103.a(this, var2);
      }
   }

   private static void a(byte[] var0, int[][] var1) {
      int var2 = var0.length;

      for (int var3 = 0; var3 < var2; var3++) {
         byte var4;
         if ((var4 = var0[var3]) != 0) {
            int[] var5 = var1[var3];
            int var6 = var5[0] >> 5;
            int var7 = var5[1] >> 5;
            int var9 = var5[2] >> 5;
            int var10 = var5[3] >> 5;
            int var11 = var6 - var9;
            int var12 = var7 - var10;
            field_105.a(var4, var6, var7, 0, var11, var12, 0);
         }

         var0[var3] = 0;
      }
   }

   public final void a(byte[] var1, class_21[] var2, class_21[] var3) {
      int var4 = var1.length;

      for (int var5 = 0; var5 < var4; var5++) {
         byte var6;
         if ((var6 = var1[var5]) != 0) {
            class_21 var7 = var2[var5];
            class_21 var8 = var3[var5];
            int var9 = var7.field_278 >> 5;
            int var10 = var7.field_279 >> 5;
            int var12 = var8.field_278 >> 5;
            int var13 = var8.field_279 >> 5;
            int var14 = var9 - var12;
            int var15 = var10 - var13;
            field_105.a(var6, var9, var10, 0, var14, var15, 0);
         }

         var1[var5] = 0;
      }
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Graphics, int) boolean
   public final boolean method_47(Graphics var1, int var2) {
      int var3 = var1.getTranslateX();
      int var4 = var1.getTranslateY();
      var1.translate(-var3, -var4);
      int var5 = 4;
      if (this.field_106 != var2 || this.field_124) {
         this.field_124 = false;
         this.method_49(var2);
         var5 = 5;
      }

      this.a(this.u, field_104[0].a(this.u), 0, 0, 0, var5);
      this.u = this.u + this.t;
      if (this.u < this.r) {
         this.t *= -1;
      }

      if (this.u > this.s) {
         this.t *= -1;
      }

      this.a(var1, true);
      var1.translate(var3, var4);
      return true;
   }

   public final int c(int var1) {
      int var2;
      return (var2 = class_5.a(570, this.field_106, 3)) < 0 ? 0 : class_5.a(var2, var1, 0) << 5;
   }

   public final void b(boolean var1) {
      if (var1) {
         this.a(true);
      }
   }

   public final void d() {
      this.field_124 = true;
   }
}
