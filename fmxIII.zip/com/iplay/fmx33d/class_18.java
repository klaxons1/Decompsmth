package com.iplay.fmx33d;

import java.util.Random;
import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Font;
import javax.microedition.lcdui.Graphics;
import javax.microedition.midlet.MIDlet;

// $VF: renamed from: s
public final class class_18 implements Runnable {
   public static final int MBOOSTER_MAX_INSTANCES = 0;
   public static volatile boolean a;
   private static int d;
   private static long b;
   // $VF: renamed from: a int
   public static int field_230;
   // $VF: renamed from: b int
   public static int field_231;
   // $VF: renamed from: d boolean
   private static boolean field_232;
   private static int e;
   private static int f;
   private static int g;
   // $VF: renamed from: a javax.microedition.lcdui.Canvas
   private static Canvas field_233;
   // $VF: renamed from: a javax.microedition.lcdui.Graphics
   private static Graphics field_234;
   // $VF: renamed from: a javax.microedition.lcdui.Font
   public static final Font field_235 = Font.getFont(64, 1, 16);
   // $VF: renamed from: b javax.microedition.lcdui.Font
   public static final Font field_236 = Font.getFont(64, 1, 0);
   public static final Font c = Font.getFont(64, 0, 8);
   private static int h;
   // $VF: renamed from: c int
   public static int field_237 = 0;
   // $VF: renamed from: a byte[][]
   public static byte[][] field_238;
   private static int i = -1;
   private static int j = -1;
   // $VF: renamed from: d javax.microedition.lcdui.Font
   private static Font field_239 = c;
   // $VF: renamed from: b boolean
   public static boolean field_240;
   // $VF: renamed from: c boolean
   public static boolean field_241;
   // $VF: renamed from: a int[][]
   private static final int[][] field_242 = new int[8][4];
   private static int k = -1;
   // $VF: renamed from: a long
   public static long field_243;
   // $VF: renamed from: c long
   private static long field_244;
   // $VF: renamed from: d long
   private static long field_245;
   private static int l = 16;
   // $VF: renamed from: a java.lang.String
   private static String field_246;
   // $VF: renamed from: b java.lang.String
   private static String field_247;
   private static int m;
   private static int n;
   // $VF: renamed from: a int[]
   private static final int[] field_248 = new int[]{65536, 128, 32, 32};
   private static int o;
   // $VF: renamed from: e long
   private static long field_249;
   // $VF: renamed from: f long
   private static long field_250;
   // $VF: renamed from: g long
   private static long field_251;
   // $VF: renamed from: e boolean
   private static boolean field_252;
   // $VF: renamed from: a java.util.Random
   private static Random field_253;

   public static final void a(int var0, int var1) {
      if (var0 != field_230 || var1 != field_231) {
         b(var0, var1);
         field_232 = true;
      }
   }

   public static final void b(int var0, int var1) {
      if (!field_232) {
         field_230 = var0;
         field_231 = var1;
      }
   }

   public static final void a(MIDlet var0) {
      field_233 = (Canvas)(new class_13());
      Display.getDisplay(var0).setCurrent((Displayable)field_233);
   }

   public static final void a() {
      l();
      class_11.a();
   }

   private static final void h() {
      g = f;
      f = f & ~e;
      e = 0;
   }

   public static final void b() {
      h = 0;
      e = 0;
      f = 0;
      g = 0;
   }

   // $VF: renamed from: a () int
   public static final int method_112() {
      int var0 = h;
      h = 0;
      return var0;
   }

   // $VF: renamed from: b () int
   public static final int method_116() {
      return field_231 - (2 + a(field_239));
   }

   public static final void a(Graphics var0) {
      field_234 = var0;
      synchronized (var0) {
         i();
      }
   }

   private static void i() {
      k = -1;
      field_234.setClip(0, 0, field_230, field_231);

      try {
         class_15.a(field_234);
      } catch (Throwable var4) {
      }

      if (!field_240) {
         j();
      }

      long var0 = System.currentTimeMillis();
      if (a(3)) {
         if (--l == 0) {
            l = 16;
            int var2 = (int)(var0 - field_244);
            field_244 = var0;
            if ((var2 = var2 >> 4) > 0) {
               field_246 = Integer.toString(1024000 / var2 + 512 >> 10);
            }
         }

         if (field_246 != null) {
            field_234.setColor(-1);
            field_234.setFont(c);
            field_234.drawString(field_246, 2, 20, 20);
         }
      }

      a(var0);
      if (m > 0) {
         field_234.setColor(-16777216);
         field_234.fillRect(0, (field_231 >> 1) - 2, field_230, c.getHeight() + 4);
         field_234.setColor(-1);
         field_234.setFont(c);
         field_234.drawString(field_247, field_230 >> 1, field_231 >> 1, 17);
         m--;
      }

      d++;
      field_252 = false;
   }

   private static final void a(long var0) {
      if (((Displayable)field_233).isShown()) {
         long var2;
         if ((var2 = Math.abs(var0 - field_245)) < 800L) {
            b += var2;
         }

         field_245 = var0;
      }
   }

   private static void j() {
      if (i != -1) {
         byte var1;
         if ((var1 = field_238[i][2]) < 0) {
            int var0 = class_5.a(field_238[i], 0);
            a(field_234, field_239, -1, class_5.a(var0), 3, field_231 - 1 + 0, 36);
         } else {
            a(var1, 3, field_231 - 1, true, 36);
         }
      }

      if (j != -1) {
         byte var3;
         if ((var3 = field_238[j][2]) < 0) {
            int var2 = class_5.a(field_238[j], 0);
            a(field_234, field_239, -1, class_5.a(var2), field_230 - 3, field_231 - 1 + 0, 40);
            return;
         }

         a(var3, field_230 - 3, field_231 - 1, true, 40);
      }
   }

   public static final boolean a(int var0) {
      return (n & 1 << var0) != 0;
   }

   private static void a(String var0) {
      if (m <= 0) {
         field_247 = var0;
         m = 30;
         c();
         Thread.yield();
      }
   }

   // $VF: renamed from: a () long
   public static final long method_113() {
      return b;
   }

   private static void k() {
      if (!field_252) {
         try {
            h();
            class_15.c();
         } catch (Throwable var3) {
         }

         field_252 = true;
      }

      if (field_252) {
         c();
      }

      field_249 = System.currentTimeMillis();
      field_243 = Math.abs(field_249 - field_250);
      long var0 = class_15.method_77() == 2 ? 88L : 50L;
      field_251 = Math.max(2L, var0 - field_243);

      try {
         Thread.sleep(field_251);
      } catch (InterruptedException var2) {
      }

      field_250 = System.currentTimeMillis();
   }

   public static final void c() {
      field_233.repaint();
      field_233.serviceRepaints();
   }

   public static final void d() {
      a(System.currentTimeMillis());
   }

   // $VF: renamed from: a (int) void
   public static final void method_121(int var0) {
      int var1 = k(var0);
      if (class_15.method_77() != 0) {
         if (o == field_248.length) {
            for (int var2 = 0; var2 < 9; var2++) {
               if (var1 == (class_5.a(58, var2, 0) & 65535)) {
                  method_127(var2);
                  break;
               }
            }

            o = 0;
         }

         o = field_248[o] == var1 ? o + 1 : 0;
      }

      if (var1 != 0) {
         f |= var1;
      } else {
         if ((var0 != -6 || field_241) && (var0 != -7 || !field_241)) {
            if (var0 == -6 && field_241 || var0 == -7 && !field_241) {
               h |= 262144;
            }
         } else if (d - field_237 > 3) {
            h |= 131072;
            field_237 = d;
            return;
         }
      }
   }

   // $VF: renamed from: d (int) void
   private static void method_127(int var0) {
      short var1;
      label25: {
         var1 = -1;
         int var2 = 1 << var0;
         short var10000;
         if ((n & var2) != 0) {
            n &= ~var2;
            var10000 = 145;
         } else {
            int var3;
            if ((var3 = class_5.a(58, var0, 2)) != 0) {
               class_15.b(var3, var0);
               break label25;
            }

            if ((var3 = class_5.a(58, var0, 3)) != 0) {
               class_15.b(var3, var0);
            }

            n |= var2;
            var10000 = 144;
         }

         var1 = var10000;
      }

      int var5;
      if ((var5 = class_5.a(58, var0, 1)) != -1 && var1 != -1) {
         a(class_5.a(var5) + " " + class_5.a(var1));
         class_15.method_76();
      }
   }

   public static final void b(int var0) {
      e = e | k(var0);
   }

   // $VF: renamed from: b (int) boolean
   public static final boolean method_128(int var0) {
      return (g & var0) != 0;
   }

   // $VF: renamed from: h () boolean
   private static boolean method_115() {
      return (129 & g) != 0;
   }

   // $VF: renamed from: a () boolean
   public static final boolean method_114() {
      return (2050 & g) != 0;
   }

   // $VF: renamed from: i () boolean
   private static boolean method_118() {
      return (8196 & g) != 0;
   }

   // $VF: renamed from: b () boolean
   public static final boolean method_117() {
      return (520 & g) != 0;
   }

   // $VF: renamed from: j () boolean
   private static boolean method_120() {
      return (1040 & g) != 0;
   }

   public static final boolean c(int var0) {
      if (method_128(var0)) {
         f &= ~var0;
         return true;
      } else {
         return false;
      }
   }

   // $VF: renamed from: c () boolean
   public static final boolean method_123() {
      if (method_115()) {
         f &= -130;
         return true;
      } else {
         return false;
      }
   }

   // $VF: renamed from: d () boolean
   public static final boolean method_125() {
      if (method_118()) {
         f &= -8197;
         return true;
      } else {
         return false;
      }
   }

   public static final boolean e() {
      if (method_117()) {
         f &= -521;
         return true;
      } else {
         return false;
      }
   }

   public static final boolean f() {
      if (method_114()) {
         f &= -2051;
         return true;
      } else {
         return false;
      }
   }

   public static final boolean g() {
      if (method_120()) {
         f &= -1041;
         return true;
      } else {
         return false;
      }
   }

   private static final int j(int var0) {
      switch (var0) {
         case 35:
            return 65536;
         case 36:
         case 37:
         case 38:
         case 39:
         case 40:
         case 41:
         case 43:
         case 44:
         case 45:
         case 46:
         case 47:
         default:
            return 0;
         case 42:
            return 32768;
         case 48:
            return 32;
         case 49:
            return 64;
         case 50:
            return 128;
         case 51:
            return 256;
         case 52:
            return 512;
         case 53:
            return 1024;
         case 54:
            return 2048;
         case 55:
            return 4096;
         case 56:
            return 8192;
         case 57:
            return 16384;
      }
   }

   private static final int k(int var0) {
      int var1;
      if ((var1 = j(var0)) != 0) {
         return var1;
      }

      int var2 = var0;
      if (var0 != -6 && var2 != -7) {
         int var3 = 0;

         try {
            var3 = field_233.getGameAction(var0);
         } catch (Exception var5) {
         }

         switch (var3) {
            case 1:
               return 1;
            case 2:
               return 8;
            case 3:
            case 4:
            case 7:
            default:
               return 0;
            case 5:
               return 2;
            case 6:
               return 4;
            case 8:
               return 16;
         }
      } else {
         return 0;
      }
   }

   // $VF: renamed from: e () void
   public static final void method_132() {
      try {
         class_15.method_74();
      } catch (Exception var1) {
      }
   }

   public final void run() {
      a = true;
      b = field_245 = field_250 = System.currentTimeMillis();

      while (a) {
         k();
      }

      class_3.a.notifyDestroyed();
   }

   public static final int a(Font var0) {
      return class_11.a(var0);
   }

   public static final int a(String var0, int var1, int var2, Font var3) {
      return class_11.a(var3, var0, var1, var2);
   }

   public static final int a(char var0, Font var1) {
      return class_11.a(var1, var0);
   }

   public static final int a(String var0, Font var1) {
      return class_11.a(var1, var0);
   }

   public static final int a(int var0, Font var1) {
      return a(class_5.a(var0), var1);
   }

   public static final void c(int var0, int var1) {
      boolean var2;
      i = (var2 = field_241) ? var1 : var0;
      j = var2 ? var0 : var1;
   }

   // $VF: renamed from: c (int) void
   public static final void method_130(int var0) {
      field_234.setColor(var0);
      field_234.fillRect(field_234.getClipX(), field_234.getClipY(), field_234.getClipWidth(), field_234.getClipHeight());
   }

   public static final void a(int var0, int var1, int var2) {
      a(var0, var1, var2, 20);
   }

   public static final void a(int var0, int var1, int var2, int var3) {
      a(field_234, var0, var1, var2, true, var3);
   }

   private static void a(int var0, int var1, int var2, boolean var3, int var4) {
      a(field_234, var0, var1, var2, var3, var4);
   }

   private static void a(Graphics var0, int var1, int var2, int var3, boolean var4, int var5) {
      int var6;
      if ((var6 = class_5.method_7(var1)) == 1) {
         var0.drawImage(class_5.method_6(var1), var2, var3, var5);
      } else if (var6 == 4) {
         int var7 = class_5.method_15(var1);
         class_7.a(var0, class_5.method_10(var1), var2, var3, var7, class_5.method_20(var1), var7, var4, var5);
      } else if (var6 != 5) {
         ;
      }
   }

   public static final void a(Graphics var0, Font var1, int var2, String var3, int var4, int var5, int var6) {
      class_11.a(var0, var1, var2, var3, var4, var5, var6);
   }

   public static final void b(int var0, int var1, int var2, int var3) {
      method_139(field_234, var0, var1, var2, var3);
   }

   private static final void l() {
      byte[] var0 = class_5.method_8(41);

      for (int var1 = 0; var1 < 9; var1++) {
         int var2 = var1 * 5;
         byte var3;
         if ((var3 = var0[var2 + 0]) >= 0) {
            byte var4 = var0[var2 + 2];
            byte var5 = var0[var2 + 3];
            byte var6 = var0[var2 + 1];
            int var7 = class_5.method_15(var3);
            int var9 = class_5.method_20(var3) / var6;
            int var10 = var4 == -2 ? var7 >> 1 : (var4 == -3 ? var7 : var4);
            int var11 = var5 == -2 ? var9 >> 1 : (var5 == -5 ? var9 : var5);
            var0[var2 + 4] = (byte)var9;
            var0[var2 + 2] = (byte)var10;
            var0[var2 + 3] = (byte)var11;
         }
      }
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Graphics, int, int, int, int) void
   private static void method_139(Graphics var0, int var1, int var2, int var3, int var4) {
      byte[] var7 = class_5.method_8(41);
      int var8 = var1 * 5;
      byte var9 = var7[var8 + 0];
      byte var10 = var7[var8 + 2];
      byte var11 = var7[var8 + 3];
      byte var12 = var7[var8 + 4];
      int var13 = class_5.method_15(var9);
      var2 -= var10;
      var3 -= var11;
      if (var0 != field_234) {
         b(var0);
         if (a(var0, var2, var3, var13, var12)) {
            a(var0, var9, var2, var3 - var4 * var12, true, 20);
         }

         c(var0);
      } else {
         method_134();
         if (method_138(var2, var3, var13, var12)) {
            a(var9, var2, var3 - var4 * var12, 20);
         }

         method_135();
      }
   }

   // $VF: renamed from: a (int) int
   public static final int method_122(int var0) {
      return class_5.method_15(class_5.a(41, var0, 0));
   }

   // $VF: renamed from: b (int) int
   public static final int method_129(int var0) {
      return class_5.a(41, var0, 4);
   }

   private static final int l(int var0) {
      int var1 = 0;
      int var4 = var0;
      int var2 = 1073741824;

      do {
         int var3 = var1 + var2;
         var1 >>= 1;
         if (var3 <= var4) {
            var4 -= var3;
            var1 += var2;
         }
      } while ((var2 >>= 2) != 0);

      if (var1 < var4) {
         var1++;
      }

      return var1 << 5;
   }

   // $VF: renamed from: a (long) long
   public static final long method_119(long var0) {
      long var2 = 0L;
      long var8 = var0;
      long var4 = 1073741824L;

      do {
         long var6 = var2 + var4;
         var2 >>= 1;
         if (var6 <= var8) {
            var8 -= var6;
            var2 += var4;
         }
      } while ((var4 >>= 2) != 0L);

      if (var2 < var8) {
         var2++;
      }

      return var2 << 5;
   }

   // $VF: renamed from: c (int) int
   public static final int method_131(int var0) {
      return l(var0);
   }

   public static final int d(int var0) {
      if ((var0 = (var0 = var0 & 1023) & 1023) <= 256) {
         return class_5.a(7, var0);
      } else if (var0 <= 512) {
         return class_5.a(7, 512 - var0);
      } else {
         return var0 <= 768 ? -class_5.a(7, var0 - 512) : -class_5.a(7, 1024 - var0);
      }
   }

   public static final int e(int var0) {
      return d(var0 + 256);
   }

   // $VF: renamed from: a (int, int) int
   public static final int method_110(int var0, int var1) {
      if (field_253 == null) {
         field_253 = new Random();
      }

      if (var1 == var0) {
         return var0;
      }

      int var2;
      var2 = (var2 = field_253.nextInt()) < 0 ? -var2 : var2;
      int var3 = var1 - var0;
      return var0 + var2 % var3;
   }

   // $VF: renamed from: b (int, int) int
   public static final int method_111(int var0, int var1) {
      long var2 = var0;
      long var4 = var1;
      return method_131((int)(var2 * var2 + var4 * var4 >> 10));
   }

   // $VF: renamed from: c (int, int) int
   public static final int method_136(int var0, int var1) {
      long var2 = var0;
      long var4 = var1;
      int var6;
      if ((var6 = (int)(var2 * var2 + var4 * var4 >> 10)) == 0) {
         return 1;
      } else {
         return method_131(var6) > 0 ? 1048576 / method_131(var6) : d(var0, var1);
      }
   }

   private static int d(int var0, int var1) {
      if (var0 < 0) {
         var0 = -var0;
      }

      if (var1 < 0) {
         var1 = -var1;
      }

      int var2;
      int var10000;
      if (var0 < var1) {
         var2 = var0;
         var10000 = var1;
      } else {
         var2 = var1;
         var10000 = var0;
      }

      int var3 = var10000;
      int var4 = var10000 * 1007 + var2 * 441;
      if (var3 < var2 << 4) {
         var4 -= var3 * 40;
      }

      return 1048576 / (var4 + 512 >> 10);
   }

   public static final int f(int var0) {
      int var1;
      int var2;
      int var3;
      int var4;
      return (
               var4 = (var3 = ((var2 = ((var1 = var0 - (var0 >>> 1 & 1431655765)) >>> 2 & 858993459) + (var1 & 858993459)) >>> 4) + var2 & 252645135)
                  + (var3 >>> 8)
            )
            + (var4 >>> 16)
         & 63;
   }

   // $VF: renamed from: a (int, int, int) int
   public static final int method_137(int var0, int var1, int var2) {
      if (var0 < var1) {
         return var1;
      } else {
         return var0 > var2 ? var2 : var0;
      }
   }

   public static final int g(int var0) {
      return var0 / 60000;
   }

   public static final int h(int var0) {
      return var0 % 60000 / 1000;
   }

   public static final int i(int var0) {
      return var0 % 1000 / 10;
   }

   // $VF: renamed from: c () int
   public static final int method_124() {
      return d;
   }

   // $VF: renamed from: d () int
   public static final int method_126() {
      return field_230;
   }

   // $VF: renamed from: e () int
   public static final int method_133() {
      return field_231;
   }

   // $VF: renamed from: f () void
   public static final void method_134() {
      b(field_234);
   }

   public static final void b(Graphics var0) {
      int[] var1 = field_242[++k];
      int var2 = var0.getClipX();
      int var3 = var0.getClipY();
      var1[0] = var2;
      var1[2] = var2 + var0.getClipWidth();
      var1[1] = var3;
      var1[3] = var3 + var0.getClipHeight();
   }

   // $VF: renamed from: a (int, int, int, int) boolean
   public static final boolean method_138(int var0, int var1, int var2, int var3) {
      return a(field_234, var0, var1, var2, var3);
   }

   public static final boolean a(Graphics var0, int var1, int var2, int var3, int var4) {
      int[] var5 = field_242[k];
      int var6 = var5[0];
      int var7 = var5[1];
      int var8 = var5[2];
      int var9 = var5[3];
      int var10 = var1 + var3;
      int var11 = var2 + var4;
      if (var6 < var1) {
         var6 = var1;
      }

      if (var7 < var2) {
         var7 = var2;
      }

      if (var8 > var10) {
         var8 = var10;
      }

      if (var9 > var11) {
         var9 = var11;
      }

      if (var8 > var6 && var9 > var7) {
         var0.setClip(var6, var7, var8 - var6, var9 - var7);
         return true;
      } else {
         return false;
      }
   }

   // $VF: renamed from: g () void
   public static final void method_135() {
      c(field_234);
   }

   public static final void c(Graphics var0) {
      a(var0, field_242[k--]);
   }

   private static void a(Graphics var0, int[] var1) {
      int var2 = var1[0];
      int var3 = var1[1];
      int var4 = var1[2];
      int var5 = var1[3];
      var0.setClip(var2, var3, var4 - var2, var5 - var3);
   }
}
