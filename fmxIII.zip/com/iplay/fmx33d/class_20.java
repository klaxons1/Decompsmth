package com.iplay.fmx33d;

// $VF: renamed from: u
public final class class_20 {
   public class_21 a;
   public class_21 b;
   public class_21 c;
   // $VF: renamed from: a u
   public static final class_20 field_275 = new class_20();
   // $VF: renamed from: b u
   public static final class_20 field_276 = new class_20();
   // $VF: renamed from: c u
   private static final class_20 field_277 = new class_20();

   public class_20() {
      this.a = new class_21(class_21.b);
      this.b = new class_21(class_21.c);
      this.c = new class_21(class_21.d);
   }

   public final void a() {
      this.a.a(class_21.b);
      this.b.a(class_21.c);
      this.c.a(class_21.d);
   }

   public final String toString() {
      return null;
   }

   public final void a(class_21 var1, class_21 var2, class_21 var3) {
      this.a.a(var1);
      this.b.a(var2);
      this.c.a(var3);
   }

   public final void a(class_21 var1, class_21 var2, class_21 var3, class_21 var4) {
      this.a.a(var2, var1);
      this.b.a(var3, var1);
      this.c.a(var4, var1);
   }

   public final void a(class_20 var1) {
      this.a.a(var1.a);
      this.b.a(var1.b);
      this.c.a(var1.c);
   }

   public final void a(int[] var1, int var2) {
      this.a.field_278 = var1[var2++];
      this.a.field_279 = var1[var2++];
      this.a.field_280 = var1[var2++];
      this.b.field_278 = var1[var2++];
      this.b.field_279 = var1[var2++];
      this.b.field_280 = var1[var2++];
      this.c.field_278 = var1[var2++];
      this.c.field_279 = var1[var2++];
      this.c.field_280 = var1[var2];
   }

   public final void b(class_21 var1, class_21 var2, class_21 var3) {
      this.b.a(var2);
      this.c.a(var3, var1);
      int var4;
      if ((var4 = this.c.method_167()) > 2048) {
         var4 >>= 4;
      }

      this.c.field_278 <<= 10;
      this.c.field_278 /= var4;
      this.c.field_279 <<= 10;
      this.c.field_279 /= var4;
      this.c.field_280 <<= 10;
      this.c.field_280 /= var4;
      this.a.b(this.b, this.c);
      this.b.b(this.c, this.a);
      this.a.a();
      this.b.a();
      this.c.a();
   }

   public final void a(int var1, int var2) {
      this.a.field_278 = var1;
      this.a.field_279 = 0;
      this.a.field_280 = -var2;
      this.b.a(class_21.c);
      this.c.field_278 = var2;
      this.c.field_279 = 0;
      this.c.field_280 = var1;
   }

   public final void b(int var1, int var2) {
      this.a.field_278 = var1;
      this.a.field_279 = var2;
      this.a.field_280 = 0;
      this.b.field_278 = -var2;
      this.b.field_279 = var1;
      this.b.field_280 = 0;
      this.c.a(class_21.d);
   }

   public final void b() {
      long var1 = this.c.field_278;
      long var3 = this.c.field_279;
      long var5 = this.c.field_280;
      long var7 = this.a.field_278;
      long var9 = this.a.field_279;
      long var11 = this.a.field_280;
      long var13 = var3 * var11 - var5 * var9 >> 10;
      long var15 = var5 * var7 - var1 * var11 >> 10;
      long var17 = var1 * var9 - var3 * var7 >> 10;
      long var19 = var9 * var17 - var11 * var15 >> 10;
      long var21 = var11 * var13 - var7 * var17 >> 10;
      long var23 = var7 * var15 - var9 * var13 >> 10;
      this.a.a();
      long var25 = class_18.method_119(var13 * var13 + var15 * var15 + var17 * var17 >> 10);
      this.b.field_278 = (int)((var13 << 10) / var25);
      this.b.field_279 = (int)((var15 << 10) / var25);
      this.b.field_280 = (int)((var17 << 10) / var25);
      var25 = class_18.method_119(var19 * var19 + var21 * var21 + var23 * var23 >> 10);
      this.c.field_278 = (int)((var19 << 10) / var25);
      this.c.field_279 = (int)((var21 << 10) / var25);
      this.c.field_280 = (int)((var23 << 10) / var25);
   }

   public final void a(int[] var1, int var2, int[] var3, int var4, int var5, int var6) {
      int var10 = var6 - 3;
      int var11 = this.a.field_278;
      int var12 = this.a.field_279;
      int var13 = this.a.field_280;
      int var14 = this.b.field_278;
      int var15 = this.b.field_279;
      int var16 = this.b.field_280;
      int var17 = this.c.field_278;
      int var18 = this.c.field_279;
      int var19 = this.c.field_280;

      for (int var20 = 0; var20 < var5; var20++) {
         int var7 = var1[var2++];
         int var8 = var1[var2++];
         int var9 = var1[var2++];
         var2 += var10;
         var3[var4++] = var7 * var11 + var8 * var14 + var9 * var17 >> 10;
         var3[var4++] = var7 * var12 + var8 * var15 + var9 * var18 >> 10;
         var3[var4++] = var7 * var13 + var8 * var16 + var9 * var19 >> 10;
         var4 += var10;
      }
   }

   public final void a(class_21 var1) {
      int var2 = var1.field_278;
      int var3 = var1.field_279;
      int var4 = var1.field_280;
      var1.field_278 = var2 * this.a.field_278 + var3 * this.b.field_278 + var4 * this.c.field_278 >> 10;
      var1.field_279 = var2 * this.a.field_279 + var3 * this.b.field_279 + var4 * this.c.field_279 >> 10;
      var1.field_280 = var2 * this.a.field_280 + var3 * this.b.field_280 + var4 * this.c.field_280 >> 10;
   }

   public final void b(class_21 var1) {
      int var2 = var1.field_278;
      int var3 = var1.field_279;
      int var4 = var1.field_280;
      var1.field_278 = var2 * this.a.field_278 + var3 * this.a.field_279 + var4 * this.a.field_280 >> 10;
      var1.field_279 = var2 * this.b.field_278 + var3 * this.b.field_279 + var4 * this.b.field_280 >> 10;
      var1.field_280 = var2 * this.c.field_278 + var3 * this.c.field_279 + var4 * this.c.field_280 >> 10;
   }

   public final void a(class_21 var1, class_21 var2) {
      int var3 = var1.field_278;
      int var4 = var1.field_279;
      int var5 = var1.field_280;
      var1.field_278 = (var3 * this.a.field_278 + var4 * this.b.field_278 + var5 * this.c.field_278 >> 10) + var2.field_278;
      var1.field_279 = (var3 * this.a.field_279 + var4 * this.b.field_279 + var5 * this.c.field_279 >> 10) + var2.field_279;
      var1.field_280 = (var3 * this.a.field_280 + var4 * this.b.field_280 + var5 * this.c.field_280 >> 10) + var2.field_280;
   }

   public final void b(class_20 var1) {
      var1.a(this.a);
      var1.a(this.b);
      var1.a(this.c);
   }

   public final void c(class_20 var1) {
      field_277.a(var1);
      field_277.b(this);
      this.a(field_277);
   }
}
