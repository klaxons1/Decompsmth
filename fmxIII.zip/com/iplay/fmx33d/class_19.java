package com.iplay.fmx33d;

import javax.microedition.lcdui.Graphics;

// $VF: renamed from: t
public final class class_19 {
   public static final int MBOOSTER_MAX_INSTANCES = 0;
   public static int a;
   private static boolean b = true;
   // $VF: renamed from: b int
   private static int field_254;
   private static boolean c;
   private static boolean d;
   private static boolean e;
   private static boolean f;
   private static boolean g;
   // $VF: renamed from: c int
   private static int field_255;
   // $VF: renamed from: d int
   private static int field_256;
   // $VF: renamed from: e int
   private static int field_257;
   // $VF: renamed from: f int
   private static int field_258;
   // $VF: renamed from: g int
   private static int field_259;
   private static int h;
   private static int i;
   private static int j;
   private static int k;
   private static int l;
   // $VF: renamed from: h boolean
   private static boolean field_260;
   private static int m;
   private static int n;
   // $VF: renamed from: a f[]
   private static final class_6[] field_261 = new class_6[2];
   // $VF: renamed from: a h
   private static class_8 field_262;
   private static int o;
   // $VF: renamed from: a java.lang.String[]
   private static String[] field_263;
   // $VF: renamed from: a byte[]
   private static byte[] field_264;
   // $VF: renamed from: b int[]
   private static final int[] field_265 = new int[6];
   // $VF: renamed from: c int[]
   private static final int[] field_266 = new int[6];
   // $VF: renamed from: a int[]
   public static final int[] field_267 = new int[14];
   private static int p;
   // $VF: renamed from: a boolean
   public static boolean field_268;
   // $VF: renamed from: d int[]
   private static final int[] field_269 = new int[2];
   // $VF: renamed from: i boolean
   private static boolean field_270;
   // $VF: renamed from: j boolean
   private static boolean field_271;
   // $VF: renamed from: k boolean
   private static boolean field_272;
   // $VF: renamed from: b byte[]
   private static byte[] field_273;
   // $VF: renamed from: c byte[]
   private static byte[] field_274;
   private static int q;
   private static int r;
   private static int s;
   private static int t;
   private static int u;
   private static int v;
   private static int w;
   private static int x = -1;

   private class_19() {
   }

   // $VF: renamed from: a () boolean
   private static boolean method_140() {
      return !b;
   }

   // $VF: renamed from: b () boolean
   private static boolean method_144() {
      return e;
   }

   public static final boolean a(int var0) {
      switch (var0) {
         case 12:
         case 16:
         case 17:
            return false;
         default:
            return true;
      }
   }

   public static final class_8 a() {
      return field_262;
   }

   public static final void a(Graphics var0) {
      class_18.b(var0);
      field_262.a(var0);
      if (b) {
         a(var0, class_5.a(233), class_18.method_126() >> 1, class_18.method_133() >> 1, 17);
      }

      class_18.c(var0);
      a(var0, field_261[0]);
      b(var0);
      if (class_18.a(7)) {
         class_6 var1;
         int var2 = (var1 = method_143()).t >> 10;
         int var3 = var1.u >> 10;
         String var4;
         int var5 = class_18.a(var4 = var2 + ", " + var3, class_18.c) + 2;
         var0.setFont(class_18.c);
         var0.setColor(0);
         var0.fillRect(0, 0, var5, class_18.c.getHeight());
         var0.setColor(-1);
         var0.drawString(var4, 1, 0, 0);
      }

      d = true;
   }

   private static void a(Graphics var0, int var1, int var2, int var3) {
      int var4 = class_5.method_15(11);
      int var5 = 0;
      int var6 = var1 - var4;
      int[] var7 = class_5.method_10(11);

      for (int var8 = var6; var8 < var1; var8++) {
         int var9;
         if ((var9 = var7[var5++]) != 0) {
            var0.setColor(var9);
            var0.drawLine(var8, var2, var8, var3);
         }
      }
   }

   private static final void b(Graphics var0) {
      int var1 = class_18.method_133() - 24 - 2;
      int var2 = class_18.a(class_18.c);
      int var3 = class_18.method_126() - 2;
      int var4 = var1 - var2;

      for (int var5 = 15; var5 >= 0; var5--) {
         if (field_264[var5] > 0) {
            a(var0, field_263[var5], var3, var4, 24);
            byte[] var10000 = field_264;
            var10000[var5] = (byte)(var10000[var5] - 2);
            var4 -= var2 + 2;
         }
      }
   }

   public static final void a(class_6 var0) {
      if (var0 == field_261[0]) {
         class_15.b(64);
         d(false);
      }
   }

   public static final boolean a(class_6 var0, int var1) {
      class_6 var10000;
      int var10001;
      switch (var1) {
         case 0:
         default:
            return var0 == field_261[0];
         case 1:
            var0.field_66++;
            var0.H += 16;
            return var0 == field_261[0];
         case 2:
            var0.b();
            if (var0 == field_261[0]) {
               j();
            }

            return var0 == field_261[0];
         case 3:
            var10000 = var0;
            var10001 = 1;
            break;
         case 4:
            var10000 = var0;
            var10001 = 2;
            break;
         case 5:
            var10000 = var0;
            var10001 = 0;
            break;
         case 6:
            var10000 = var0;
            var10001 = 3;
      }

      var10000.d(var10001);
      return var0 == field_261[0];
   }

   // $VF: renamed from: a (int) int
   private static int method_146(int var0) {
      q = Integer.MIN_VALUE;
      if (var0 < 0) {
         return 0;
      }

      int var1 = class_5.method_20(var0);
      int var2 = class_5.method_20(574);
      int var3 = 0;

      for (int var4 = 0; var4 < var1; var4++) {
         int var5 = class_5.a(var0, var4, 0);

         for (int var6 = 0; var6 < var2; var6++) {
            if (var5 == class_5.a(574, var6, 2)) {
               int var7;
               if ((var7 = class_5.a(574, var6, 3)) == 1) {
                  var3++;
               }

               if (var7 == 2) {
                  q = class_5.a(var0, var4, 1) << 5;
               }
            }
         }
      }

      return var3;
   }

   // $VF: renamed from: a (int) void
   private static final void method_147(int var0) {
      p |= var0;
   }

   public static final boolean b(int var0) {
      return var0 == 3 || var0 == 5 && class_15.method_89(17, -1);
   }

   public static final void a(int var0, int var1) {
      int var2 = var1 < 0 ? 7 : 6;
      if (var0 == 3) {
         class_15.method_93(var0, 2);
         class_15.b(var2, 5);
      }

      if (var0 == 5 && class_15.method_89(17, -1)) {
         class_15.method_93(var0, 2);
         class_15.b(var2, 3);
      }
   }

   private static void a(Graphics var0, class_6 var1, int var2) {
      if (var1.field_100) {
         int var3 = 0;

         while (true) {
            if (var3 >= 5) {
               return;
            }

            int var4;
            if ((var4 = var1.method_32(var3)) > 0) {
               a(var0, class_18.method_126() >> 1, var2, class_6.field_99[var3][0], var4, class_6.field_99[var3][1]);
               break;
            }

            var3++;
         }
      } else {
         Graphics var10000;
         int var10001;
         int var10002;
         int var10003;
         int var10004;
         byte var10005;
         if (var1.I != 0 && var1.I > -15) {
            var10000 = var0;
            var10001 = class_18.method_126() >> 1;
            var10002 = var2;
            var10003 = 160;
            var10004 = 15 + var1.I;
            var10005 = 15;
         } else if (var1.J > 15) {
            var10000 = var0;
            var10001 = class_18.method_126() >> 1;
            var10002 = var2;
            var10003 = 48;
            var10004 = var1.J;
            var10005 = 35;
         } else if (var1.K > 15) {
            var10000 = var0;
            var10001 = class_18.method_126() >> 1;
            var10002 = var2;
            var10003 = 49;
            var10004 = var1.K;
            var10005 = 30;
         } else {
            int var5;
            int var6;
            if ((var5 = var1.j) < 0 || (var6 = class_5.a(562, var5, 0)) == -1) {
               return;
            }

            var10000 = var0;
            var10001 = class_18.method_126() >> 1;
            var10002 = var2;
            var10003 = var6;
            var10004 = 0;
            var10005 = -1;
         }

         a(var10000, var10001, var10002, var10003, var10004, var10005);
      }
   }

   private static void a(class_6 var0, int var1, int var2) {
      if (!var0.method_35() || (a & 1) == 0) {
         int var3 = var0.field_63;
         int var4 = var0.c;
         int var5 = var0.d;
         int var6 = class_18.method_122(8);
         var1 += var6 >> 1;

         for (int var7 = 0; var7 < var4; var7++) {
            class_18.b(8, var1, var2, 1);
            var1 += var6 + 1;
         }

         for (int var9 = 0; var9 < var3; var9++) {
            class_18.b(8, var1, var2, 0);
            var1 += var6 + 1;
         }

         for (int var10 = 0; var10 < var5; var10++) {
            class_18.b(8, var1, var2, 2);
            var1 += var6 + 1;
         }
      }
   }

   private static final void a(Graphics var0, int var1, int var2, int var3, int var4, int var5) {
      if (var3 != -1) {
         String var6;
         int var7 = class_18.a(var6 = class_5.a(var3), class_18.c);
         a(var0, var6, var1, var2, 17);
         var2 += class_18.a(class_18.c) + 2;
         if (var4 <= var5) {
            int var8 = (var7 << 10) / var5;
            int var9 = var4 * var8 >> 10;
            var1 -= var7 >> 1;
            var0.setColor(-16119286);
            var0.fillRect(var1 + 1, var2 + 1, var7, 2);
            var0.setColor(-864252);
            var0.fillRect(var1, var2, var9, 2);
            return;
         }

         if (var5 != -1) {
            a(var0, String.valueOf(var4 - var5), var1, var2, 17);
         }
      }
   }

   private static final void a(Graphics var0, String var1, int var2, int var3, int var4) {
      class_15.a(var0, class_18.c, 16701443, var1, var2, var3, var4);
   }

   private static final void a(Graphics var0, class_6 var1) {
      c(var1);
      int var2 = class_18.a(class_18.c);
      class_16.a(var0);
      class_16.a(var0, var1);
      a(var0, var1, class_16.method_108());
      a(var1, class_16.b(), class_16.c());
      if (c()) {
         b(var0, class_16.method_108() + 2 * var2);
      }

      if (e && (a / 6 & 1) != 0) {
         class_18.a(34, class_18.method_126() - 4, 20, 24);
      }
   }

   private static final void b(Graphics var0, int var1) {
      var0.setColor(-11534336);
      int var2 = var1;
      var0.fillRect(0, var2, class_18.method_126(), class_18.a(class_18.c) + 2);
      class_15.a(var0, 16701443, var1);
   }

   // $VF: renamed from: b (int) int
   private static final int method_150(int var0) {
      return var0 * 1024 >> 10;
   }

   private static final void c(class_6 var0) {
      int var1 = method_150(var0.f) * 60;
      field_265[0] = class_18.g(var1);
      field_265[1] = class_18.h(var1);
      field_265[2] = class_18.i(var1);
      field_265[3] = var0.field_65;
      field_265[4] = m;
      field_265[5] = var0.field_66;
      int var3 = 0;

      for (int var4 = 0; var4 < 6; var4++) {
         int var5 = class_5.a(37, var4, 4);
         int var2;
         if ((var2 = field_265[var4]) != field_266[var4]) {
            field_266[var4] = var2;
            method_147(class_5.a(37, var4, 2));
            int var7 = class_5.a(37, var4, 5);
            var2 = var2 < var7 ? var2 : var7;
            int var8 = (var7 + 1) / 10;
            int var9 = var3;

            for (int var10 = 0; var10 < var5; var10++) {
               int var6 = var2 / var8;
               var2 -= var6 * var8;
               var8 /= 10;
               field_267[var9++] = var6;
            }
         }

         var3 += var5;
      }
   }

   // $VF: renamed from: a (f) int
   public static final int method_149(class_6 var0) {
      return c(field_262.method_48(var0.x));
   }

   // $VF: renamed from: a () int
   public static final int method_141() {
      return c(field_262.method_48(q));
   }

   private static final int c(int var0) {
      return class_18.method_137(var0 * 191 >> 10, 0, 191);
   }

   private static final boolean c() {
      return x >= 0;
   }

   // $VF: renamed from: a () void
   public static final void method_142() {
      method_159();
      if (field_254 >= 0) {
         if (field_254 == 0) {
            l();
         }

         field_254--;
      } else {
         if (c && d) {
            c = false;
            class_18.c(6, 20);
         }

         if (b) {
            if (class_18.c(1040)) {
               k();
               d(true);
            }
         } else {
            class_6 var0 = field_261[0];
            int var1 = 0;
            int var2 = d(var0);
            if (c()) {
               int var3 = class_5.a(573, x, 4);
               if ((1 << var2 & var3) != 0) {
                  var2 = -1;
               }
            }

            int var5 = method_154(var0);
            if (class_18.method_117()) {
               var1 = 16;
            }

            if (class_18.method_114()) {
               var1 = 32;
            }

            for (int var4 = 0; var4 < 2; var4++) {
               if (!e) {
                  if (var2 >= 0) {
                     var0.e(var2);
                     var2 = -1;
                  }

                  var0.c(var5);
                  var0.c(var1);
               }

               e();
            }
         }
      }
   }

   // $VF: renamed from: c (f) int
   private static int method_154(class_6 var0) {
      int var1 = 0;
      int var10000;
      if (class_15.a(5) != 0) {
         if (class_18.method_128(1040)) {
            var1 = 192;
            d(true);
            return var1;
         }

         if (class_18.c(1040)) {
            var1 = 128;
            d(!field_268);
            return var1;
         }

         if (class_18.method_128(8196)) {
            if (var0.method_38()) {
               var1 = 64;
            }

            d(false);
            return var1;
         }

         if (!field_268) {
            return var1;
         }

         var10000 = 128;
      } else if (class_18.method_128(1040)) {
         var10000 = 192;
      } else if (class_18.method_128(1040)) {
         var10000 = 128;
      } else {
         if (!class_18.method_128(8196) || !var0.method_38()) {
            return var1;
         }

         var10000 = 64;
      }

      return var10000;
   }

   private static int d(class_6 var0) {
      byte var1;
      label42: {
         var1 = -1;
         byte var10000;
         if (var0.method_38()) {
            if (!class_18.c(129)) {
               break label42;
            }

            var10000 = 7;
         } else if (class_18.c(256)) {
            var10000 = 1;
         } else if (class_18.c(4096)) {
            var10000 = 3;
         } else if (class_18.c(16384)) {
            var10000 = 2;
         } else if (class_18.c(64)) {
            var10000 = 6;
         } else if (class_18.c(32)) {
            var10000 = 4;
         } else {
            if (!class_18.c(65536)) {
               break label42;
            }

            var10000 = 5;
         }

         var1 = var10000;
      }

      if (var0.method_39() && class_18.c(129)) {
         var1 = 8;
      }

      if (class_18.c(32768)) {
         var1 = 10;
      }

      return var1;
   }

   // $VF: renamed from: d () void
   private static void method_159() {
      for (int var0 = 0; var0 < 2; var0++) {
         field_262.a(false);
      }
   }

   private static final void e() {
      if (k == 1) {
         for (int var0 = 0; var0 < n; var0++) {
            class_6 var1;
            label43:
            if ((var1 = field_261[var0]).method_35()) {
               class_6 var10000;
               byte var10001;
               if (var1.j == 12) {
                  if (var1.f <= 85) {
                     break label43;
                  }

                  var10000 = var1;
                  var10001 = 85;
               } else {
                  if (var1.f <= 75) {
                     break label43;
                  }

                  var10000 = var1;
                  var10001 = 75;
               }

               var10000.f = var10001;
            }

            if (field_260) {
               if (var1.I > 0) {
                  var1.field_78 = true;
                  if (var1.method_38() && var1.method_29()) {
                     var1.b();
                     j();
                  }
               }
            } else if (var1.I > 0 && var1.method_29()) {
               var1.e(9);
            }

            if (!var1.field_68) {
               var1.I = e(var1);
            }
         }
      }

      field_262.c();
      n();
      a++;
   }

   public static final void b(class_6 var0) {
      int[] var1 = var0.b;
      int var2 = 0;
      int var3 = 0;
      int var5 = -1;
      int var6;
      if ((var6 = class_5.a(569, j, 3)) == 4) {
         var5 = 16384;
      }

      if (var6 == 5) {
         var5 = 32768;
      }

      for (int var7 = 0; var7 < 18; var7++) {
         int var8;
         if ((var8 = var1[var7]) > 0 && (var5 & 1 << var7) != 0) {
            var2 += class_5.a(562, var7, 11) * var8;
            var3 += class_5.a(562, var7, 10) * var8;
            if (var2 == 0) {
               var2 = 1;
            }

            boolean var9 = class_5.a(562, var7, 8) != 0;
            var0.a[var7] += var8;
            int var10;
            if (var0 == field_261[0] && (var10 = class_5.a(562, var7, 0)) != -1) {
               String var11 = class_5.a(var10);
               String var14;
               if (var8 > 1 && !var9) {
                  class_5.a(1, String.valueOf(var8), var11);
                  var14 = class_5.a(1);
               } else {
                  var14 = var11;
               }

               a(var14);
            }
         }

         var1[var7] = 0;
      }

      if (var0 == field_261[0]) {
         if (var2 > 1) {
            class_5.a(3, String.valueOf(var2));
            a(class_5.a(3));
         }

         if (var3 > 0) {
            class_5.a(2, String.valueOf(var3));
            a(class_5.a(2));
         }
      }

      var3 *= var2;
      var0.field_65 += var3;
      int var13 = var0.H + (var3 * 128 >> 10);
      var0.H = class_18.method_137(var13, 0, 256);
   }

   private static final void a(String var0) {
      int var1 = o++ & 15;
      field_264[var1] = 80;
      field_263[var1] = var0;
   }

   public static final void b() {
      for (int var0 = 0; var0 < 2; var0++) {
         field_261[var0] = new class_6();
         field_261[var0].a();
      }

      o();
      field_262.a();
      g();
      field_259 = class_15.a(18);
      h = class_15.a(19);
      f();
   }

   private static final void f() {
      a(213, 7, 0);
      a(214, 8, 0);
      a(215, 9, 0);
      a(216, 10, 0);
      a(217, 11, 1);

      for (int var0 = 0; var0 < 7; var0++) {
         int var1 = class_5.a(574, var0, 0);
         class_15.a(26, var1, 35, var0, 0);
      }

      class_15.a(26, 116, 3, -1, 0);
   }

   // $VF: renamed from: d (int) int
   private static int method_162(int var0) {
      int var1 = class_5.a(570, var0, 0);
      int var2 = class_15.method_83(6, var1);
      return class_15.method_92(6, var2);
   }

   private static int e(int var0) {
      int var1;
      if ((var1 = class_5.a(570, var0, 0)) < 217) {
         int var2 = class_15.method_83(6, var1 + 1);
         return class_15.method_92(6, var2);
      } else {
         return 6;
      }
   }

   // $VF: renamed from: c (int) boolean
   private static boolean method_155(int var0) {
      if (var0 == 46) {
         return true;
      }

      int var1 = method_162(var0);
      int var2 = method_162(var0 + 1);
      return var1 != var2;
   }

   private static void a(int var0, int var1, int var2) {
      class_15.method_91(var1, var2);

      for (int var3 = 0; var3 < 47; var3++) {
         if (class_5.a(570, var3, 0) == var0) {
            int var5 = class_5.a(570, var3, 1);
            int var7;
            int var10000;
            int var10001;
            if ((var7 = class_5.b(573, 3, var3)) >= 0) {
               var10000 = 573;
               var10001 = var7;
            } else {
               var10000 = 569;
               var10001 = var5;
            }

            int var6 = class_5.a(var10000, var10001, 0);
            class_15.a(var1, var6, 44, var3, 7);
         }
      }

      class_15.a(var1, 116, 3, -1, 0);
   }

   // $VF: renamed from: b (int) void
   private static final void method_151(int var0) {
      int var1 = class_5.a(574, var0, 0);
      int var2 = class_5.a(574, var0, 1);
      int var3 = class_5.a(574, var0, 2);
      class_15.method_98(27, var1);
      if (class_15.method_96(27) == 0) {
         class_15.a(27, -1, 3, var3, 0);
      }

      class_15.a(27, 0, var2);
      class_15.b(27, 0, var3);
      class_15.a(27, 0, var2);
   }

   private static void g() {
      class_16.a();
      if (field_262 != null) {
         field_262.a(class_18.method_126(), class_18.method_133());
      }
   }

   public static final void a(boolean var0) {
      if (var0) {
         class_15.method_94(205);
      }

      if (field_255 != field_258) {
         field_273 = null;
      }

      class_15.method_72();
      field_255 = field_258;
      field_257 = f(field_255);
      j = class_5.a(570, field_255, 1);
      field_262.a(field_255);
      l = 0;
      k = class_5.a(569, j, 6);
      field_260 = class_5.a(569, j, 7) != 0;
      label46:
      if (k == 1) {
         int var1 = class_5.a(570, field_255, 2);
         int var10000;
         if (field_260) {
            var10000 = field_262.c(1);
         } else {
            int var2;
            if ((var2 = class_5.a(566, var1, 8)) < 0 || class_5.method_20(var2) <= 0) {
               break label46;
            }

            var10000 = class_5.a(var2, 0, 1) << 5;
         }

         l = var10000;
      }

      field_270 = class_5.a(569, j, 8) != 0 && !c();
      field_271 = class_5.a(569, j, 9) != 0;
      field_272 = field_270 | field_271;
      m = method_146(class_5.a(570, field_255, 4));
      b(false);
      if (var0) {
         class_15.method_73();
      }
   }

   private static void h() {
      int var0 = 0;
      field_274 = null;
      if (!e) {
         field_274 = class_15.method_84(field_255, 0);
      }

      if (field_274 != null) {
         var0++;
      }

      n = class_18.method_137(var0 + 1, 1, 2);
      field_261[0].b(field_259);
      field_261[0].e = h;
   }

   public static final void b(boolean var0) {
      if (var0) {
         class_15.method_94(205);
      }

      h();
      field_262.b();
      b = true;
      a = 0;
      field_254 = -1;
      d(false);
      field_263 = new String[16];
      field_264 = new byte[16];
      int var1 = field_262.c(0);

      for (int var2 = 0; var2 < n; var2++) {
         class_6 var3;
         (var3 = field_261[var2]).field_67 = true;
         var3.field_93 = false;
         var3.a(field_255);
         var3.field_79 = var1;
         var3.c();
         if (k == 1 && !field_260) {
            var3.field_78 = true;
         }
      }

      for (int var4 = 0; var4 < field_266.length; var4++) {
         field_266[var4] = -1;
      }

      method_147(65535);
      m();
      class_6 var5 = field_261[0];
      if (e) {
         var5.a(field_273);
         var5.h();
      } else {
         if (field_270 && field_274 != null) {
            class_6 var6;
            (var6 = field_261[1]).field_93 = true;
            i();
            var6.a(field_274);
            var6.h();
         }

         if (field_272) {
            var5.g();
         }
      }

      field_262.a(true);
      class_15.a((String)null);
      if (c()) {
         class_15.a(class_5.a(class_5.a(573, x, 2)));
      }

      if (var0) {
         class_15.method_73();
      }
   }

   private static final void d(boolean var0) {
      if (var0 != field_268) {
         method_147(64);
      }

      field_268 = var0;
   }

   private static final void i() {
      if (field_274 != null) {
         field_261[1].field_67 = class_15.a(6) != 0;
      }
   }

   // $VF: renamed from: b () int
   public static final int method_145() {
      return n;
   }

   // $VF: renamed from: b (f) int
   public static final int method_161(class_6 var0) {
      int var1 = 0;
      int var2 = n;

      for (int var3 = 0; var3 < var2; var3++) {
         if (field_261[var3] == var0) {
            var1 = var3;
            break;
         }
      }

      return var1;
   }

   // $VF: renamed from: a (int) f
   public static final class_6 method_148(int var0) {
      return field_261[var0];
   }

   // $VF: renamed from: a () f
   public static final class_6 method_143() {
      int var0 = 0;
      if (0 >= n) {
         var0 = n - 1;
      }

      return field_261[var0];
   }

   private static final void j() {
      field_254 = 30;
      class_15.b(63);
      class_6 var0;
      if (field_272 && (var0 = field_261[0]).method_42()) {
         var0.a(false);
         if (field_271) {
            field_273 = var0.method_30();
         }
      }
   }

   private static final void k() {
      b = false;
      class_15.b(60);
      if (class_18.a(6) || class_18.a(5) || class_18.a(4)) {
         l();
      }
   }

   private static final void l() {
      class_15.a(e ? 12 : (d() ? 17 : 16), false);
   }

   private static final int e(class_6 var0) {
      return (var0.method_29() ? var0.x : field_262.method_46()) - l >> 10 >> 5;
   }

   private static final boolean d() {
      int var0 = class_5.a(569, j, 3);
      int var1 = class_5.a(570, field_255, 7);
      int var2 = class_5.a(570, field_255, 8);
      int var3 = class_5.a(570, field_255, 9);
      int var4 = class_5.a(568, var0, 2);
      int var5 = class_5.a(568, var0, 0);
      int var6 = class_5.a(568, var0, 1);
      int var7 = class_5.a(568, var0, 3);
      class_6 var10 = field_261[0];
      int var10000;
      switch (var0) {
         case 1:
         case 4:
         case 5:
            var10000 = var10.field_65;
            break;
         case 2:
            var10000 = var10.field_66;
            break;
         case 3:
            var10000 = var10.I;
            break;
         default:
            var10000 = method_150(var10.f);
      }

      int var8 = var10000;
      int var9 = var10000;
      String var11 = null;
      if (j == 4 || j == 10) {
         int var16 = 0;

         for (int var13 = 0; var13 < 18; var13++) {
            if (var10.a[var13] > 0) {
               var16 |= 1 << var13;
            }
         }

         StringBuffer var18;
         if ((var18 = a(field_255, var16, false)).length() > 0) {
            var11 = var18.toString();
         }
      } else if (j == 3) {
         int var12 = class_5.a(570, field_255, 10);
         if (method_150(var10.f) > var12) {
            var11 = method_152(var12, 0);
         }
      }

      label69: {
         if (class_18.a(6)) {
            var9 = var3;
            var10000 = var3;
         } else if (class_18.a(5)) {
            var9 = var2;
            var10000 = var2;
         } else {
            if (!class_18.a(4)) {
               break label69;
            }

            var9 = var1;
            var10000 = var1;
         }

         var8 = var10000;
         var11 = null;
      }

      int var17 = 0;
      int var19;
      if (var11 == null && (var19 = var9 * var6) >= var1 * var6) {
         var17 = 3;
         if (var19 >= var2 * var6) {
            var17 = 2;
            if (var19 >= var3 * var6) {
               var17 = 1;
            }
         }
      }

      String var20 = method_152(var8, var5);
      class_5.b(295, class_5.a(var7));
      class_5.b(297, var20);
      f = false;
      if (var17 == 0) {
         String var21 = var11;
         if (var11 == null) {
            var21 = method_152(var1, var4);
         }

         class_5.b(296, var21);
         class_15.method_104(12, class_15.method_83(12, 219));
         return false;
      } else {
         String var14 = class_5.a(class_5.a(564, var17, 0));
         class_5.b(298, var14);
         d(field_255, var17);
         field_256 = var17;
         byte[] var15 = null;
         if (field_270 && field_273 != null) {
            var15 = field_273;
         }

         if (f = class_15.a(field_255, var8, var15, var6)) {
            class_5.a(29, var14, var20);
         }

         class_15.method_104(12, class_15.method_83(12, 220));
         return true;
      }
   }

   private static final void d(int var0, int var1) {
      int var2 = f(var0);
      if (var1 != 0 && (var1 < var2 || var2 == 0)) {
         int var10000;
         switch (var1) {
            case 1:
               var10000 = 13;
               break;
            case 2:
               var10000 = 11;
               break;
            case 3:
               var10000 = 9;
               break;
            default:
               return;
         }

         class_15.method_100(var10000, var0);
      }
   }

   private static int f(int var0) {
      if (class_15.method_99(13, var0)) {
         return 1;
      } else if (class_15.method_99(11, var0)) {
         return 2;
      } else {
         return class_15.method_99(9, var0) ? 3 : 0;
      }
   }

   // $VF: renamed from: a (int, int) java.lang.String
   private static String method_152(int var0, int var1) {
      String var2 = null;
      int var10000;
      switch (var1) {
         case 0:
            if (var0 >= 0) {
               return class_5.e(var0 * 60);
            }

            var10000 = 314;
            break;
         case 1:
            return String.valueOf(var0);
         case 2:
            class_5.a(41, String.valueOf(var0));
            var10000 = 41;
            break;
         case 3:
            switch (var0) {
               case 1:
                  return class_5.a(163);
               case 2:
                  return class_5.a(162);
               case 3:
                  return class_5.a(161);
               case 4:
               default:
                  return var2;
            }
         default:
            return var2;
      }

      return class_5.a(var10000);
   }

   // $VF: renamed from: d () int
   private static int method_160() {
      int var0 = 0;

      for (int var1 = 0; var1 < 47; var1++) {
         if (class_5.b(573, 3, var1) < 0) {
            int var2 = class_5.a(570, var1, 1);
            int var3 = class_5.a(569, var2, 10);
            int var4 = 0;
            int var5 = class_5.a(569, var2, 3);
            int var6 = class_5.a(568, var5, 1);
            int var7;
            if ((var7 = class_15.c(var1, 0) * var6) != 0) {
               int var8 = class_5.a(570, var1, 7) * var6;
               if (var7 > var8) {
                  var4 = Math.abs(var8 - var7) * var3;
               }
            }

            var0 += var4;
         }
      }

      return var0;
   }

   private static final void m() {
      int var0 = class_5.a(569, j, 4);

      for (int var1 = 0; var1 < n; var1++) {
         class_6 var2 = field_261[var1];
         switch (var0) {
            case 2:
               var2.f = (class_5.a(570, field_255, 6) << 10) / 1024;
               break;
            case 0:
            case 1:
            case 3:
         }
      }
   }

   private static final void n() {
      int var0 = class_5.a(569, j, 5);

      for (int var1 = 0; var1 < n; var1++) {
         class_6 var2;
         if (!(var2 = field_261[var1]).field_68) {
            switch (var0) {
               case 1:
               case 2:
               case 3:
               default:
                  break;
               case 4:
                  var2.f++;
                  break;
               case 5:
                  var2.f--;
                  if (var2.f <= 0) {
                     var2.f = 0;
                     var2.b();
                     if (var1 == 0) {
                        j();
                     }
                  }
            }
         }
      }
   }

   public static final void c(boolean var0) {
      if (var0) {
         method_147(65535);
         field_262.b(var0);
         i();
      }
   }

   // $VF: renamed from: c () void
   public static final void method_157() {
      class_15.a(5, 1);
      class_15.a(6, 1);
      class_15.a(15, 511);
      class_15.a(20, 1);
      field_259 = 0;
      h = 0;
      class_15.a(18, field_259);
      class_15.a(19, h);
   }

   public static final void b(int var0, int var1) {
      int var10000;
      int var10001;
      switch (var0) {
         case 10:
            if (field_258 != field_255) {
               method_163(field_255);
            }
         case 9:
            e = false;
            if (!class_15.method_89(17, -1)) {
               field_259 = 0;
               class_15.method_79(8);
               return;
            }

            var10000 = 5;
            var10001 = 3;
            break;
         case 11:
            e = true;
            if (field_258 != field_255) {
               method_163(field_255);
            }

            class_15.method_79(8);
            return;
         case 12:
            if (field_256 != 0 && field_255 >= 7 && field_255 < 37 && (field_257 == 0 || field_257 > field_256)) {
               int var11 = 1;
               if (field_257 == 0 && field_256 == 1) {
                  var11 = 2;
               }

               int var16 = 0;

               for (int var4 = field_255 + 1; var4 < 37; var4++) {
                  if (!method_153(7, var4)) {
                     class_15.method_100(15, var4);
                     var16++;
                     if (var16 >= var11) {
                        break;
                     }
                  }
               }

               field_257 = field_256;
               int var19;
               if (var16 > 0 && d(var19 = var16 > 1 ? 1 : 0)) {
                  return;
               }
            }

            for (int var12 = 0; var12 < 14; var12++) {
               int var17 = class_5.a(572, var12, 0);
               int var20 = class_5.a(572, var12, 1);
               boolean var5 = true;

               for (int var6 = 0; var6 < 47; var6++) {
                  int var7 = class_5.a(570, var6, 0);
                  if (var17 == -1 && var7 != 213 && var7 != 217 || var17 != -1 && var17 == var7) {
                     if (var20 != 0) {
                        int var8;
                        if ((var8 = f(var6)) == 0 || var8 == 4 || var8 > var20) {
                           var5 = false;
                           break;
                        }
                     } else {
                        if (class_15.method_99(15, var6)) {
                           break;
                        }

                        var5 = false;
                     }
                  }
               }

               if (var5 && d(class_5.a(572, var12, 2))) {
                  return;
               }
            }

            if (f) {
               f = false;
               class_15.b(5, 19);
               class_15.method_66();
               if (class_15.field_212 != 0) {
                  g = class_15.method_81(method_160());
                  return;
               }

               return;
            }

            if (class_15.a(21) == 0) {
               int var13 = 0;

               for (int var18 = 0; var18 < 37; var18++) {
                  int var21;
                  if ((var21 = f(var18)) > 0 && var21 < 4) {
                     var13++;
                  }
               }

               if (var13 == 37) {
                  class_15.a(21, 1);
                  class_5.b(301, class_5.a(234));
                  var10000 = 5;
                  var10001 = 18;
                  break;
               }
            }

            class_15.method_72();
            if (g) {
               g = false;
               if (class_15.method_65()) {
                  return;
               }
            }

            if (f(field_255) == 0) {
               return;
            }

            var10000 = 6;
            var10001 = 12;
            break;
         case 15:
            var10000 = 7;
            var10001 = method_162(field_255);
            break;
         case 16:
            if (method_155(field_255)) {
               int var9 = e(field_255);
               int var14 = class_15.method_88(6, var9);
               class_15.method_104(6, var14);
               var10000 = 5;
               var10001 = 6;
            } else {
               int var10;
               int var15 = class_15.method_88(var10 = method_162(field_255), g(field_255));
               class_15.method_104(var10, var15);
               var10000 = 5;
               var10001 = var10;
            }
            break;
         case 35:
            method_151(var1);
            var10000 = 5;
            var10001 = 27;
            break;
         case 43:
            field_262.d();
            var10000 = 5;
            var10001 = var1;
            break;
         case 44:
            x = -1;
            method_163(var1);
            class_15.method_93(16, class_15.method_68());
            var10000 = 5;
            var10001 = 2;
            break;
         case 45:
            field_259 = r;
            h = s;
            class_15.a(18, field_259);
            class_15.a(19, h);
            if (class_15.method_68() != 4) {
               class_15.method_79(8);
               return;
            }

            var10000 = 5;
            var10001 = 6;
            break;
         case 51:
            field_262.a(field_269);
            return;
         case 63:
            if (field_255 == field_258 && field_255 == 36) {
               int var2;
               label130: {
                  var2 = 1;
                  byte var22;
                  switch (var1) {
                     case 4:
                        var22 = 3;
                        break;
                     case 5:
                        var22 = 2;
                        break;
                     default:
                        break label130;
                  }

                  var2 = var22;
               }

               for (int var3 = 0; var3 < 37; var3++) {
                  d(var3, var2);
               }

               return;
            }

            return;
         case 64:
            x = -1;
            method_163(7);
            class_15.method_93(16, 0);
            field_259 = 0;
            h = 0;
            var10000 = 8;
            var10001 = -1;
            break;
         default:
            return;
      }

      class_15.b(var10000, var10001);
   }

   private static final boolean d(int var0) {
      if (var0 >= 0) {
         int var1 = class_5.a(571, var0, 1);
         if (class_5.a(567, var1, 2) == 0) {
            method_156(var0);
            class_15.b(5, 18);
            return true;
         }

         if (!class_15.method_99(17, var0)) {
            class_15.method_100(17, var0);
            method_156(var0);
            class_15.b(5, 18);
            return true;
         }
      }

      return false;
   }

   // $VF: renamed from: c (int) void
   private static final void method_156(int var0) {
      int var3;
      label22: {
         String var10;
         int var10000;
         label21: {
            int var1 = class_5.a(571, var0, 1);
            int var2 = class_5.a(571, var0, 0);
            var3 = class_5.a(567, var1, 0);
            int var10001;
            switch (var1) {
               case 0:
               default:
                  break label22;
               case 1:
                  var10000 = var3;
                  var10 = String.valueOf(class_5.a(571, var0, 2));
                  break label21;
               case 2:
                  int var4 = class_5.a(571, var0, 2);
                  int var5 = class_5.a(570, var4, 1);
                  class_15.method_100(15, var4);
                  int var7;
                  int var9;
                  if ((var7 = class_5.b(573, 3, var4)) >= 0) {
                     var10000 = 573;
                     var9 = var7;
                  } else {
                     var10000 = 569;
                     var9 = var5;
                  }

                  int var6 = class_5.a(var10000, var9, 0);
                  var10000 = var3;
                  var10001 = var6;
                  break;
               case 3:
                  i = class_5.a(571, var0, 2);
                  class_15.method_100(20, i);
                  var10000 = var3;
                  var10001 = var2;
            }

            var10 = class_5.a(var10001);
         }

         class_5.a(var10000, var10);
      }

      class_5.b(301, class_5.a(var3));
   }

   // $VF: renamed from: d (int) void
   private static final void method_163(int var0) {
      field_258 = var0;
      x = class_5.b(573, 3, var0);
      int var1 = class_5.a(570, var0, 1);
      int var2 = class_5.a(570, var0, 7);
      int var3 = class_5.a(570, var0, 8);
      int var4 = class_5.a(570, var0, 9);
      int var5 = class_5.a(569, var1, 3);
      int var6 = class_5.a(568, var5, 2);
      int var10000;
      String var10001;
      if (c()) {
         int var7 = class_5.a(573, x, 1);
         int var8 = class_5.a(573, x, 2);
         class_5.b(87, class_5.a(var7));
         var10000 = 88;
         var10001 = class_5.a(var8);
      } else {
         class_5.b(87, "");
         var10000 = 88;
         var10001 = "";
      }

      int var11;
      label20: {
         class_5.b(var10000, var10001);
         int var10 = class_5.a(569, var1, 0);
         class_5.b(85, class_5.a(var10));
         var11 = class_5.a(569, var1, 2);
         if (var1 == 3) {
            var10000 = var11;
            var10001 = method_152(class_5.a(570, var0, 10), 0);
         } else {
            if (var1 != 4 && var1 != 10) {
               break label20;
            }

            StringBuffer var9 = a(var0, 0, true);
            var10000 = var11;
            var10001 = var9.toString();
         }

         class_5.a(var10000, var10001);
      }

      class_5.b(299, class_5.a(var11));
      String[] var12 = new String[]{method_152(var2, var6), method_152(var3, var6), method_152(var4, var6)};
      class_5.a(6, var12);
      class_5.b(300, "");
      method_164(var0);
   }

   private static StringBuffer a(int var0, int var1, boolean var2) {
      StringBuffer var3 = new StringBuffer();
      int var4 = class_5.a(570, var0, 10);

      for (int var5 = 0; var5 < 18; var5++) {
         int var6 = 1 << var5;
         if ((var4 & var6) != 0 && (var1 & var6) == 0) {
            var3.append(class_5.a(class_5.a(562, var5, var2 ? 1 : 0)));
            var3.append('\n');
         }
      }

      return var3;
   }

   public static final void c(int var0, int var1) {
      switch (var0) {
         case 3:
         case 4:
         case 5:
            if (!b(var1)) {
               r = field_259;
               s = h;
               a(null, true, true);
            }

            if (var0 == 4) {
               a(4, 576, 0, s);
               return;
            }

            class_15.method_93(var0, 2);
            a(5, 576, 0, s);
            a(3, 563, 0, r);
            return;
         case 6:
         case 7:
         case 8:
         case 9:
         case 10:
         case 11:
         default:
            if (var0 == 14) {
               int var3 = class_15.a(6) != 0 ? 144 : 145;
               class_5.a(10, class_5.a(var3));
            }

            return;
         case 12:
            if (var1 == 2 && field_258 != field_255) {
               method_163(field_255);
            }

            class_15.d(var0);
      }
   }

   // $VF: renamed from: e (int) void
   private static void method_164(int var0) {
      int var10000;
      String var10001;
      String var10002;
      if (method_153(9, var0)) {
         int var1 = class_5.a(570, field_258, 1);
         int var2 = class_5.a(569, var1, 3);
         int var3 = class_5.a(568, var2, 0);
         int var4 = class_5.a(568, var2, 3);
         String var6 = method_152(class_15.c(field_258, 0), var3);
         var10000 = 29;
         var10001 = class_5.a(var4);
         var10002 = var6;
      } else {
         var10000 = 29;
         var10001 = class_5.a(164);
         var10002 = class_5.a(314);
      }

      class_5.a(var10000, var10001, var10002);
   }

   private static void a(int var0, int var1, int var2, int var3) {
      int var4 = class_15.method_96(var0);

      for (int var5 = 0; var5 < var4; var5++) {
         int var6;
         if ((var6 = class_15.method_92(var0, var5)) != -1) {
            if (class_15.method_85(var0, var5)) {
               class_15.a(var0, var5, class_5.a(var1, var6, var2));
               if (var3 >= 0 && var6 == var3) {
                  class_15.method_104(var0, var5);
               }
            } else {
               class_15.a(var0, var5, 114);
            }
         }
      }
   }

   // $VF: renamed from: a (int, int) boolean
   public static final boolean method_153(int var0, int var1) {
      switch (var0) {
         case 6:
            int var3 = var1;
            int var4 = class_15.method_96(var1);

            for (int var5 = 0; var5 < var4; var5++) {
               if (class_15.method_90(var3, var5) == 44) {
                  int var6 = class_15.method_92(var3, var5);
                  if (method_153(7, var6)) {
                     return true;
                  }
               }
            }

            return false;
         case 7:
            return var1 < 47 && (class_18.a(1) || class_15.method_99(15, var1));
         case 8:
            if (g(field_255) > -1) {
               return true;
            }

            return false;
         case 9:
            if (f(field_258) != 0) {
               return true;
            }

            return false;
         case 10:
         default:
            return true;
         case 11:
            return method_140();
         case 12:
            return true;
         case 13:
            if (field_273 != null) {
               return true;
            }

            return false;
         case 14:
            return method_144();
         case 15:
            if (!method_144()) {
               return true;
            }

            return false;
         case 16:
            if (field_274 != null) {
               return true;
            }

            return false;
         case 17:
            int var2 = class_15.a(20);
            if (!class_18.a(2) && class_18.f(var2) <= 1) {
               return false;
            }

            return true;
         case 18:
            if (!class_18.a(2) && !class_15.method_99(20, var1)) {
               return false;
            }

            return true;
         case 19:
            return true;
      }
   }

   private static final int g(int var0) {
      for (int var1 = ++var0; var1 < 47; var1++) {
         if (method_153(7, var1)) {
            return var1;
         }
      }

      return -1;
   }

   public static final void a(Graphics var0, int var1) {
      if (class_15.method_77() != 0) {
         int var2 = class_18.method_133();
         int var3 = class_18.method_126();
         class_18.method_130(-11534336);
         int var4 = class_15.field_197;
         int var5 = class_18.method_116() - 4;
         var0.setColor(-12451840);
         var0.fillRect(0, 0, var3, var4);
         var0.fillRect(0, var5, var3, var2 - var5);
         switch (var1) {
            case 4:
            case 6:
            case 12:
            case 13:
            case 14:
            case 15:
            default:
               class_18.a(12, 0, class_18.method_116(), 36);
            case 3:
            case 5:
            case 7:
            case 8:
            case 9:
            case 10:
            case 11:
            case 16:
            case 17:
               a(var0, var3, var4, var5);
         }
      }
   }

   public static final boolean a(Graphics var0, int var1, int var2) {
      boolean var3 = false;
      switch (var1) {
         case 3:
         case 4:
         case 5:
            class_15.c(class_18.method_133() - class_15.f(var1, 3));
            if (class_15.method_90(var1, var2) == 45) {
               if (var1 == 3) {
                  r = class_15.method_92(var1, var2);
               }

               if (var1 == 5 || var1 == 4) {
                  s = class_15.method_92(var1, var2);
               }

               a(var0, var1 == 3, false);
            }

            if (b(var1)) {
               int var8 = class_18.method_122(1);
               int var9 = class_18.method_129(1);
               class_18.b(1, var8, class_15.field_197 + var9, 0);
               class_18.b(1, class_18.method_126() - var8, class_15.field_197 + var9, 1);
            }
         case 6:
         case 12:
         case 13:
         case 14:
         case 15:
         case 18:
         case 19:
         case 20:
         case 21:
         case 22:
         case 23:
         case 24:
         case 25:
         case 26:
         default:
            break;
         case 7:
         case 8:
         case 9:
         case 10:
         case 11:
            class_15.c(class_18.method_133() - class_15.f(var1, 3));
            if (class_15.method_90(var1, var2) == 44) {
               int var7 = class_15.method_92(var1, var2);
               class_18.b(var0);
               int var5 = class_15.method_70();
               int var6 = class_18.method_116() - 4;
               class_18.method_138(var0.getClipX(), var5, var0.getClipWidth(), var6 - var5);
               field_262.method_47(var0, var7);
               class_18.c(var0);
               method_165(var7);
            }
            break;
         case 16:
            if (j != 4) {
               d(var0);
               var3 = true;
            }
            break;
         case 17:
            c(var0);
            var3 = true;
            break;
         case 27:
            class_15.c(class_18.method_133() - class_15.f(var1, 3));
            int var4 = class_15.method_92(var1, 0);
            field_262.a(var0, var4);
      }

      return var3;
   }

   private static final void a(Graphics var0, boolean var1, boolean var2) {
      int var3 = 0;
      int var4 = 0;
      if (var0 != null) {
         var3 = var0.getTranslateX();
         var4 = var0.getTranslateY();
         var0.translate(-var3, -var4);
      }

      int var5 = class_15.method_70() + 4;
      int var6 = class_15.method_75();
      int var7 = class_5.a(563, r, 1);
      int var8 = class_5.a(576, s, 1);
      int var9;
      int var10000;
      if (var1) {
         var9 = var7;
         var10000 = var8;
      } else {
         var9 = var8;
         var10000 = var7;
      }

      int var10 = var10000;
      int var11 = var6 - var5;
      int var12 = class_5.method_20(var9);
      int var13 = class_5.method_20(var10);
      int var14 = class_18.method_126() * 60 >> 10;
      int var15;
      if ((var15 = var5 + (var11 - var12 >> 2)) < var5) {
         var15 = var5;
      }

      int var16 = class_18.method_126() - class_5.method_15(var10) - (class_18.method_126() * 50 >> 10);
      int var17;
      if ((var17 = var6 - var13 - (var11 - var13 >> 2)) > var6 - var13) {
         var17 = var6 - var13;
      }

      var14 <<= 10;
      var15 <<= 10;
      var16 <<= 10;
      var17 <<= 10;
      if (var2) {
         t = var14 - (class_5.method_15(var9) << 10);
         u = var15;
         v = var16;
         w = -(class_5.method_20(var10) << 10);
      } else {
         int var10001;
         int var10002;
         if (var1) {
            t = t + ((var14 - t) * 256 >> 10);
            u = u + ((var15 - u) * 256 >> 10);
            v = v + ((var16 - v) * 256 >> 10);
            w = w + ((var17 - w) * 256 >> 10);
            class_18.a(var8, v >> 10, w >> 10);
            class_18.a(class_5.a(563, r, 2), t >> 10, u >> 10);
            var10000 = var7;
            var10001 = t >> 10;
            var10002 = u;
         } else {
            t = t + ((var16 - t) * 256 >> 10);
            u = u + ((var17 - u) * 256 >> 10);
            v = v + ((var14 - v) * 256 >> 10);
            w = w + ((var15 - w) * 256 >> 10);
            class_18.a(var7, t >> 10, u >> 10);
            class_18.a(class_5.a(576, s, 2), v >> 10, w >> 10);
            var10000 = var8;
            var10001 = v >> 10;
            var10002 = w;
         }

         class_18.a(var10000, var10001, var10002 >> 10);
      }

      if (var0 != null) {
         var0.translate(var3, var4);
      }
   }

   private static final void c(Graphics var0) {
      int var1 = class_5.a(576, h, 1);
      int var3 = class_18.a(class_18.field_236) + 2;
      int var4 = class_5.method_20(var1);
      int var5 = 6 * var3;
      int var6 = class_18.method_116() - class_15.method_70();
      int var7;
      if ((var7 = class_15.method_70() + (var6 - var4 - var5 >> 1) + (var3 >> 1)) < class_15.method_70()) {
         var7 = class_15.method_70();
      }

      int var8 = class_18.method_126() >> 1;
      b(var0, var7, var8, 295);
      var7 += var3;
      b(var0, var7, var8, 297);
      var7 += var3;
      int var9 = class_18.method_126() * 950 >> 10;
      b(var0, var7, var9, 294);
      var7 += var3;
      b(var0, var7, var9, 298);
      int var14;
      var7 = (var14 = var7 + var3) + (var3 >> 1);
      int var10 = class_18.method_126() - class_5.method_15(var1) - class_18.method_122(5) >> 1;
      class_18.a(var1, var10, var7);
      class_18.b(5, var10 + class_5.method_15(var1) + (class_18.method_122(5) >> 1), var7 + (var4 >> 1), field_256 - 1);
   }

   private static final void d(Graphics var0) {
      int var1 = class_5.a(576, h, 1);
      int var3 = class_18.a(class_18.field_236) + 2;
      int var4 = class_5.method_20(var1);
      int var5 = 6 * var3;
      int var6 = class_18.method_116() - class_15.method_70();
      int var7;
      if ((var7 = class_15.method_70() + (var6 - var4 - var5 >> 1) + (var3 >> 1)) < class_15.method_70()) {
         var7 = class_15.method_70();
      }

      int var8 = class_18.method_126() >> 1;
      b(var0, var7, var8, 295);
      var7 += var3;
      b(var0, var7, var8, 297);
      var7 += var3;
      var8 = class_18.method_126() * 950 >> 10;
      String var9;
      Graphics var10000;
      int var10001;
      int var10002;
      String var10003;
      if (class_18.a(var9 = class_5.a(293), class_18.field_236) > class_18.method_126() - 4) {
         int var10 = var9.indexOf(32);
         String var11 = var9.substring(0, var10);
         String var12 = var9.substring(var10 + 1);
         a(var0, var7, var8, var11);
         var7 += var3;
         var10000 = var0;
         var10001 = var7;
         var10002 = var8;
         var10003 = var12;
      } else {
         var10000 = var0;
         var10001 = var7;
         var10002 = var8;
         var10003 = var9;
      }

      a(var10000, var10001, var10002, var10003);
      var7 += var3;
      var9 = class_5.a(296);
      a(var0, var7, var8, var9);
      int var16;
      var7 = (var16 = var7 + var3) + (var3 >> 1);
      class_18.a(var1, class_18.method_126() - class_5.method_15(var1) >> 1, var7);
   }

   private static void b(Graphics var0, int var1, int var2, int var3) {
      a(var0, var1, var2, class_5.a(var3));
   }

   private static void a(Graphics var0, int var1, int var2, String var3) {
      int var4;
      if ((var4 = var2 - class_18.a(var3, class_18.field_236)) < 2) {
         var4 = 2;
      }

      class_18.a(var0, class_18.field_236, -1138688, var3, var4, var1, 20);
   }

   // $VF: renamed from: f (int) void
   private static void method_165(int var0) {
      int var1 = class_15.field_197;
      int var2 = class_5.a(570, var0, 1);
      int var3 = class_5.a(569, var2, 1);
      int var4 = f(var0);
      int var5 = Math.max(class_18.method_122(4), class_18.method_122(5)) >> 1;
      int var6 = class_18.method_129(4);
      int var7 = class_18.method_126() - var5 - 4;
      class_18.b(4, var7, var1, var3);
      if (var4 > 0) {
         var1 += var6 + 4;
         class_18.b(5, var7, var1, var4 - 1);
      }
   }

   private static void o() {
      if (field_262 == null) {
         p();
      }

      int var0 = class_18.method_126();
      int var1 = class_18.method_133();
      field_262.a(var0, var1);
   }

   // $VF: renamed from: c () int
   public static final int method_158() {
      return 60;
   }

   private static final void p() {
      field_262 = new class_8();
   }
}
