package com.iplay.fmx33d;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Vector;
import javax.microedition.io.Connection;
import javax.microedition.io.Connector;
import javax.microedition.io.HttpConnection;
import javax.microedition.io.InputConnection;
import javax.microedition.io.OutputConnection;
import javax.microedition.midlet.MIDlet;

// $VF: renamed from: j
public final class class_10 implements Runnable {
   public static MIDlet a;
   // $VF: renamed from: a java.lang.String
   public static String field_134 = "";
   // $VF: renamed from: a java.lang.Integer
   private static final Integer field_135 = new Integer(-1);
   private static final Integer b = new Integer(-2);
   private static final Integer c = new Integer(-3);
   private static final Integer d = new Integer(-4);
   private static final Integer e = new Integer(-5);
   private static final Integer f = new Integer(-6);
   // $VF: renamed from: a java.util.Vector
   private Vector field_136 = new Vector();
   // $VF: renamed from: b java.util.Vector
   private Vector field_137 = new Vector();
   // $VF: renamed from: c java.util.Vector
   private Vector field_138 = new Vector();
   // $VF: renamed from: a boolean
   private volatile boolean field_139 = false;
   // $VF: renamed from: a int
   public static int field_140;
   // $VF: renamed from: b int
   public static int field_141;
   // $VF: renamed from: a java.lang.String[]
   public static String[] field_142;
   // $VF: renamed from: a int[]
   public static int[] field_143;
   // $VF: renamed from: b int[]
   public static int[] field_144;
   // $VF: renamed from: b java.lang.String
   private static String field_145;
   // $VF: renamed from: c java.lang.String
   private static String field_146;
   // $VF: renamed from: d java.lang.String
   private static String field_147;
   // $VF: renamed from: c int
   private static int field_148;
   // $VF: renamed from: d int
   private static int field_149;

   public class_10(MIDlet var1) {
      a(var1);
      new Thread(this).start();
   }

   public final synchronized void a(int var1, class_15 var2) {
      this.field_136.addElement(new Integer(var1));
      this.field_137.addElement(var2);
      this.field_138.addElement(null);
      this.notify();
   }

   public final synchronized void a(class_15 var1) {
      this.field_136.addElement(field_135);
      this.field_137.addElement(var1);
      this.field_138.addElement(null);
      this.notify();
   }

   public final synchronized void b(class_15 var1) {
      this.field_136.addElement(b);
      this.field_137.addElement(var1);
      this.field_138.addElement(null);
      this.notify();
   }

   public final synchronized void a(String var1, String var2, class_15 var3) {
      this.field_136.addElement(f);
      this.field_137.addElement(var3);
      Vector var10000;
      String var10001;
      if (var2 != null) {
         var10000 = this.field_138;
         var10001 = var1 + "|" + var2;
      } else {
         var10000 = this.field_138;
         var10001 = var1;
      }

      var10000.addElement(var10001);
      this.notify();
   }

   public final synchronized void b(int var1, class_15 var2) {
      this.field_136.addElement(d);
      this.field_137.addElement(var2);
      this.field_138.addElement(Integer.toString(var1));
      this.notify();
   }

   public final synchronized void c(class_15 var1) {
      this.field_136.addElement(e);
      this.field_137.addElement(var1);
      this.field_138.addElement(null);
      this.notify();
   }

   public final void a() {
      this.field_139 = true;
      synchronized (this) {
         this.notify();
      }
   }

   public final void run() {
      while (!this.field_139) {
         Integer var1;
         class_15 var2;
         String var3;
         synchronized (this) {
            while (this.field_136.size() == 0) {
               try {
                  this.wait();
               } catch (InterruptedException var7) {
               }

               if (this.field_139) {
                  return;
               }
            }

            var1 = (Integer & Integer)this.field_136.elementAt(0);
            var2 = (class_15)this.field_137.elementAt(0);
            var3 = (String & String)this.field_138.elementAt(0);
            this.field_136.removeElementAt(0);
            this.field_137.removeElementAt(0);
            this.field_138.removeElementAt(0);
         }

         int var4 = 1;

         while (--var4 >= 0 && !this.a(var2, var1, var3, true)) {
         }
      }
   }

   private final boolean a(class_15 var1, Integer var2, String var3, boolean var4) {
      if (var2 == field_135) {
         DataInputStream var14;
         if ((var14 = a(var1, 0, 5, null)) != null) {
            if (a(var14) > -1) {
               var1.a(1, 2, 0, null, null);
               return true;
            } else {
               return true;
            }
         } else {
            if (var4) {
               var1.a(-1, 2, 0, null, null);
            }

            return false;
         }
      } else if (var2 == b) {
         StringBuffer var13 = new StringBuffer();
         int var16;
         if ((var16 = a(var1, "nickname", var13)) > 0) {
            var1.a(1, 3, 0, var13.toString(), null);
            return true;
         }

         if (var4) {
            var1.a(var16, 3, 0, null, null);
         }

         return false;
      } else if (var2 == c) {
         int var12;
         if ((var12 = a(var1, "nickname", var3)) > 0) {
            var1.a(1, 4, 0, var3, null);
            return true;
         }

         if (var4) {
            var1.a(var12, 4, 0, null, null);
         }

         return false;
      } else if (var2 == d) {
         if (method_58(Integer.parseInt(var3), var1) > 0) {
            var1.a(1, 5, 0, null, null);
            return true;
         }

         if (var4) {
            var1.a(-1, 5, 0, null, null);
         }

         return false;
      } else if (var2 == e) {
         Vector var11;
         if ((var11 = method_59(var1)) != null) {
            var1.a(1, 6, 0, null, var11);
            return true;
         }

         if (var4) {
            var1.a(-1, 6, 0, null, null);
         }

         return false;
      } else if (var2 == f) {
         int var10 = var3.lastIndexOf(124);
         StringBuffer var15 = new StringBuffer();
         String var10000;
         String var10001;
         if (var10 >= 0) {
            String var8 = var3.substring(0, var10);
            String var9 = var3.substring(var10 + 1);
            var10000 = var8;
            var10001 = var9;
         } else {
            var10000 = var3;
            var10001 = null;
         }

         int var7;
         if ((var7 = a(var10000, var10001, var1, var15)) > 0) {
            var1.a(1, 7, 0, var15.toString(), null);
            return true;
         }

         if (var7 < 0) {
            var1.a(var7, 7, 0, var15.toString(), null);
            return true;
         }

         if (var4) {
            var1.a(var7, 7, 0, null, null);
         }

         return false;
      } else {
         StringBuffer var5 = new StringBuffer();
         int var6;
         if ((var6 = a(var1, var2.intValue(), null, null, var5)) >= 0) {
            var1.a(var6, 1, 0, var5.toString(), null);
            return true;
         }

         if (var4) {
            var1.a(-1, 1, 0, null, null);
         }

         return false;
      }
   }

   private static final void a(class_15 var0, int var1) {
      if (var0 != null) {
         var0.method_105(var1);
      }
   }

   // $VF: renamed from: a (int, o) int
   private static int method_58(int var0, class_15 var1) {
      HttpConnection var2 = null;
      DataInputStream var3 = null;
      DataOutputStream var4 = null;
      int var5 = 0;

      try {
         a(var1, 1);
         var4 = a(var2 = method_60(), 1);
         a(var1, 2);
         var4.writeUTF("RATEGAME");
         var4.writeInt(var0);
         var5 = (var3 = a(var2)).readInt();
      } catch (Exception var10) {
      } finally {
         a(var3, var4, var2);
      }

      return var5;
   }

   // $VF: renamed from: a (o) java.util.Vector
   private static Vector method_59(class_15 var0) {
      HttpConnection var1 = null;
      DataInputStream var2 = null;
      DataOutputStream var3 = null;
      Vector var4 = null;

      try {
         a(var0, 1);
         (var3 = a(var1 = method_60(), 1)).writeUTF("M7RecommendGame");
         a(var0, 2);
         if ((var2 = a(var1)).readInt() > 0) {
            int var6 = var2.readInt();
            var4 = new Vector(var6);

            for (int var8 = 0; var8 < var6; var8++) {
               String var7;
               if ((var7 = var2.readUTF()) != null && (var7 = var7.trim()).length() > 0) {
                  var4.addElement(var7);
               }
            }
         }
      } catch (Exception var12) {
         var4 = null;
      } finally {
         a(var2, var3, var1);
      }

      return var4;
   }

   private static int a(String var0, String var1, class_15 var2, StringBuffer var3) {
      HttpConnection var4 = null;
      DataInputStream var5 = null;
      DataOutputStream var6 = null;
      int var7 = 0;

      try {
         a(var2, 1);
         var6 = a(var4 = method_60(), 1);
         a(var2, 2);
         var6.writeUTF("REGISTERUSER");
         var6.writeUTF(var0);
         if (var1 != null) {
            var6.writeUTF(var1);
         }

         var7 = (var5 = a(var4)).readInt();
         var3.append(var5.readUTF());
      } catch (Exception var12) {
      } finally {
         a(var5, var6, var4);
      }

      return var7;
   }

   private static final void a(MIDlet var0) {
      a = var0;
      field_134 = a.getAppProperty("UNITYLANGUAGE");
      if (field_134 != null) {
         field_134.trim();
      } else {
         field_134 = "";
      }

      b();
   }

   public static final void a(MIDlet var0, String var1) {
      a = var0;
      field_134 = var1;
      b();
   }

   private static final void b() {
      field_145 = class_15.method_107("UNITYENTRYPOINT");
      String var0;
      if ((var0 = class_15.method_107("UNITYUSERTAG")) == null) {
         var0 = "UNITYUSERID";
      }

      field_147 = class_15.method_107(var0);
      field_148 = class_15.a("UNITYDEVICEID", -1);
      field_146 = class_15.method_107("UNITYCONTENTTYPE");
      field_149 = class_15.a("UNITYGAMEID", -1);
   }

   // $VF: renamed from: a () javax.microedition.io.HttpConnection
   private static final HttpConnection method_60() throws IOException {
      try {
         if (false) {
            throw (IOException)null;
         }

         return (HttpConnection)Connector.open(field_145);
      } catch (IOException var3) {
         try {
            Thread.sleep(500L);
         } catch (Exception var2) {
         }

         throw var3;
      }
   }

   private static final DataOutputStream a(HttpConnection var0, int var1) throws IOException {
      String var2;
      label18: {
         var0.setRequestMethod("POST");
         String var10000;
         if ((var2 = field_146) == null) {
            var10000 = "*/*";
         } else {
            var2.trim();
            if (!"NONE".equals(var2)) {
               break label18;
            }

            var10000 = null;
         }

         var2 = var10000;
      }

      if (var2 != null) {
         var0.setRequestProperty("content-type", var2);
      }

      var0.setRequestProperty("accept", "*/*");
      DataOutputStream var3;
      (var3 = new DataOutputStream(((OutputConnection)var0).openOutputStream())).writeInt(90001);
      var3.writeUTF(field_147);
      var3.writeInt(field_148);
      var3.writeInt(method_61());
      var3.writeUTF(field_134);
      var3.writeInt(0);
      var3.writeInt(var1);
      return var3;
   }

   private static final DataInputStream a(HttpConnection var0) throws IOException {
      boolean var1 = false;
      DataInputStream var2 = null;

      int var5;
      try {
         if (false) {
            throw (IOException)null;
         }

         var5 = var0.getResponseCode();
      } catch (IOException var4) {
         var5 = 0;
      }

      if (var5 == 200) {
         (var2 = ((InputConnection)var0).openDataInputStream()).readLong();
         var2.readInt();
         var2.readUTF();
         var2.readInt();
      }

      return var2;
   }

   // $VF: renamed from: a () int
   private static final int method_61() {
      return field_149;
   }

   private static final void a(DataInputStream var0, DataOutputStream var1, HttpConnection var2) {
      if (var1 != null) {
         try {
            var1.close();
         } catch (IOException var5) {
         }
      }

      if (var0 != null) {
         try {
            var0.close();
         } catch (IOException var4) {
         }
      }

      if (var2 != null) {
         try {
            if (false) {
               throw (IOException)null;
            }

            ((Connection)var2).close();
            return;
         } catch (IOException var6) {
         }
      }
   }

   private static final int a(class_15 var0, int var1, String var2, String var3, StringBuffer var4) {
      HttpConnection var5 = null;
      DataInputStream var6 = null;
      DataOutputStream var7 = null;
      int var8 = -1;

      try {
         a(var0, 1);
         var7 = a(var5 = method_60(), 1);
         a(var0, 2);
         var7.writeUTF("addHighScore");
         var7.writeInt(var1);
         var7.writeUTF(var2 == null ? "" : var2);
         var7.writeUTF(var3 == null ? "" : var3);
         var8 = (var6 = a(var5)).readInt();
         if (var4 != null) {
            var4.append(var6.readUTF());
         }
      } catch (Exception var13) {
      } finally {
         a(var6, var7, var5);
      }

      return var8;
   }

   // $VF: Could not verify finally blocks. A semaphore variable has been added to preserve control flow.
   // Please report this issue to the Sporeflower issue tracker at https://github.com/hourianto/sporeflower/issues and attach the class file or JAR that caused the error.
   private static final DataInputStream a(class_15 var0, int var1, int var2, String var3) {
      HttpConnection var4 = null;
      DataInputStream var5 = null;
      DataInputStream var6 = null;
      DataOutputStream var7 = null;
      boolean var12 = false /* VF: Semaphore variable */;

      label68: {
         try {
            var12 = true;
            a(var0, 1);
            var7 = a(var4 = method_60(), 1);
            a(var0, 3);
            var7.writeUTF("getHighScore");
            var7.writeInt(var1);
            var7.writeInt(var2);
            var7.writeUTF(var3 == null ? "" : var3);
            if ((var5 = a(var4)).readInt() < 0) {
               var5.close();
               var5 = null;
               var12 = false;
            } else if (var1 == 0) {
               a((DataInputStream)null, var7, var4);
               (var7 = a(var4 = method_60(), 1)).writeUTF("getHighScore");
               var7.writeInt(-1);
               var7.writeInt(1);
               var7.writeUTF(var3 == null ? "" : var3);
               if ((var6 = a(var4)).readInt() >= 0) {
                  var6.readUTF();
                  var6.readInt();
                  field_140 = var6.readInt();
                  var12 = false;
               } else {
                  var12 = false;
               }
            } else {
               var12 = false;
            }
            break label68;
         } catch (Exception var13) {
            a(var5, var7, var4);
            var5 = null;
            var7 = null;
            var4 = null;
            var12 = false;
         } finally {
            if (var12) {
               a(var6, var7, var4);
            }
         }

         a(var6, (DataOutputStream)null, (HttpConnection)null);
         return var5;
      }

      a(var6, var7, var4);
      return var5;
   }

   private static final int a(class_15 var0, String var1, StringBuffer var2) {
      HttpConnection var3 = null;
      DataInputStream var4 = null;
      DataOutputStream var5 = null;
      int var6 = 0;

      try {
         a(var0, 1);
         var5 = a(var3 = method_60(), 1);
         a(var0, 3);
         var5.writeUTF("LookupUserProp");
         var5.writeUTF(var1);
         var6 = (var4 = a(var3)).readInt();
         if (var2 != null) {
            var2.append(var4.readUTF());
         }
      } catch (Exception var11) {
      } finally {
         a(var4, var5, var3);
      }

      return var6;
   }

   private static final int a(class_15 var0, String var1, String var2) {
      HttpConnection var3 = null;
      DataInputStream var4 = null;
      DataOutputStream var5 = null;
      int var6 = 0;

      try {
         a(var0, 1);
         var5 = a(var3 = method_60(), 1);
         a(var0, 2);
         var5.writeUTF("SetUserProp");
         var5.writeUTF(var1);
         var5.writeUTF(var2);
         var6 = (var4 = a(var3)).readInt();
      } catch (Exception var11) {
      } finally {
         a(var4, var5, var3);
      }

      return var6;
   }

   private static int a(DataInputStream var0) {
      boolean var1 = false;

      int var8;
      try {
         var0.readUTF();
         var0.readInt();
         var0.readInt();
         var0.readInt();
         field_144 = new int[var8 = var0.readInt()];
         field_142 = new String[var8];
         field_143 = new int[var8];
         field_141 = var8;

         for (int var2 = 0; var2 < field_141; var2++) {
            field_144[var2] = var0.readInt();
            field_142[var2] = var0.readUTF();
            field_143[var2] = var0.readInt();
            var0.readUTF();
         }
      } catch (Exception var6) {
         var8 = -1;
      } finally {
         a(var0, (DataOutputStream)null, (HttpConnection)null);
      }

      return var8;
   }
}
