package com.iplay.fmx33d;

import javax.microedition.lcdui.Graphics;

// $VF: renamed from: p
public final class class_16 {
   private static int a;
   private static int b;

   public static final void a() {
      int var0 = class_5.method_15(24);
      int var1 = class_5.method_20(24);
      int var2 = class_18.method_126();
      int var3 = class_18.method_133();
      a = var2 - var0 >> 1;
      b = var3 - var1;
   }

   // $VF: renamed from: a () int
   public static final int method_108() {
      return 2 * (6 + class_5.method_20(26));
   }

   public static final int b() {
      return a + class_5.method_15(25) + class_5.method_15(32);
   }

   public static final int c() {
      return b - class_5.method_20(25);
   }

   public static final void a(Graphics var0) {
      int var1 = class_5.method_15(24);
      int var2 = class_18.method_126();
      int var3 = class_5.method_20(25);
      int var4 = a + 15;
      int var5 = b - var3;
      int var6 = class_5.method_15(26);
      int var7 = var2 - var6 >> 1;
      class_18.a(24, a, b);
      class_18.a(25, var4, var5);
      class_18.a(26, var7, 6);
      a(var1);
      a(var0, var7, 6);
      method_109();
   }

   private static void a(Graphics var0, int var1, int var2) {
      int var4 = var1 + 3;
      int var3 = var2 + 2;
      int var5;
      if ((var5 = class_19.method_141()) > 0) {
         class_18.a(33, var4 + var5, var3 - 1, 17);
      }

      for (int var7 = class_19.method_145() - 1; var7 >= 0; var7--) {
         class_6 var8;
         if ((var8 = class_19.method_148(var7)).field_67) {
            int var9 = class_19.method_149(var8);
            if (var5 != 0 && var8.field_68) {
               var9 = var5 - 2;
            }

            var0.setColor(var7 == 0 ? 16777215 : 16711680);
            var0.fillRect(var4 + var9, var3 + 1, 4, 2);
            var0.fillRect(var4 + var9 + 1, var3, 2, 4);
         }
      }
   }

   private static void a(int var0) {
      int var1 = a;
      int var2 = b;
      int var3 = class_18.field_241 ? 36 : 35;
      int var4 = class_18.field_241 ? 35 : 36;
      int var5 = var1 + 3;
      int var6 = var1 + var0 + -3;
      if (var1 < 0) {
         var5 -= var1;
         var6 += var1;
      }

      class_18.a(var3, var5, var2 + 11);
      class_18.a(var4, var6, var2 + 11, 24);
   }

   // $VF: renamed from: b () void
   private static void method_109() {
      int var0 = a;
      int var1 = b;
      boolean var4 = false;
      int var5 = class_5.method_15(30);
      int var6 = class_5.method_20(30) / 10;
      int var7 = class_5.method_20(37);
      int[] var8 = class_19.field_267;
      class_18.method_134();

      for (int var9 = 0; var9 < var7; var9++) {
         int var2 = var0 + class_5.a(37, var9, 0);
         int var3 = var1 + class_5.a(37, var9, 1);
         int var13 = class_5.a(37, var9, 3);
         int var10 = class_5.a(37, var9, 4);

         for (int var11 = 0; var11 < var10; var11++) {
            class_18.method_138(var2, var3, var5, var6);
            int var12 = var3 - var6 * var8[var13++];
            class_18.a(30, var2, var12);
            var2 += var5;
         }
      }

      class_18.method_135();
   }

   public static final void a(Graphics var0, class_6 var1) {
      int var2 = class_5.method_20(26);
      int var3 = class_5.method_20(24);
      int var4 = class_18.method_129(6);
      int var5 = class_18.method_129(7) + var4 * 2 + var3;
      int var6 = var3 + class_5.method_20(25) + 2 * var4 + class_18.method_129(7);
      if (var5 < var6) {
         var5 = var6;
      }

      int var7 = (class_18.method_133() - var2 - var3 - var5) * 800 >> 10;
      int var8;
      int var9 = (var8 = class_18.method_133() - var5) - var7;
      int var10 = var1.H;
      int var11;
      if ((var11 = (var7 * var10 << 10) / 256 >> 10) > var7) {
         var11 = var7;
      }

      int var12 = class_18.method_122(6);
      int var14 = 2 + var12;
      class_18.b(6, 2, var9 - var4, 0);
      class_18.b(6, 2, var8, 1);
      if (class_19.field_268) {
         class_18.b(7, 2, var8 + var4 + 1, 0);
      }

      int[] var15 = class_5.method_10(28);
      int var16 = 0;
      int var17 = var8 - var11;

      for (int var18 = 2; var18 < var14; var18++) {
         var0.setColor(var15[var16++]);
         var0.drawLine(var18, var9, var18, var17);
      }

      if (var17 < var8) {
         var15 = class_5.method_10(29);
         var16 = 0;

         for (int var21 = 2; var21 < var14; var21++) {
            var0.setColor(var15[var16++]);
            var0.drawLine(var21, var17, var21, var8);
         }
      }
   }
}
