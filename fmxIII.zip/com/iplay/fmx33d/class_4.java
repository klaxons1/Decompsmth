package com.iplay.fmx33d;

// $VF: renamed from: d
public final class class_4 {
   public static final int MBOOSTER_MAX_INSTANCES = 2;
   public boolean a;
   // $VF: renamed from: a int
   private int field_43;
   private int b;
   private int c;
   private int d;
   // $VF: renamed from: b boolean
   private boolean field_44;
   private int e;
   private int f;
   private int g;
   // $VF: renamed from: a int[]
   private int[] field_45;
   // $VF: renamed from: b int[]
   private int[] field_46;
   // $VF: renamed from: c int[]
   private int[] field_47;
   // $VF: renamed from: a short[][]
   private short[][] field_48;

   public class_4(int var1) {
      this.e = var1;
   }

   public final void a(int var1, boolean var2) {
      this.field_44 = var2;
      if (var1 >= 0) {
         this.f = 0;
         this.d = Integer.MIN_VALUE;
         this.c = Integer.MAX_VALUE;
         this.b = Integer.MIN_VALUE;
         this.field_43 = Integer.MAX_VALUE;
         this.g = class_5.method_20(var1);
         this.field_45 = new int[this.g];
         this.field_46 = new int[this.g << 1];
         this.field_47 = new int[this.g * 4];
         this.field_48 = new short[this.g][];

         for (int var3 = 0; var3 < this.g; var3++) {
            int var4 = class_5.a(var1, var3, 0);
            int var5 = -1;
            int var6;
            if ((var6 = class_5.b(575, 0, var4)) >= 0) {
               var5 = class_5.a(575, var6, 1);
            }

            int var7 = class_5.a(var1, var3, 1) << 0;
            int var8 = class_5.a(var1, var3, 2) << 0;
            int var9 = var3 << 1;
            this.field_46[0 + var9] = var7;
            this.field_46[1 + var9] = var8;
            int var10 = class_5.method_20(var5);
            this.field_45[var3] = var10;
            this.field_48[var3] = class_5.method_9(var5);
            int var11 = Integer.MIN_VALUE;
            int var12 = Integer.MAX_VALUE;
            short var13 = this.field_48[var3][this.field_45[var3] - 1 << 1];
            short var14 = this.field_48[var3][0];
            int var15 = 1;

            for (int var16 = 0; var16 < var10; var16++) {
               short var17;
               if ((var17 = this.field_48[var3][var15]) < var12) {
                  var12 = var17;
               }

               if (var17 > var11) {
                  var11 = var17;
               }

               var15 += 2;
            }

            int var21 = var14 + var7;
            int var20 = var13 + var7;
            var12 += var8;
            var11 += var8;
            int var22 = var3 * 4;
            this.field_47[0 + var22] = var21;
            this.field_47[1 + var22] = var12;
            this.field_47[2 + var22] = var20;
            this.field_47[3 + var22] = var11;
            if (this.field_43 > var21) {
               this.field_43 = var21;
            }

            if (this.b < var20) {
               this.b = var20;
            }

            if (this.c > var12) {
               this.c = var12;
            }

            if (this.d < var11) {
               this.d = var11;
            }
         }
      }
   }

   public final int a(int var1) {
      int var2;
      return (var2 = this.b(var1)) >= 0 ? this.a(var2, var1) : 0;
   }

   private int b(int var1) {
      var1 >>= this.e;
      int var2 = this.f * 4;
      int var3 = this.field_47[0 + var2];
      int var4 = this.field_47[2 + var2];
      if (var1 >= var3 && var1 < var4) {
         return this.f;
      }

      var2 = 0;

      for (int var5 = 0; var5 < this.g; var5++) {
         var3 = this.field_47[0 + var2];
         var4 = this.field_47[2 + var2];
         if (var1 >= var3 && var1 < var4) {
            this.f = var5;
            return var5;
         }

         var2 += 4;
      }

      return -1;
   }

   public final int a(class_21 var1, class_21 var2, int var3) {
      if (this.a && this.g != 0) {
         int var4;
         return (var4 = this.b(var1.field_278)) >= 0 ? this.a(var4, var1, var2, var3) : 0;
      } else {
         return 0;
      }
   }

   public final boolean a(boolean var1, int var2, int var3) {
      if (this.g == 0) {
         this.a = false;
         return false;
      }

      class_4 var10000;
      boolean var10001;
      label53: {
         this.a = var1;
         int var4 = var2 >> this.e;
         if (this.field_44) {
            if (var4 >= this.field_43 && var4 <= this.b) {
               if (this.a || this.a(var2) + 0 >= var3) {
                  return this.a;
               }

               var10000 = this;
               var10001 = true;
               break label53;
            }

            var10000 = this;
         } else {
            int var5 = -1;
            int var6 = 0;

            for (int var7 = 0; var7 < this.g; var7++) {
               int var8 = this.field_47[0 + var6];
               int var9 = this.field_47[2 + var6];
               if (var4 >= var8 && var4 < var9 && (this.a || this.a(var7, var2) + 0 < var3)) {
                  var5 = var7;
               }

               var6 += 4;
            }

            var10000 = this;
            if (var5 >= 0) {
               var10001 = true;
               break label53;
            }
         }

         var10001 = false;
      }

      var10000.a = var10001;
      return this.a;
   }

   private int a(int var1, class_21 var2, class_21 var3, int var4) {
      int var5 = var2.field_278 >> this.e;
      int var6 = var2.field_279 >> this.e;
      int var7 = var1 * 4;
      int var8 = this.field_47[0 + var7];
      int var9 = this.field_47[2 + var7];
      if (var5 >= var8 && var5 <= var9) {
         var5 -= this.field_46[0 + (var1 << 1)];
         var6 -= this.field_46[1 + (var1 << 1)];
         short[] var10;
         int var11 = a(var10 = this.field_48[var1], this.field_45[var1], var5 - 1024);
         int var12 = a(var10, this.field_45[var1], var5 + 1024);
         int var13 = Integer.MAX_VALUE;
         int var14 = var11;

         for (int var15 = var11; var15 <= var12; var15++) {
            int var16 = var15 << 1;
            short var17 = var10[var16++];
            short var18 = var10[var16++];
            short var19 = var10[var16++];
            short var20 = var10[var16];
            int var21;
            if ((var21 = a(var17, var18, var19, var20, var5, var6)) < var13) {
               var13 = var21;
               var14 = var15;
            }
         }

         int var34 = var14 << 1;
         short var41 = var10[var34++];
         short var42 = var10[var34++];
         short var43 = var10[var34++];
         short var44 = var10[var34];
         int var45 = var43 - var41;
         int var46 = var44 - var42;
         int var22 = var5 - var41;
         int var23 = var6 - var42;
         int var24 = -var46;
         int var25 = var45;
         int var26;
         if ((var26 = var22 * var24 + var23 * var25) > 0) {
            return 0;
         }

         int var27 = var45 * var22 + var46 * var23;
         int var28 = var45 * var45 + var46 * var46 >> 10;
         var27 /= var28;
         int var29 = var41 + (var27 * var45 >> 10);
         int var30 = var42 + (var27 * var46 >> 10);
         var22 = var29 - var5 << this.e;
         var23 = var30 - var6 << this.e;
         if (var4 != 1024) {
            int var48;
            var22 = (var48 = var22 * var4) >> 10;
            int var50;
            var23 = (var50 = var23 * var4) >> 10;
         }

         if (var22 > 256 || var22 < -256) {
            var2.field_278 += var22;
         }

         var2.field_279 += var23;
         int var31 = 1048576 / class_18.method_131(var28);
         if (var3 != null) {
            var3.field_278 = var45 * var31 >> 10;
            var3.field_279 = var46 * var31 >> 10;
         }

         int var51;
         return var51 = var26 / var28;
      } else {
         return 0;
      }
   }

   private static int a(short[] var0, int var1, int var2) {
      int var6 = var1 - 1;
      int var7 = 0;

      short var3;
      short var4;
      int var5;
      do {
         int var8 = (var5 = var6 + var7 >> 1) << 1;
         var3 = var0[var8];
         var4 = var0[var8 + 2];
         if (var2 < var3) {
            var6 = var5;
         } else {
            var7 = var5 + 1;
         }
      } while ((var2 < var3 || var2 >= var4) && var7 < var6);

      return var5;
   }

   private static int a(int var0, int var1, int var2, int var3, int var4, int var5) {
      int var6 = var2 - var0;
      int var7 = var3 - var1;
      int var8 = var4 - var0;
      int var9 = var5 - var1;
      int var10;
      if ((var10 = var8 * var6 + var9 * var7) <= 0) {
         return var8 * var8 + var9 * var9 >> 10;
      } else {
         int var11 = var6 * var6 + var7 * var7;
         if (var10 >= var11) {
            int var16 = var4 - var2;
            int var13 = var5 - var3;
            return var16 * var16 + var13 * var13 >> 10;
         } else {
            int var12 = var8 * var8 + var9 * var9 >> 10;
            var10 >>= 10;
            var11 >>= 10;
            return var12 - var10 * var10 / var11;
         }
      }
   }

   private int a(int var1, int var2) {
      var2 = (var2 >> this.e) - this.field_46[0 + (var1 << 1)];
      int var3;
      int var4 = (var3 = this.field_45[var1]) - 1;
      short[] var5;
      int var6;
      if ((var6 = a(var5 = this.field_48[var1], var3, var2)) < 0) {
         var6 = 0;
      }

      if (var6 > var4 - 1) {
         var6 = var4 - 1;
      }

      int var7;
      if ((var7 = var6 + 1) > var4) {
         var7 = var4;
      }

      var6 <<= 1;
      var7 <<= 1;
      short var8 = var5[var6];
      short var9 = var5[var7];
      int var10 = (var2 - var8 << 10) / (var9 - var8);
      short var11 = var5[var6 + 1];
      short var12;
      int var13 = (var12 = var5[var7 + 1]) - var11;
      return var11 + (var10 * var13 >> 10) + this.field_46[1 + (var1 << 1)] << this.e;
   }
}
