package com.iplay.fmx33d;

// $VF: renamed from: i
public final class class_9 {
   public int a;
   // $VF: renamed from: a v
   public static final class_21 field_125 = new class_21();
   public static final class_21 b = new class_21();
   // $VF: renamed from: a v[]
   public static class_21[] field_126;
   // $VF: renamed from: a u[]
   public static class_20[] field_127;
   // $VF: renamed from: b u[]
   public static class_20[] field_128;
   public static class_20[] c;
   // $VF: renamed from: b v[]
   public static class_21[] field_129;
   public static class_20[] d;
   // $VF: renamed from: c v[]
   public static class_21[] field_130;
   // $VF: renamed from: d v[]
   public static class_21[] field_131;
   public static class_20[] e;
   // $VF: renamed from: a n[]
   public static class_14[] field_132;
   // $VF: renamed from: a c[]
   public static class_2[] field_133;

   public class_9(int var1) {
      this.a = var1;
   }

   public final void a(int var1, int var2) {
      class_2.field_41 = var1;
      class_2.field_42 = var2;
      class_14.field_166 = var1;
      class_14.field_167 = var2;
   }

   public final void a(int var1) {
      field_132 = new class_14[var1];
      field_133 = new class_2[var1];
      field_126 = new class_21[var1];
      field_127 = new class_20[var1];
      field_128 = new class_20[var1];
      field_129 = new class_21[var1];
      c = new class_20[var1];
      d = new class_20[var1];
      field_130 = new class_21[var1];
      field_131 = new class_21[var1];
      e = new class_20[var1];

      for (int var2 = 0; var2 < var1; var2++) {
         field_132[var2] = new class_14();
         field_133[var2] = new class_2(191);
         field_126[var2] = new class_21();
         field_127[var2] = new class_20();
         field_128[var2] = new class_20();
         field_129[var2] = new class_21();
         c[var2] = new class_20();
         d[var2] = new class_20();
         field_130[var2] = new class_21();
         field_131[var2] = new class_21();
         e[var2] = new class_20();
      }
   }

   public final void b(int var1) {
      class_6 var2 = class_19.method_148(var1);
      class_14 var3 = field_132[var1];
      class_21 var4 = field_126[var1];
      class_20 var5 = field_127[var1];
      class_20 var6 = field_128[var1];
      class_21 var7 = field_130[var1];
      class_21 var8 = field_131[var1];
      class_20 var9 = e[var1];
      c[var1].a(var5);
      field_129[var1].a(var4);
      d[var1].a(var6);
      class_20 var10 = class_20.field_276;
      int var11 = var2.x;
      int var12 = var2.y;
      int var13 = -var1 * (512 << this.a);
      if (var2.method_29()) {
         a(var2, var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13);
      } else {
         class_2 var14 = field_133[var1];
         var5.a(var14.field_35);
         var4.a(var14.a);
         var8.a(var14.b);
         var7.a(var14.c);
         var9.a(var14.field_35);
      }

      var4.c(this.a);
      var8.c(this.a);
      var7.c(this.a);
   }

   private static void a(
      class_6 var0,
      class_14 var1,
      class_21 var2,
      class_20 var3,
      class_20 var4,
      class_21 var5,
      class_21 var6,
      class_20 var7,
      class_20 var8,
      int var9,
      int var10,
      int var11
   ) {
      int var12 = var0.A * var0.field_80;
      int var13 = var0.z * var0.field_80;
      var3.b(var13, var12);
      var2.a(var9, var10, var11);
      var4.a(class_20.field_275);
      if (var0.field_80 < 0) {
         var8.a(class_21.e, class_21.c, class_21.f);
         var4.c(var8);
         var3.c(var8);
      }

      var6.a(var0.method_34(2) - var9, var0.method_37(2) - var10, 0);
      var3.b(var6);
      var5.a(var0.method_34(3) - var9, var0.method_37(3) - var10, 0);
      var3.b(var5);
      var1.a(var0, var3);
      if (var0.l > 0) {
         int var14;
         int var15 = class_18.e(var14 = var0.l);
         int var16 = class_18.d(var14);
         var8.a(var15, var16);
         var4.c(var8);
         var3.c(var8);
      }

      var3.a(var6, var2);
      var3.a(var5, var2);
      int var17;
      int var18 = class_18.d(var17 = var6.field_278 >> 5);
      int var19 = class_18.e(var17);
      var7.b(var19, -var18 * var0.field_80);
      var7.b(var3);
      var1.a(var2, var3);
   }

   public final void a(class_6 var1) {
      int var2 = class_19.method_161(var1);
      class_2 var3 = field_133[var2];
      class_21 var4 = field_126[var2];
      class_21 var5 = field_129[var2];
      class_20 var6 = field_127[var2];
      class_20 var7 = c[var2];
      field_125.a(var4);
      field_125.b(this.a);
      b.a(var5);
      b.b(this.a);
      var3.a(field_125, var6, b, var7);
      class_14 var8 = field_132[var2];
      class_20 var9 = field_128[var2];
      class_20 var10 = d[var2];
      var8.a(var1, 0, var10, var9);
   }

   public final void c(int var1) {
      field_133[var1].a();
      field_132[var1].a();
   }

   // $VF: renamed from: a (int) v
   public final class_21 method_53(int var1) {
      return field_132[var1].field_156;
   }

   // $VF: renamed from: b (int) v
   public final class_21 method_55(int var1) {
      return field_132[var1].b;
   }

   // $VF: renamed from: c (int) v
   public final class_21 method_56(int var1) {
      return field_133[var1].a;
   }

   public final void a(class_8 var1, int var2) {
      var1.a(field_132[var2].field_157, field_132[var2].field_158, field_132[var2].field_159);
      var1.a(field_133[var2].field_39, field_133[var2].field_36, field_133[var2].field_37);
   }

   public final class_21 d(int var1) {
      return field_126[var1];
   }

   public final class_20 a(int var1, boolean var2) {
      return var2 ? field_128[var1] : field_127[var1];
   }

   // $VF: renamed from: a (int, boolean) v
   public final class_21 method_57(int var1, boolean var2) {
      return var2 ? field_130[var1] : field_131[var1];
   }

   // $VF: renamed from: a (int) u
   public final class_20 method_54(int var1) {
      return e[var1];
   }

   // $VF: renamed from: a (int, int) v
   public final class_21 method_51(int var1, int var2) {
      return field_132[var1].a(var2);
   }

   // $VF: renamed from: a (int, int) u
   public final class_20 method_52(int var1, int var2) {
      return field_132[var1].method_63(var2);
   }
}
