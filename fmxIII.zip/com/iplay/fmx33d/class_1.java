package com.iplay.fmx33d;

import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
import javax.microedition.m3g.Appearance;
import javax.microedition.m3g.Background;
import javax.microedition.m3g.Camera;
import javax.microedition.m3g.CompositingMode;
import javax.microedition.m3g.Graphics3D;
import javax.microedition.m3g.Image2D;
import javax.microedition.m3g.IndexBuffer;
import javax.microedition.m3g.Light;
import javax.microedition.m3g.Loader;
import javax.microedition.m3g.Mesh;
import javax.microedition.m3g.Node;
import javax.microedition.m3g.Object3D;
import javax.microedition.m3g.PolygonMode;
import javax.microedition.m3g.Texture2D;
import javax.microedition.m3g.Transform;
import javax.microedition.m3g.TriangleStripArray;
import javax.microedition.m3g.VertexArray;
import javax.microedition.m3g.VertexBuffer;

// $VF: renamed from: b
public final class class_1 {
   private static final short[] a = new short[9];
   private static final short[] b = new short[288];
   // $VF: renamed from: a byte[]
   private static final byte[] field_6 = new byte[192];
   private static final short[] c = new short[12];
   // $VF: renamed from: b byte[]
   private static final byte[] field_7 = new byte[8];
   // $VF: renamed from: a javax.microedition.m3g.Graphics3D
   private static Graphics3D field_8;
   // $VF: renamed from: a javax.microedition.m3g.Light
   private static Light field_9;
   // $VF: renamed from: a javax.microedition.m3g.Background
   private static Background field_10;
   // $VF: renamed from: a javax.microedition.m3g.Camera
   private static Camera field_11;
   // $VF: renamed from: a javax.microedition.m3g.CompositingMode
   private static CompositingMode field_12;
   // $VF: renamed from: b javax.microedition.m3g.CompositingMode
   private static CompositingMode field_13;
   // $VF: renamed from: a javax.microedition.m3g.Appearance
   private static Appearance field_14;
   // $VF: renamed from: a boolean
   private boolean field_15;
   // $VF: renamed from: a javax.microedition.m3g.TriangleStripArray
   private static TriangleStripArray field_16;
   // $VF: renamed from: a javax.microedition.m3g.VertexBuffer
   private static VertexBuffer field_17;
   // $VF: renamed from: a javax.microedition.m3g.VertexArray
   private static VertexArray field_18;
   // $VF: renamed from: b javax.microedition.m3g.VertexArray
   private static VertexArray field_19;
   // $VF: renamed from: b javax.microedition.m3g.TriangleStripArray
   private static TriangleStripArray field_20;
   // $VF: renamed from: b javax.microedition.m3g.VertexBuffer
   private static VertexBuffer field_21;
   // $VF: renamed from: c javax.microedition.m3g.VertexArray
   private static VertexArray field_22;
   private static VertexArray d;
   // $VF: renamed from: a javax.microedition.m3g.Texture2D
   private static Texture2D field_23;
   // $VF: renamed from: b javax.microedition.m3g.Texture2D
   private static Texture2D field_24;
   // $VF: renamed from: a int[]
   private static int[] field_25;
   // $VF: renamed from: a javax.microedition.m3g.Mesh[]
   private static Mesh[] field_26;
   // $VF: renamed from: a float[]
   private static float[] field_27;
   // $VF: renamed from: b float[]
   private static float[] field_28;
   // $VF: renamed from: a javax.microedition.m3g.Transform
   private static Transform field_29;
   // $VF: renamed from: b javax.microedition.m3g.Transform
   private static Transform field_30;
   // $VF: renamed from: b int[]
   private static int[] field_31;
   // $VF: renamed from: a q
   private class_17 field_32;
   // $VF: renamed from: a int
   private int field_33;
   // $VF: renamed from: b int
   private int field_34;

   public final class_17 a() {
      return this.field_32;
   }

   // $VF: renamed from: a () int
   public final int method_0() {
      return this.field_33;
   }

   public final int b() {
      return this.field_34;
   }

   private static boolean a(int var0) {
      boolean var1 = true;
      int var2;
      if ((var2 = class_5.a(320, var0, 2)) >= 0 && class_5.method_7(var2) != 4) {
         try {
            Object3D[] var5 = Loader.load(class_5.method_22(var2, ".bin"));
            field_26[var0] = (Mesh)var5[0];
            field_25[var0] = 228;
            int var4 = class_5.a(320, var0, 0);
            int var9;
            if ((var9 = class_5.a(320, var0, 1)) >= 0) {
               label36: {
                  Appearance var6 = field_26[var0].getAppearance(0);
                  Appearance var10000;
                  int var10001;
                  Texture2D var10002;
                  if (var9 == 16) {
                     var10000 = var6;
                     var10001 = 0;
                     var10002 = field_23;
                  } else {
                     if (var9 != 17) {
                        break label36;
                     }

                     var10000 = var6;
                     var10001 = 0;
                     var10002 = field_24;
                  }

                  var10000.setTexture(var10001, var10002);
               }

               if (var4 < 0 && field_26[var0].getVertexBuffer().getColors() != null) {
                  var4 = 1;
               }

               if (var4 >= 0 || ((Node)field_26[var0]).getAlphaFactor() != 1.0F) {
                  field_25[var0] = 227;
               }
            } else {
               field_25[var0] = 224;
            }
         } catch (Exception var8) {
            var1 = false;
         }
      }

      return var1;
   }

   // $VF: renamed from: a () void
   public final void method_1() {
      try {
         Image var1 = class_5.method_6(16);
         Image2D var2 = new Image2D(100, var1);
         field_23 = new Texture2D(var2);
         field_23.setBlending(228);
         field_23.setWrapping(240, 240);
         field_23.setFiltering(208, 210);
         var1 = class_5.method_6(17);
         var2 = new Image2D(100, var1);
         field_24 = new Texture2D(var2);
         field_24.setBlending(228);
         field_24.setWrapping(240, 240);
         field_24.setFiltering(208, 210);
         int var3;
         field_25 = new int[var3 = class_5.method_20(320)];
         field_26 = new Mesh[var3];

         for (int var4 = 0; var4 < var3; var4++) {
            a(var4);
            class_15.g(586 + var4);
         }
      } catch (Exception var6) {
      }

      int[] var8 = new int[96];
      int[] var10 = new int[32];

      for (int var11 = 0; var11 < 32; var11++) {
         var10[var11] = 3;
         int var13 = var11 * 3;
         var8[var13] = var13;
         var8[var13 + 1] = var13 + 1;
         var8[var13 + 2] = var13 + 2;
      }

      field_20 = new TriangleStripArray(var8, var10);
      field_22 = new VertexArray(96, 3, 2);
      d = new VertexArray(96, 2, 1);
      field_21 = new VertexBuffer();
      field_21.setPositions(field_22, 1.0F, null);
      field_21.setTexCoords(0, d, 0.0078125F, null);
      int[] var12 = new int[]{0, 1, 3, 2};
      int[] var14 = new int[]{4};
      field_16 = new TriangleStripArray(var12, var14);
      field_18 = new VertexArray(4, 3, 2);
      field_19 = new VertexArray(4, 2, 1);
      field_17 = new VertexBuffer();
      field_17.setPositions(field_18, 1.0F, null);
      field_17.setTexCoords(0, field_19, 0.0078125F, null);
      field_13 = new CompositingMode();
      field_13.setBlending(66);
      field_13.setColorWriteEnable(true);
      field_13.setAlphaWriteEnable(true);
      field_13.setDepthWriteEnable(false);
      field_13.setDepthTestEnable(false);
      field_12 = new CompositingMode();
      field_12.setBlending(65);
      field_12.setColorWriteEnable(true);
      field_12.setAlphaWriteEnable(true);
      field_12.setDepthWriteEnable(false);
      field_12.setDepthTestEnable(true);
      PolygonMode var5;
      (var5 = new PolygonMode()).setPerspectiveCorrectionEnable(false);
      var5.setShading(165);
      var5.setCulling(160);
      field_14 = new Appearance();
      field_14.setPolygonMode(var5);
      field_14.setTexture(0, field_24);
   }

   public final void a(int var1, int var2) {
      this.field_33 = var1;
      this.field_34 = var2;
      if (this.field_32 == null) {
         this.field_32 = new class_17();
      }

      this.field_32.a(var1, var2);
      if (field_11 == null) {
         field_30 = new Transform();
         field_29 = new Transform();
         field_27 = new float[16];
         field_27[15] = 1.0F;
         field_28 = new float[16];
         field_28[15] = 1.0F;
         field_9 = new Light();
         field_9.setMode(128);
         field_9.setIntensity(1.0F);
         field_10 = new Background();
         field_10.setColorClearEnable(false);
         field_10.setDepthClearEnable(true);
         field_8 = Graphics3D.getInstance();
         field_8.addLight(field_9, new Transform());
         field_11 = new Camera();
      }

      field_11.setPerspective(60.833336F, (float)var1 / var2, 64.0F, 32767.0F);
      field_31 = class_5.method_10(319);
   }

   public final void a(Graphics var1) {
      class_21 var2 = this.field_32.a;
      class_20 var3 = this.field_32.field_222;
      float var4 = 9.765625E-4F * var3.c.field_278;
      float var5 = 9.765625E-4F * var3.c.field_279;
      float var6;
      float var7 = -(var6 = 9.765625E-4F * var3.c.field_280);
      float var8 = var4;
      float var9 = -var5 * var8;
      float var10 = var4 * var8 - var6 * var7;
      float var11 = var5 * var7;
      field_27[0] = var7;
      field_27[1] = var9;
      field_27[2] = -var4;
      field_27[3] = var2.field_278;
      field_27[5] = var10;
      field_27[6] = -var5;
      field_27[7] = var2.field_279;
      field_27[8] = var8;
      field_27[9] = var11;
      field_27[10] = -var6;
      field_27[11] = var2.field_280;
      field_29.setIdentity();
      field_29.set(field_27);
      field_8.bindTarget(var1, true, 8);
      field_8.clear(field_10);
      field_8.setCamera(field_11, field_29);
   }

   public final void a(boolean var1) {
      this.field_15 = !var1;
   }

   public final void a(int var1, class_20 var2, class_21 var3) {
      int var4;
      if ((var4 = class_5.a(320, var1, 3)) >= 0) {
         class_21 var5 = new class_21();
         int[] var6 = class_5.method_10(var4);
         int var7 = var6[3];
         var5.a(var6, 0);
         if (this.field_32.a(var5, var7, var2, var3) == -1) {
            return;
         }
      }

      field_28[0] = 9.765625E-4F * var2.a.field_278;
      field_28[1] = 9.765625E-4F * var2.b.field_278;
      field_28[2] = 9.765625E-4F * var2.c.field_278;
      field_28[3] = var3.field_278;
      field_28[4] = 9.765625E-4F * var2.a.field_279;
      field_28[5] = 9.765625E-4F * var2.b.field_279;
      field_28[6] = 9.765625E-4F * var2.c.field_279;
      field_28[7] = var3.field_279;
      field_28[8] = 9.765625E-4F * var2.a.field_280;
      field_28[9] = 9.765625E-4F * var2.b.field_280;
      field_28[10] = 9.765625E-4F * var2.c.field_280;
      field_28[11] = var3.field_280;
      field_30.setIdentity();
      field_30.set(field_28);
      Mesh var8;
      if ((var8 = field_26[var1]) != null) {
         int var9;
         if ((var9 = field_25[var1]) == 227 && !this.field_15) {
            var8.getAppearance(0).getTexture(0).setBlending(var9);
         }

         field_8.render((Node)var8, field_30);
         if (var9 == 227 && !this.field_15) {
            var8.getAppearance(0).getTexture(0).setBlending(228);
         }
      }
   }

   public final void b(int var1, class_20 var2, class_21 var3) {
      int var4 = class_5.a(320, var1, 2);
      int var5 = class_5.a(320, var1, 4);
      int var6 = class_5.a(320, var1, 5);
      int[] var7 = class_5.method_10(var4);
      int[] var8 = class_5.method_10(var5);
      int[] var9 = class_5.method_10(var6);
      int var10 = class_5.method_15(var4);
      int var11 = var8[0];
      int var12 = 1;
      int var13 = 0;
      short[] var14 = b;
      byte[] var15 = field_6;
      int var16 = 0;
      int var17 = 0;

      for (int var18 = 0; var18 < var11; var18++) {
         int var19 = var8[var12++];

         for (int var22 = 0; var22 < var19; var22++) {
            int var21 = var8[var12++] * var10;
            var14[var16++] = (short)var7[0 + var21];
            var14[var16++] = (short)var7[1 + var21];
            var14[var16++] = (short)var7[2 + var21];
            var15[var17++] = (byte)(var9[var13++] >> 10);
            var15[var17++] = (byte)(var9[var13++] >> 10);
         }
      }

      for (int var27 = var11; var27 < 32; var27++) {
         System.arraycopy(a, 0, var14, var16, 9);
         var16 += 9;
      }

      field_22.set(0, 96, var14);
      d.set(0, 96, var15);
      field_28[0] = 9.765625E-4F * var2.a.field_278;
      field_28[1] = 9.765625E-4F * var2.b.field_278;
      field_28[2] = 9.765625E-4F * var2.c.field_278;
      field_28[3] = var3.field_278;
      field_28[4] = 9.765625E-4F * var2.a.field_279;
      field_28[5] = 9.765625E-4F * var2.b.field_279;
      field_28[6] = 9.765625E-4F * var2.c.field_279;
      field_28[7] = var3.field_279;
      field_28[8] = 9.765625E-4F * var2.a.field_280;
      field_28[9] = 9.765625E-4F * var2.b.field_280;
      field_28[10] = 9.765625E-4F * var2.c.field_280;
      field_28[11] = var3.field_280;
      field_30.setIdentity();
      field_30.set(field_28);
      field_14.setCompositingMode(field_13);
      field_8.render(field_21, (IndexBuffer)field_20, field_14, field_30);
   }

   public final void a(int var1, int var2, int var3, int var4, int var5) {
      short[] var6 = c;
      short var7;
      short var8 = (short)(-(var7 = (short)(var2 >> 1)));
      var6[0] = var8;
      var6[1] = var8;
      var6[3] = var7;
      var6[4] = var8;
      var6[6] = var7;
      var6[7] = var7;
      var6[9] = var8;
      var6[10] = var7;
      int[] var9 = field_31;
      int var10 = var1 * 4;
      byte var11 = (byte)var9[1 + var10];
      byte var12 = (byte)var9[2 + var10];
      int var13 = var9[3 + var10] - 1;
      byte var14 = (byte)((var11 & 255) + var13);
      byte var15 = (byte)((var12 & 255) + var13);
      byte[] var16 = field_7;
      var16[0] = var11;
      var16[1] = var12;
      var16[2] = var14;
      var16[3] = var12;
      var16[4] = var14;
      var16[5] = var15;
      var16[6] = var11;
      var16[7] = var15;
      field_18.set(0, 4, var6);
      field_19.set(0, 4, var16);

      for (int var17 = 0; var17 < 11; var17++) {
         field_28[var17] = -field_27[var17];
      }

      field_28[3] = var3;
      field_28[7] = var4;
      field_28[11] = var5;
      field_30.setIdentity();
      field_30.set(field_28);
      field_14.setCompositingMode(field_12);
      field_8.render(field_17, (IndexBuffer)field_16, field_14, field_30);
   }

   // $VF: renamed from: b () void
   public final void method_2() {
      field_8.releaseTarget();
   }
}
