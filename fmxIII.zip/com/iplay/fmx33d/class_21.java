package com.iplay.fmx33d;

// $VF: renamed from: v
public final class class_21 {
   public static final class_21 a = new class_21(0, 0, 0);
   public static final class_21 b = new class_21(1024, 0, 0);
   public static final class_21 c = new class_21(0, 1024, 0);
   public static final class_21 d = new class_21(0, 0, 1024);
   public static final class_21 e = new class_21(-1024, 0, 0);
   public static final class_21 f;
   public static final class_21 g;
   public static final class_21 h;
   public static final class_21 i;
   // $VF: renamed from: a int
   public int field_278;
   // $VF: renamed from: b int
   public int field_279;
   // $VF: renamed from: c int
   public int field_280;

   public class_21() {
   }

   public final String toString() {
      return (String)null;
   }

   public class_21(class_21 var1) {
      this.a(var1);
   }

   public class_21(int var1, int var2, int var3) {
      this.a(var1, var2, var3);
   }

   public final void a(int var1, int var2, int var3) {
      this.field_278 = var1;
      this.field_279 = var2;
      this.field_280 = var3;
   }

   public final void a(int[] var1, int var2) {
      this.field_278 = var1[var2++];
      this.field_279 = var1[var2++];
      this.field_280 = var1[var2];
   }

   public final void a(class_21 var1) {
      this.field_278 = var1.field_278;
      this.field_279 = var1.field_279;
      this.field_280 = var1.field_280;
   }

   public final void a(class_21 var1, class_21 var2) {
      this.field_278 = var1.field_278 - var2.field_278;
      this.field_279 = var1.field_279 - var2.field_279;
      this.field_280 = var1.field_280 - var2.field_280;
   }

   public final void a(class_21 var1, int var2) {
      int var3 = 1024 - var2;
      this.field_278 = this.field_278 * var2 + var1.field_278 * var3 >> 10;
      this.field_279 = this.field_279 * var2 + var1.field_279 * var3 >> 10;
      this.field_280 = this.field_280 * var2 + var1.field_280 * var3 >> 10;
   }

   // $VF: renamed from: a (v) int
   public final int method_166(class_21 var1) {
      long var2 = this.field_278;
      long var4 = this.field_279;
      long var6 = this.field_280;
      long var8 = var1.field_278;
      long var10 = var1.field_279;
      long var12 = var1.field_280;
      return (int)(var2 * var8 + var4 * var10 + var6 * var12 >> 10);
   }

   public final void b(class_21 var1, class_21 var2) {
      long var3 = var1.field_278;
      long var5 = var1.field_279;
      long var7 = var1.field_280;
      long var9 = var2.field_278;
      long var11 = var2.field_279;
      long var13 = var2.field_280;
      this.field_278 = (int)(var5 * var13 - var7 * var11 >> 10);
      this.field_279 = (int)(var7 * var9 - var3 * var13 >> 10);
      this.field_280 = (int)(var3 * var11 - var5 * var9 >> 10);
   }

   public final void a() {
      long var1 = this.field_278;
      long var3 = this.field_279;
      long var5 = this.field_280;
      int var9 = class_18.method_131((int)(var1 * var1 + var3 * var3 + var5 * var5 >> 10));
      this.field_278 <<= 10;
      this.field_278 /= var9;
      this.field_279 <<= 10;
      this.field_279 /= var9;
      this.field_280 <<= 10;
      this.field_280 /= var9;
   }

   public final void b(class_21 var1) {
      this.field_278 = this.field_278 + var1.field_278;
      this.field_279 = this.field_279 + var1.field_279;
      this.field_280 = this.field_280 + var1.field_280;
   }

   public final void b(int var1, int var2, int var3) {
      this.field_278 += var1;
      this.field_279 += var2;
      this.field_280 += var3;
   }

   public final void c(class_21 var1) {
      this.field_278 = this.field_278 - var1.field_278;
      this.field_279 = this.field_279 - var1.field_279;
      this.field_280 = this.field_280 - var1.field_280;
   }

   public final void a(int var1) {
      if (var1 != 1024) {
         class_21 var10000;
         int var10001;
         if (var1 == 512) {
            this.field_278 >>= 1;
            this.field_279 >>= 1;
            var10000 = this;
            var10001 = this.field_280 >> 1;
         } else {
            long var2 = (long)this.field_278 * var1;
            long var4 = (long)this.field_279 * var1;
            long var6 = (long)this.field_280 * var1;
            this.field_278 = (int)(var2 >> 10);
            this.field_279 = (int)(var4 >> 10);
            var10000 = this;
            var10001 = (int)(var6 >> 10);
         }

         var10000.field_280 = var10001;
      }
   }

   public final void b(int var1) {
      this.field_278 <<= var1;
      this.field_279 <<= var1;
      this.field_280 <<= var1;
   }

   public final void c(int var1) {
      this.field_278 >>= var1;
      this.field_279 >>= var1;
      this.field_280 >>= var1;
   }

   // $VF: renamed from: a () int
   public final int method_167() {
      long var1 = this.field_278;
      long var3 = this.field_279;
      long var5 = this.field_280;
      return class_18.method_131((int)(var1 * var1 + var3 * var3 + var5 * var5 >> 10));
   }

   public final int b() {
      long var1 = this.field_278;
      long var3 = this.field_279;
      long var5 = this.field_280;
      return (int)(var1 * var1 + var3 * var3 + var5 * var5 >> 10);
   }

   // $VF: widened method access to satisfy Java override rules
   static {
      new class_21(0, -1024, 0);
      f = new class_21(0, 0, -1024);
      g = new class_21();
      h = new class_21();
      i = new class_21();
      new class_21();
      new class_21();
      new class_21();
   }
}
