package com.iplay.fmx33d;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Vector;
import javax.microedition.lcdui.Font;
import javax.microedition.lcdui.Graphics;
import javax.microedition.midlet.MIDlet;

// $VF: renamed from: o
public final class class_15 {
   public static final int MBOOSTER_MAX_INSTANCES = 1;
   private static String a;
   private static String b;
   private static int d;
   // $VF: renamed from: b boolean
   private static boolean field_168;
   private static boolean c;
   // $VF: renamed from: d boolean
   private static boolean field_169;
   private static boolean e;
   // $VF: renamed from: a java.lang.String[]
   private static String[] field_170 = new String[2];
   // $VF: renamed from: a byte[][]
   public static byte[][] field_171;
   // $VF: renamed from: a byte[][][]
   public static byte[][][] field_172;
   // $VF: renamed from: a byte[]
   public static byte[] field_173;
   // $VF: renamed from: b byte[][]
   public static byte[][] field_174;
   // $VF: renamed from: a long
   private static long field_175;
   // $VF: renamed from: e int
   private static int field_176;
   private static int f;
   private static int g;
   private static int h;
   private static int i;
   private static int j;
   private static int k = 28;
   private static int l;
   private static int m;
   private static int n;
   // $VF: renamed from: b byte[]
   private static byte[] field_177;
   // $VF: renamed from: c byte[]
   private static byte[] field_178;
   // $VF: renamed from: b int[]
   private static int[] field_179;
   // $VF: renamed from: f boolean
   private static boolean field_180;
   private static int o;
   private static int p;
   private static int q;
   // $VF: renamed from: g boolean
   private static boolean field_181;
   // $VF: renamed from: h boolean
   private static boolean field_182;
   // $VF: renamed from: i boolean
   private static boolean field_183;
   // $VF: renamed from: j boolean
   private static boolean field_184;
   // $VF: renamed from: c byte[][]
   private static byte[][] field_185;
   private static int r;
   private static int s;
   // $VF: renamed from: b java.lang.String[]
   private static String[] field_186;
   // $VF: renamed from: c java.lang.String[]
   private static String[] field_187;
   private static int t;
   // $VF: renamed from: a java.lang.String[][]
   private static String[][] field_188;
   // $VF: renamed from: a int[][]
   private static int[][] field_189;
   // $VF: renamed from: b byte[][][]
   private static byte[][][] field_190;
   private static int u;
   private static int v;
   private static int w;
   // $VF: renamed from: d byte[]
   private static byte[] field_191;
   private static int x = 0;
   private static int y = x;
   private static int z;
   private static int A;
   // $VF: renamed from: k boolean
   private static boolean field_192;
   // $VF: renamed from: a java.lang.StringBuffer
   private static StringBuffer field_193;
   // $VF: renamed from: b java.lang.StringBuffer
   private static StringBuffer field_194;
   // $VF: renamed from: c java.lang.String
   private static String field_195;
   // $VF: renamed from: d java.lang.String
   private static String field_196;
   private static int B;
   private static int C;
   private static int D;
   // $VF: renamed from: a int
   public static int field_197;
   // $VF: renamed from: b int
   public static int field_198;
   private static int E;
   private static int F;
   // $VF: renamed from: e java.lang.String
   private static String field_199;
   // $VF: renamed from: f java.lang.String
   private static String field_200;
   private static int G;
   private static int H;
   private static int I;
   private static int J;
   private static int K;
   private static int L;
   // $VF: renamed from: b int[][]
   private static final int[][] field_201 = new int[2][6];
   // $VF: renamed from: a int[]
   public static int[] field_202;
   // $VF: renamed from: c int[]
   private static int[] field_203;
   // $VF: renamed from: l boolean
   private static volatile boolean field_204;
   private static int M;
   // $VF: renamed from: b long
   private static long field_205;
   private static int N;
   // $VF: renamed from: m boolean
   private static boolean field_206 = false;
   // $VF: renamed from: a l
   private static class_12 field_207;
   // $VF: renamed from: a o
   private static class_15 field_208;
   // $VF: renamed from: a j
   private static class_10 field_209;
   private static int O;
   private static int P;
   private static int Q;
   private static int R;
   // $VF: renamed from: g java.lang.String
   private static String field_210;
   // $VF: renamed from: a java.util.Vector
   private static Vector field_211;
   // $VF: renamed from: c int
   public static int field_212;
   // $VF: renamed from: n boolean
   private static boolean field_213 = false;
   // $VF: renamed from: o boolean
   private static boolean field_214 = true;
   private static int S;
   private static int T;
   // $VF: renamed from: p boolean
   private static boolean field_215;
   // $VF: renamed from: q boolean
   private static boolean field_216;
   private static int U;
   private static int V;
   // $VF: renamed from: a boolean
   public static boolean field_217;
   private static int W;
   // $VF: renamed from: r boolean
   private static boolean field_218;
   // $VF: renamed from: a javax.microedition.lcdui.Font
   private static Font field_219;
   private static int X;
   // $VF: renamed from: a char
   private static char field_220;
   private static int Y;
   private static int Z;
   // $VF: renamed from: a char[][]
   private static char[][] field_221 = new char[][]{
      {'0'}, {'1'}, {'a', 'b', 'c', '2'}, {'d', 'e', 'f', '3'}, {'g', 'h', 'i', '4'}, {'j', 'k', 'l', '5'}, {'m', 'n', 'o', '6'}, {'p', 'q', 'r', 's', '7'},
      {'t', 'u', 'v', '8'}, {'w', 'x', 'y', 'z', '9'}
   };
   private static int aa;
   private static int ab;
   private static int ac;
   private static int ad = 586;
   private static int ae;

   private class_15() {
   }

   // $VF: renamed from: a () void
   public static void method_64() {
      field_208 = new class_15();
      new Thread(new class_18()).start();
   }

   // $VF: renamed from: b () void
   public static void method_67() {
      if (class_18.a) {
         method_94(206);
         k();
         J();
         class_18.a = false;
      }
   }

   private static void k() {
      class_5.b();
   }

   public static final void a(Graphics var0) {
      if (field_204) {
         d(var0);
      } else {
         switch (i) {
            case 0:
               c(var0);
               return;
            case 1:
               a(var0, k);
               return;
            case 2:
               class_19.a(var0);
         }
      }
   }

   private static final void l() {
      if (j == 0) {
         f = -1;
         m();
      } else if (j == 1) {
         t();
         m();
      } else if (j == 2) {
         if (class_5.method_3() == 0) {
            class_5.a();
         }
      } else if (j == 3) {
         class_18.a();
         E();
         m();
      } else if (j == 4) {
         class_19.b();
         m();
      } else if (j == 5) {
         a(e());
      } else if (j == 6) {
         if (field_202[2] == 5) {
            a(33, false);
         } else {
            m();
         }
      } else if (j == 7) {
         if (field_169) {
            n();
            field_205 = class_18.method_113();
            a(32, false);
         } else {
            m();
         }
      } else if (j == 8) {
         if (field_212 != 0 && field_215 && b()) {
            j = 9;
            field_209.b(field_208);
         } else {
            m();
            m();
         }
      } else if (j != 9) {
         if (j == 10) {
            if (field_212 != 0) {
               if (d()) {
                  class_5.a(39, a(field_193.toString(), false));
                  a(42, false);
               } else if (field_218) {
                  a(39, false);
               } else {
                  a(43, false);
               }
            } else {
               m();
            }
         } else if (j == 11) {
            if (f >= 0) {
               a(e());
            } else {
               h(1, 2000);
            }
         } else if (j == 12) {
            if (f >= 0) {
               a(e());
            } else {
               h(2, 10000);
            }
         } else {
            if (j == 13) {
               if (!e) {
                  a(0, false);
                  return;
               }

               b(64, -1);
            }
         }
      }
   }

   private static final void m() {
      j++;
   }

   private static final void n() {
      String var0 = class_5.a(145);
      if (field_202[0] != 0) {
         var0 = class_5.a(144);
      }

      String var1 = String.valueOf(class_18.h(10999 - N));
      class_5.a(11, var0, var1);
   }

   public static final void c() {
      if (O != 0) {
         q(O);
         O = 0;
      }

      o();
      if (!field_204) {
         if (i == 0) {
            l();
         } else {
            if (field_207 != null) {
               field_207.b();
            }

            if (!method_71()) {
               if (i == 2) {
                  if (s < 0) {
                     class_19.method_142();
                  } else if (--s == 0) {
                     a(r, false);
                  }
               }

               if (ab > 0) {
                  ab--;
               }

               if (i == 1) {
                  if (method_86(k) != 3) {
                     if (class_18.method_123()) {
                        a(k, l - 1, -1, false);
                     }

                     if (class_18.method_125()) {
                        a(k, l + 1, 1, false);
                     }

                     if (class_18.g()) {
                        z();
                     }

                     label66:
                     if (class_19.b(k)) {
                        int var10000;
                        byte var10001;
                        if (class_18.e()) {
                           var10000 = k;
                           var10001 = -1;
                        } else {
                           if (!class_18.f()) {
                              break label66;
                           }

                           var10000 = k;
                           var10001 = 1;
                        }

                        class_19.a(var10000, var10001);
                     }

                     if (k == 32) {
                        N = (int)(class_18.method_113() - field_205);
                        if (N >= 10999) {
                           m();
                           k(0, -1);
                        } else {
                           n();
                           method_76();
                        }
                     }

                     if (k == 38) {
                        if (class_18.e()) {
                           b(37, -1);
                        }

                        if (class_18.f()) {
                           b(37, 1);
                           return;
                        }
                     }
                  } else {
                     p();
                  }
               }
            }
         }
      }
   }

   private static final void o() {
      if (P != 0) {
         switch (P) {
            case 1:
               if (field_213) {
                  field_213 = false;
                  if (Q != -1) {
                     field_202[49] = -1;
                  }

                  field_214 = false;
                  b(S, T);
               } else if (Q != -1) {
                  b(field_210);
               } else {
                  N();
               }

               method_72();
               break;
            case 2:
               if (Q == 1) {
                  O();
               } else {
                  P();
               }
               break;
            case 3:
               if (Q == 1) {
                  c(field_210);
               } else {
                  p(Q);
               }
            case 4:
            default:
               break;
            case 5:
               if (Q == 1) {
                  Q();
               } else {
                  R();
               }
               break;
            case 6:
               if (Q == 1) {
                  a(field_211);
               } else {
                  S();
               }
               break;
            case 7:
               if (Q == 1) {
                  d(field_210);
               } else {
                  a(Q, field_210);
               }
         }

         P = 0;
         Q = 0;
         R = 0;
         field_210 = null;
         field_211 = null;
      }
   }

   private static final void p() {
      if (k == 40) {
         if (class_18.c(1)) {
            a(k, l - 1, -1, false);
         }

         if (class_18.c(4)) {
            a(k, l + 1, 1, false);
         }
      }

      if (class_18.c(32768)) {
         method_79(61);
      } else if (class_18.c(65536)) {
         a('_');
         i(1);
         x();
      } else if (class_18.c(8)) {
         i(-1);
      } else if (class_18.c(2)) {
         i(1);
      } else {
         for (int var0 = 0; var0 <= 9; var0++) {
            if (class_18.c(32 << var0)) {
               X = field_221[var0].length > 1 ? 12 : 1;
               int var10000;
               if (var0 == Z && x != 2) {
                  Y++;
                  var10000 = Y % field_221[var0].length;
               } else {
                  if (field_220 != 0) {
                     i(1);
                  }

                  Z = var0;
                  var10000 = 0;
               }

               label80: {
                  Y = var10000;
                  field_220 = field_221[var0][Y];
                  char var3;
                  if (x == 0) {
                     var3 = Character.toUpperCase(field_220);
                  } else {
                     if (x != 2) {
                        break label80;
                     }

                     var3 = field_221[var0][field_221[var0].length - 1];
                  }

                  field_220 = var3;
               }

               a(field_220);
            }
         }

         if (--X == 0) {
            i(1);
            x();
         }

         byte var2 = 12;
         int var1 = 14;
         if (A == 0) {
            var1 = 13;
         }

         if (field_193 == null || field_193.toString().trim().length() < 4) {
            var2 = -1;
         }

         field_184 = true;
         field_183 = var2 != -1;
         field_171[k][4] = var2;
         field_171[k][5] = (byte)var1;
         class_18.c(var2, var1);
      }
   }

   private static final void a(Graphics var0, Font var1, String var2, String var3, int var4, int var5, int var6, int var7, int var8) {
      a(var0, var1, -1138688, var2, var5, var6, 20);
      var6 += var8;
      var0.setColor(-1138688);
      var0.drawRect(var5, var6, var7, var8);
      class_18.b(var0);
      if (class_18.a(var0, var5, var6, var7, var8)) {
         class_18.a(var0, var1, -1138688, var3, var5 + 2 - var4, var6 + 1, 20);
      }

      class_18.c(var0);
   }

   private static final void b(Graphics var0) {
      boolean var1 = false;
      Font var2 = class_18.field_236;
      int var3;
      int var4 = var3 = class_18.a(class_18.field_236) + 2;
      if (var3 * 7 > B - h()) {
         var4 = var3 = class_18.a(class_18.c) + 1;
         var2 = class_18.c;
         if (var3 * 7 > B - h()) {
            var4 = 0;
            if (var3 * 6 > B - h()) {
               var1 = true;
               field_181 = l == 1;
               field_182 = l == 0;
            }
         }
      }

      int var6 = h() + (B - h()) - 6 * var3 - var4;
      if (var1) {
         var6 = h() + (B - h()) - 3 * var3 - (var3 >> 1);
      }

      int var7 = F - 1;
      String var9 = field_193.toString().trim();
      String var10 = field_194.toString().trim();
      StringBuffer var11;
      char var12 = (var11 = l == 0 ? field_193 : field_194).charAt(z);
      int var13 = 0;

      for (int var14 = 0; var14 < z; var14++) {
         var13 += class_18.a(var11.charAt(var14), var2);
      }

      int var20 = 0;
      int var15 = 4 + var13 + 1;
      int var16 = class_18.a(X < 0 ? var11.charAt(z) : field_220, var2);
      if (var15 + var16 > var7) {
         var20 = var16 + var15 - var7;
      }

      var15 -= var20;
      int var10000;
      int var10001;
      if (l != 0 && !var1) {
         var10000 = var6 + 3 * var3;
         var10001 = var4;
      } else {
         var10000 = var6;
         var10001 = var3;
      }

      int var17 = var10000 + var10001;
      if ((class_18.method_124() & 3) != 0) {
         var0.setColor(-7387136);
         if (var12 == ' ') {
            var0.drawLine(var15, var17 + 2, var15, var17 + var3 - 2);
         } else {
            var0.fillRect(var15, var17 + 2, var16 + 1, var3 - 4);
         }
      }

      if (!var1 || l == 0) {
         String var8 = class_5.a(a(field_172[40][0]));
         a(var0, var2, var8, var9, l == 0 ? var20 : 0, 4, var6, var7, var3);
      }

      if (!var1) {
         var6 += 2 * var3 + var4;
      }

      if (!var1 || l == 1) {
         String var19 = class_5.a(a(field_172[40][1]));
         a(var0, var2, var19, var10, l == 1 ? var20 : 0, 4, var6, var7, var3);
      }

      String var18 = l == 0 ? var9 : var10;
      a(var0, var2, -1138688, class_5.a(287), class_18.field_230 - 4, B - var3, 24);
      a(var0, var2, -1138688, var18.length() + "/" + (l == 0 ? 15 : 10), 4, B - var3, 20);
   }

   private static final void a(Graphics var0, StringBuffer var1, int var2, int var3) {
      int var4 = class_18.a(class_18.field_236) + 2;
      Font var5 = class_18.field_236;
      int var7 = h() + (B - h() >> 1) - var4;
      int var8 = F - 1;
      String var10 = var1.toString().trim();
      char var11 = var1.charAt(z);
      int var12 = 0;

      for (int var13 = 0; var13 < z; var13++) {
         var12 += class_18.a(var1.charAt(var13), var5);
      }

      int var18 = 0;
      int var14 = 4 + var12 + 1;
      int var15 = class_18.a(X < 0 ? var1.charAt(z) : field_220, var5);
      if (var14 + var15 > var8) {
         var18 = var15 + var14 - var8;
      }

      var14 -= var18;
      int var16 = var7 + var4;
      if ((class_18.method_124() & 7) != 0) {
         var0.setColor(-7387136);
         if (var11 == ' ') {
            var0.drawLine(var14, var16 + 2, var14, var16 + var4 - 2);
         } else {
            var0.fillRect(var14, var16 + 2, var15 + 1, var4 - 4);
         }
      }

      String var9 = class_5.a(a(field_172[var2][0]));
      a(var0, var5, var9, var10, var18, 4, var7, var8, var4);
      String var17 = var10;
      a(var0, var5, -1138688, class_5.a(287), class_18.field_230 - 4, B - var4, 24);
      a(var0, var5, -1138688, var17.length() + "/" + var3, 4, B - var4, 20);
   }

   private static final int f() {
      return 15;
   }

   private static final int g() {
      return 4;
   }

   private static final boolean b() {
      return field_193 == null || a(field_193.toString(), false).length() == 0;
   }

   // $VF: renamed from: c () boolean
   private static final boolean method_69() {
      return a(field_194.toString(), false).length() == 0;
   }

   private static final boolean d() {
      int var0 = g();
      return a(field_193.toString(), true).length() >= var0;
   }

   private static final boolean e() {
      return class_18.c(1040);
   }

   private static final void h(int var0, int var1) {
      field_175 = class_18.method_113();
      field_176 = var1;
      f = var0;
      int var2;
      if ((var2 = e(f - 1)) >= 0) {
         class_5.method_19(var2);
      }

      class_5.method_21(e(f));
      class_18.c();
   }

   private static final void a(boolean var0) {
      if (!var0) {
         g = (int)(class_18.method_113() - field_175);
         if (g <= field_176) {
            return;
         }
      }

      q();
   }

   private static void q() {
      if (f >= 0) {
         m();
         int var0;
         if ((var0 = e(f)) >= 0) {
            class_5.method_19(var0);
         }

         f = -1;
      }
   }

   private static final void b(boolean var0) {
      if (field_202 == null) {
         field_202 = new int[50];
      }

      if (var0) {
         field_202[2] = 5;
      }

      if (var0) {
         field_202[0] = field_168 ? 50 : 0;
         field_202[1] = c ? 1 : 0;
      }

      for (int var1 = 4; var1 < 22; var1++) {
         field_202[var1] = 0;
      }

      class_19.method_157();
   }

   public static final int a(int var0) {
      return field_202[var0];
   }

   public static final void a(int var0, int var1) {
      if (var1 != field_202[var0]) {
         field_202[var0] = var1;
      }
   }

   private static final void r() {
      field_193 = a("", 22, f());
   }

   private static final void s() {
      field_194 = a("", 38, 10);
   }

   private static final StringBuffer a(String var0, int var1, int var2) {
      StringBuffer var3;
      (var3 = new StringBuffer(var2)).insert(0, var0);
      var3.setLength(var2);

      for (int var4 = var0.length(); var4 < var2; var4++) {
         var3.setCharAt(var4, ' ');
      }

      if (var1 > 0) {
         int var6 = var1 + var2;

         for (int var5 = var1; var5 < var6; var5++) {
            field_202[var5] = var3.charAt(var5 - var1);
         }
      }

      return var3;
   }

   private static final void t() {
      String[] var0 = new String[]{field_170[0] + "_opt", field_170[0] + "_his"};
      class_5.a(var0);
      field_202 = class_5.method_16(0);
      if (class_5.d() != 0) {
         b(true);
      } else if (field_202.length != 50) {
         class_5.g(0);
         field_202 = null;
         b(true);
         class_5.method_26(0);
      } else {
         field_193 = method_82(22, f());
         field_194 = method_82(38, 10);
      }

      v();
      int var1 = field_202[2];
      if (a != null) {
         class_5.method_23(a);
         field_202[2] = class_5.field_54;
      } else {
         if (var1 == 5) {
            var1 = 0;
         }

         class_5.method_13(var1);
      }

      if (field_193 == null) {
         r();
         s();
      }
   }

   private static final void u() {
      ByteArrayOutputStream var0 = new ByteArrayOutputStream();
      DataOutputStream var1 = new DataOutputStream((OutputStream)var0);
      byte[] var2 = null;
      boolean var3 = false;
      int var16;
      var2 = new byte[var16 = f()];

      for (int var4 = 0; var4 < var16; var4++) {
         var2[var4] = 32;
      }

      try {
         var1.writeInt(t);

         for (int var17 = 0; var17 < 47; var17++) {
            for (int var5 = 0; var5 < 1; var5++) {
               String var6;
               if ((var6 = field_188[var17][var5]) == null) {
                  ((OutputStream)var1).write(var2);
               } else {
                  byte[] var7;
                  int var8 = (var7 = var6.getBytes()).length;
                  ((OutputStream)var1).write(var7);

                  for (int var9 = var8; var9 < var16; var9++) {
                     var1.writeByte(32);
                  }
               }

               var1.writeInt(field_189[var17][var5]);
               byte[] var19;
               if ((var19 = field_190[var17][var5]) != null) {
                  var1.writeShort(var19.length);
                  ((OutputStream)var1).write(var19);
               } else {
                  var1.writeShort(0);
               }
            }
         }

         var1.close();
         byte[] var18 = var0.toByteArray();
         class_5.a(1, var18);
         m(1);
         return;
      } catch (Exception var13) {
      } finally {
         class_5.a((OutputStream)var1);
      }
   }

   private static final void v() {
      field_188 = new String[47][1];
      field_189 = new int[47][1];
      field_190 = new byte[47][1][];
      byte[] var0 = null;
      var0 = new byte[f()];
      byte[] var1 = class_5.a(1, false);
      if (class_5.d() == 0) {
         DataInputStream var2 = class_5.method_27(var1);

         try {
            t = var2.readInt();

            for (int var3 = 0; var3 < 47; var3++) {
               for (int var4 = 0; var4 < 1; var4++) {
                  class_5.a(var2, var0);
                  field_188[var3][var4] = new String(var0);
                  field_189[var3][var4] = var2.readInt();
                  short var5;
                  if ((var5 = var2.readShort()) > 0) {
                     byte[] var6 = new byte[var5];
                     class_5.a(var2, var6);
                     field_190[var3][var4] = var6;
                  }
               }
            }

            return;
         } catch (Exception var10) {
         } finally {
            class_5.a((InputStream)var2);
         }
      }
   }

   // $VF: renamed from: a (int, int) java.lang.StringBuffer
   private static final StringBuffer method_82(int var0, int var1) {
      StringBuffer var2;
      (var2 = new StringBuffer(var1)).setLength(var1);
      int var3 = var0 + var1;

      for (int var4 = var0; var4 < var3; var4++) {
         var2.setCharAt(var4 - var0, (char)field_202[var4]);
      }

      return var2;
   }

   private static final String a(String var0, boolean var1) {
      int var2 = 0;
      StringBuffer var3 = null;
      int var4 = f();
      if (var0 != null) {
         (var3 = new StringBuffer(var4)).setLength(var4);
         int var5 = Math.min(var4, var0.length());

         for (int var6 = 0; var6 < var5; var6++) {
            char var7;
            StringBuffer var10000;
            int var10001;
            char var10002;
            if ((var7 = var0.charAt(var6)) != 0 && var7 != ' ') {
               var2 = var6 + 1;
               var10000 = var3;
               var10001 = var6;
               var10002 = var7;
            } else {
               var10000 = var3;
               var10001 = var6;
               var10002 = ' ';
            }

            var10000.setCharAt(var10001, var10002);
         }
      }

      return (!var1 || var2 != 0) && var3 != null ? var3.toString().trim() : "";
   }

   // $VF: renamed from: d () void
   public static final void method_74() {
      class_18.b();
      J();
      if (!field_180) {
         field_180 = true;
         if (i != 0 && (i == 2 || method_86(k) != 4)) {
            w();
         }
      }
   }

   private static void w() {
      if (i == 2) {
         int var10000;
         if (s > 0) {
            s = -1;
            var10000 = r;
         } else {
            var10000 = 14;
         }

         a(var10000, false);
      }
   }

   private static final int a(StringBuffer var0) {
      int var1 = 0;
      int var2 = var0.length();

      for (int var3 = 0; var3 < var2 && var0.charAt(var3) != ' '; var3++) {
         var1++;
      }

      return var1 < var2 ? var1 : var2 - 1;
   }

   private static final void x() {
      X = -1;
      field_220 = 0;
      Y = -1;
      Z = 0;
   }

   private static final StringBuffer a() {
      return l == 0 ? field_193 : field_194;
   }

   private static final void y() {
      StringBuffer var0;
      boolean var1 = (var0 = a()).charAt(z) == ' ' && z > 0;
      if (X >= 0) {
         if (z == A) {
            i(1);
         }

         x();
      }

      int var2 = var0.length() - 1;
      if (var1) {
         i(-1);
      }

      for (int var3 = z; var3 < var2; var3++) {
         var0.setCharAt(var3, var0.charAt(var3 + 1));
      }

      var0.setCharAt(var2, ' ');
      i(-1);
      if (var1) {
         i(1);
      }
   }

   private static final void i(int var0) {
      X = -1;
      x();
      A = a(a());
      z = Math.max(0, Math.min(z + var0, A));
   }

   private static final void a(char var0) {
      StringBuffer var1;
      (var1 = a()).setCharAt(z, var0);
      A = a(var1);
   }

   // $VF: renamed from: c (int) int
   private static int method_86(int var0) {
      return field_171[var0][2];
   }

   // $VF: renamed from: d (int) int
   private static int method_87(int var0) {
      return class_5.a(field_171[var0], 0);
   }

   private static final void z() {
      if (l < 0) {
         method_79(3);
      } else {
         int var1 = method_86(k) != 2 && k != 49 ? l : 0;
         byte[] var2 = field_172[k][var1];
         int var3 = var2[3] & 255;
         int var4 = var2[4] & 255;
         b(var3, var4);
      }
   }

   private static final void j(int var0) {
      int var1 = field_202[var0];
      boolean var2 = var0 == 0;
      if (var0 == 0) {
         field_202[var0] = var1 == 0 ? 50 : 0;
      }

      field_207.a(field_202[0], field_202[0]);
      if (field_177[k] == 14) {
         b(class_19.method_158());
      }

      if (var2 && k == 15 && field_177[15] == 14) {
         var2 = false;
      }

      if (var2) {
         c(false);
      }

      method_76();
   }

   private static final void A() {
      Object var0 = null;
      String var3 = class_5.a(field_202[0] == 0 ? 145 : 144);
      class_5.a(9, var3);
   }

   // $VF: renamed from: a (int) void
   public static final void method_79(int var0) {
      b(var0, -1);
   }

   public static final void b(int var0, int var1) {
      if (var0 != 0) {
         ac = 1;
      }

      if (!e(var0, var1)) {
         switch (var0) {
            case 0:
               return;
            case 1:
               z();
               return;
            case 2:
               if (k == 47) {
                  b(7, 0);
                  return;
               }
               break;
            case 3:
               if (field_177[k] != -2) {
                  if (field_177[k] == -3) {
                     k(0, -1);
                     return;
                  }

                  ac = -1;
                  a(field_177[k], false);
                  return;
               }

               ac = -1;
               method_79(4);
               return;
            case 4:
               k(2, -1);
               return;
            case 5:
               a(var1, true);
               return;
            case 6:
               a(var1, false);
               return;
            case 7:
               ac = -1;
               a(var1, false);
               return;
            case 8:
               class_18.c(-1, -1);
               class_19.a(true);
               k(2, -1);
               return;
            case 9:
            case 10:
            case 11:
            case 12:
            case 13:
            case 15:
            case 16:
            case 19:
            case 20:
            case 21:
            case 22:
            case 23:
            case 24:
            case 25:
            case 26:
            case 28:
            case 30:
            case 31:
            case 32:
            case 33:
            case 34:
            case 35:
            default:
               if (var0 == 26) {
                  method_94(205);
                  class_5.method_13(var1);
                  field_202[2] = class_5.field_54;
                  method_72();
                  F();
                  class_10.a(class_3.a, class_5.field_53);
                  M();
                  if (j >= 13) {
                     method_79(3);
                     return;
                  }

                  m();
                  k(0, -1);
                  c();
                  return;
               }

               if (var0 == 61) {
                  if (l == 0) {
                     y = y == 0 ? 1 : 0;
                     class_5.b(287, class_5.a(288 + y));
                     x = y;
                     x();
                     return;
                  }
               } else {
                  if (var0 == 19) {
                     field_195 = field_193.toString();
                     a(field_195, 22, 5);
                     method_72();
                     method_66();
                     a(0, false);
                     return;
                  }

                  if (var0 == 20) {
                     y();
                     return;
                  }

                  if (var0 == 25) {
                     if (var1 < 0) {
                        var1 = 0;
                     }

                     String[] var3 = field_188[var1];
                     int[] var4 = field_189[var1];
                     a(var3, var4, null);
                     a(36, true);
                     return;
                  }

                  if (var0 == 28) {
                     j(var1);
                     return;
                  }

                  if (var0 == 47) {
                     if (field_202[0] == 0) {
                        field_202[0] = 50;
                     }

                     m();
                     k(0, -1);
                     method_72();
                     return;
                  }

                  if (var0 == 48) {
                     field_202[0] = 0;
                     m();
                     k(0, -1);
                     method_72();
                     return;
                  }

                  if (var0 == 32) {
                     C();
                     return;
                  }

                  if (var0 == 33) {
                     return;
                  }

                  class_19.b(var0, var1);
               }
               break;
            case 14:
               class_19.b(true);
               k(2, -1);
               return;
            case 17:
               ac = -1;
               b(7, 0);
               return;
            case 18:
               method_67();
               return;
            case 27:
               method_94(207);
               class_5.method_18();
               b(false);
               t = 0;
               v();
               M();
               method_79(3);
               return;
            case 29:
               int var2 = field_202[var1];
               field_202[var1] = var2 == 0 ? 1 : 0;
               method_76();
               return;
            case 36:
               k(38);
               return;
            case 37:
               aa += var1;
               if (aa < 0) {
                  aa = class_5.c() - 1;
               }

               if (aa >= class_5.c()) {
                  aa = 0;
               }

               class_5.b(308, class_5.c(aa));
               L();
               method_76();
               return;
         }
      }
   }

   private static final void k(int var0) {
      byte var1 = (byte)(i == 2 ? 4 : 1);
      field_171[var0][5] = var1;
      int var2 = method_96(var0) - 1;
      if (method_78(var0, var2) == 116) {
         byte var3 = (byte)(i == 2 ? 4 : 3);
         field_172[var0][var2][3] = var3;
      }

      a(var0, true);
   }

   private static final boolean d(int var0, int var1) {
      if (!field_217 && field_202[49] != -1 && field_202[49] != 0) {
         boolean var2 = false;

         for (int var3 = 0; var3 < 4; var3++) {
            int var4 = class_5.a(585, var3);
            if (var0 == var4) {
               var2 = true;
               break;
            }
         }

         if (var0 == 58 && field_202[49] == t) {
            var2 = false;
         }

         if (!var2) {
            return var2;
         }

         S = var0;
         T = var1;
         field_213 = true;
         field_209.a(field_202[49], field_208);
         return var2;
      } else {
         return false;
      }
   }

   private static final boolean e(int var0, int var1) {
      int var2 = class_5.a(584, field_212, 2);
      if (field_214) {
         if (d(var0, var1)) {
            return true;
         }
      } else {
         field_214 = true;
      }

      switch (var0) {
         case 21:
            a(var2, true);
            break;
         case 22:
            method_79(56);
            break;
         case 23:
            if (var2 == 40) {
               if (b() && method_69()) {
                  a(field_177[k], false);
               } else {
                  y();
               }
            } else if (b()) {
               a(field_177[k], false);
            } else {
               y();
            }
            break;
         case 24:
            r();
            s();
            field_193 = null;
            method_72();
            method_79(18);
            break;
         case 25:
         case 26:
         case 27:
         case 28:
         case 29:
         case 30:
         case 31:
         case 32:
         case 33:
         case 34:
         case 35:
         case 36:
         case 37:
         case 38:
         case 39:
         case 40:
         case 41:
         case 42:
         case 43:
         case 44:
         case 45:
         case 46:
         case 47:
         case 48:
         case 49:
         case 50:
         case 51:
         default:
            return false;
         case 52:
            a(class_5.a(584, field_212, 3), true);
            break;
         case 53:
            U = var1;
            V = method_78(k, l);
            field_209.b(U, field_208);
            break;
         case 54:
            m();
            k(0, -1);
            break;
         case 55:
            B();
            m();
            k(0, -1);
            break;
         case 56:
            if (var2 == 40) {
               field_209.a(a(field_193.toString(), false), field_194.toString(), field_208);
            } else {
               field_209.a(a(field_193.toString(), false), null, field_208);
            }
            break;
         case 57:
            field_209.a(field_208);
            break;
         case 58:
            field_202[49] = t;
            if (!field_192) {
               field_209.b(field_208);
            }

            field_209.a(t, field_208);
            break;
         case 59:
            a(12, false);
            break;
         case 60:
            field_209.c(field_208);
      }

      return true;
   }

   private static final void B() {
      field_217 = true;
      field_215 = false;
      field_216 = false;
      H();
      field_203 = new int[field_202.length];
      System.arraycopy(field_202, 0, field_203, 0, field_202.length);
   }

   private static final void C() {
      try {
         class_7.a(class_3.a, b);
         method_67();
      } catch (Exception var1) {
      }
   }

   // $VF: renamed from: e () void
   public static final void method_76() {
      if (i == 1) {
         int var0 = l;
         a(k, false);
         boolean var1 = true;
         int var2;
         if ((var2 = method_86(k)) != 2 && var2 != 5) {
            var1 = var0 < field_172[k].length && field_172[k][var0][5] != 0;
         }

         if (var1) {
            a(k, var0, 0, false);
         }
      }
   }

   private static final int e(int var0) {
      switch (var0) {
         case 0:
            return 8;
         case 1:
            return 9;
         case 2:
            return 10;
         default:
            return -1;
      }
   }

   private static final void c(Graphics var0) {
      var0.setColor(j < 12 ? -1 : -11534336);
      var0.fillRect(0, 0, class_18.field_230, class_18.field_231);
      int var2;
      if (f >= 0 && f <= 2 && class_5.method_11(var2 = e(f))) {
         class_18.a(var2, class_18.field_230 >> 1, class_18.field_231 >> 1, 3);
      }

      boolean var13 = (j == 11 || j == 12 || j == 5 && g < field_176 && g != 0) && !field_204;
      if (j >= 2 && j <= 5 && !var13) {
         int var16 = class_18.field_230 * 819 >> 10;
         int var17 = class_18.field_231 * 41 >> 10;
         int var18 = class_18.field_230 * 102 >> 10;
         int var6 = class_18.field_231 * 921 >> 10;
         int var7 = class_18.field_230 * 798 >> 10;
         int var8 = class_18.field_231 * 20 >> 10;
         if ((var16 & 1) != 0) {
            var16--;
         }

         if ((var17 & 1) != 0) {
            var17--;
         }

         if ((var7 & 1) != 0) {
            var7--;
         }

         if ((var8 & 1) != 0) {
            var8--;
         }

         if (var16 - var7 < 2) {
            var7 = var16 - 2;
         }

         if (var17 - var8 < 2) {
            var8 = var17 - 2;
         }

         if (var17 < 4) {
            var17 = 4;
            var8 = 2;
         }

         int var9 = var18 + (var16 - var7 >> 1);
         int var10 = var6 + (var17 - var8 >> 1);
         int var12 = (var7 << 10) / ad * ae >> 10;
         var0.setColor(-4144960);
         var0.fillRect(var18, var6, var16, var17);
         var0.setColor(-864252);
         var0.fillRect(var9, var10, var12, var8);
      } else if (var13) {
         int var3 = class_18.method_133() - class_18.c.getHeight() - 5;
         var3 += 0;
         var3 += 0;
         var0.setFont(class_18.c);
         String var4 = class_5.a(232);
         int var5 = class_18.method_126() >> 1;
         a(var0, var4, var5, var3, 17);
      }

      h++;
   }

   private static void a(Graphics var0, String var1, int var2, int var3, int var4) {
      var0.setFont(class_18.c);
      var0.setColor(-16119286);
      var0.drawString(var1, var2 + 1, var3, var4);
      var0.drawString(var1, var2 - 1, var3, var4);
      var0.drawString(var1, var2, var3 + 1, var4);
      var0.drawString(var1, var2, var3 - 1, var4);
      var0.setColor(-91354);
      var0.drawString(var1, var2, var3, var4);
   }

   private static final void D() {
      field_219 = class_18.c;
      E = class_18.method_129(0) + 3;
      field_197 = 6 + class_18.a(class_18.field_235) + 3 + Math.abs(0);
      D = class_18.method_116();
      D = Math.min(D, class_18.field_231 - class_5.method_20(38) - 2 - 1);
      C = D;
      B = C - E;
      field_198 = B;
      F = class_18.field_230 - 8;
   }

   private static final void E() {
      D();
      field_177 = new byte[field_171.length];
      method_93(0, 30);
      method_93(12, 6);
      field_178 = new byte[field_171.length];
      field_179 = new int[24];
      if (a != null) {
         i(15, 143);
      }

      if (!field_169) {
         i(15, 8);
         i(15, 9);
      }

      if (b == null) {
         i(0, 209);
      }

      G();
      F();
      byte[] var1 = field_172[36][0];
      byte[][] var0 = new byte[1][7];

      for (int var5 = 0; var5 < 1; var5++) {
         byte[] var2 = var0[0];
         System.arraycopy(var1, 0, var2, 0, 7);
      }

      field_172[36] = var0;
      I();
   }

   private static final void F() {
      class_5.a(0, field_170);
      boolean var0;
      String var1 = class_5.a((var0 = class_18.field_241) ? 230 : 231);
      String var2 = class_5.a(var0 ? 231 : 230);
      class_5.a(30, new String[]{var1, var2});
      class_10.a(class_3.a, class_5.field_53);
      H();
   }

   private static final void G() {
      String var0 = method_107("OPERATORCOMMUNITY");
      field_212 = 0;
      if (var0 != null && (field_215 || field_216)) {
         for (int var1 = 1; var1 < 5; var1++) {
            String var3 = class_5.a(class_5.a(584, var1, 1));
            if (var0.equals(var3)) {
               field_212 = var1;
               return;
            }
         }
      }
   }

   private static final void H() {
      if (!field_217 && field_212 != 0) {
         if (!field_216) {
            i(44, 269);
         }

         if (!field_215) {
            i(44, 273);
            i(44, 271);
            i(44, 272);
         }

         int var0;
         if (((var0 = class_5.a(584, field_212, 6)) & 1) == 0) {
            i(44, 269);
         }

         if ((var0 & 2) == 0) {
            i(44, 273);
         }

         if ((var0 & 8) == 0) {
            i(44, 272);
         }

         if ((var0 & 4) == 0) {
            i(44, 271);
         }

         if ((var0 & 16) == 0) {
            i(44, 275);
         }

         int var1 = class_5.a(584, field_212, 0);
         class_5.b(303, class_5.a(var1));
         class_5.a(31, class_5.a(var1));
         class_5.a(33, class_5.a(var1));
         class_5.a(36, class_5.a(var1));
      } else {
         i(0, 303);
         i(23, 33);
         i(23, 34);
      }
   }

   public static final void a(int var0, int var1, int var2, int var3, int var4) {
      byte[][] var5;
      int var6;
      byte[][] var7 = new byte[(var6 = (var5 = field_172[var0]).length) + 1][7];

      for (int var8 = 0; var8 < var6; var8++) {
         System.arraycopy(var5[var8], 0, var7[var8], 0, 7);
      }

      byte[] var9 = var7[var6];
      var9[3] = (byte)var2;
      var9[4] = (byte)var3;
      var9[6] = (byte)var4;
      var9[5] = 1;
      var9[2] = -1;
      a(var9, var1);
      field_172[var0] = var7;
   }

   private static void i(int var0, int var1) {
      byte[][] var2;
      int var3 = (var2 = field_172[var0]).length;
      int var4 = -1;

      for (int var5 = 0; var5 < var3; var5++) {
         if (a(var2[var5]) == var1) {
            var4 = var5;
            break;
         }
      }

      if (var4 >= 0) {
         byte[][] var8 = new byte[var3 - 1][];
         int var6 = 0;

         for (int var7 = 0; var7 < var3; var7++) {
            if (var7 != var4) {
               var8[var6++] = var2[var7];
            }
         }

         field_172[var0] = var8;
      }
   }

   // $VF: renamed from: a (int, int) int
   public static final int method_83(int var0, int var1) {
      int var2 = -1;
      int var3 = method_96(var0);

      for (int var4 = 0; var4 < var3; var4++) {
         if (method_78(var0, var4) == var1) {
            var2 = var4;
            break;
         }
      }

      return var2;
   }

   // $VF: renamed from: b (int, int) int
   public static final int method_88(int var0, int var1) {
      int var2 = -1;
      int var3 = method_96(var0);

      for (int var4 = 0; var4 < var3; var4++) {
         if (method_92(var0, var4) == var1) {
            var2 = var4;
            break;
         }
      }

      return var2;
   }

   private static final void I() {
      field_207 = new class_12();
   }

   private static void c(boolean var0) {
      a(59, true, var0);
      field_206 = true;
   }

   public static final void b(int var0) {
      if (a(0) != 0) {
         a(var0, false, false);
      }
   }

   private static final void a(int var0, boolean var1, boolean var2) {
      if (field_207 != null) {
         K();
         if (var0 >= 0) {
            field_207.a(var0, var1, var2);
         }
      }
   }

   private static void J() {
      try {
         if (field_207 != null) {
            field_207.a();
         }
      } catch (Exception var1) {
      }

      field_206 = false;
   }

   private static final void K() {
      if (field_207 != null) {
         field_207.a(field_202[0], field_202[0]);
      }
   }

   public static final boolean a(int var0, int var1, byte[] var2, int var3) {
      boolean var4;
      if (var4 = method_97(var0, var1, var3) > -1) {
         u = var0;
         v = var1;
         w = var3;
         field_191 = var2;
      }

      return var4;
   }

   // $VF: renamed from: a (int, int, int) int
   private static int method_97(int var0, int var1, int var2) {
      byte var3 = -1;
      int var4 = var1 * var2;

      for (int var5 = 0; var5 < 1; var5++) {
         int var6;
         if ((var6 = field_189[var0][0] * var2) == 0 || var6 <= var4) {
            var3 = 0;
            break;
         }
      }

      return var3;
   }

   // $VF: renamed from: a (int, int) byte[]
   public static final byte[] method_84(int var0, int var1) {
      return field_190[var0][var1];
   }

   public static final int c(int var0, int var1) {
      return field_189[var0][var1];
   }

   // $VF: renamed from: a () boolean
   public static final boolean method_65() {
      if (!field_217 && field_215) {
         method_93(48, 12);
         if (class_5.a(584, field_212, 5) != 0) {
            b(6, 48);
         } else {
            method_79(58);
         }

         return true;
      } else {
         return false;
      }
   }

   // $VF: renamed from: a () int
   public static final int method_66() {
      int var0 = u;
      int var1 = v;
      int var2 = w;
      int var3 = method_97(var0, var1, var2);
      int[] var4 = field_189[var0];
      String[] var5 = null;
      var5 = field_188[var0];
      if (var3 >= 0) {
         for (int var6 = -1; var6 >= var3; var6--) {
            var4[var6 + 1] = var4[var6];
            var5[var6 + 1] = var5[var6];
            field_190[var0][var6 + 1] = field_190[var0][var6];
         }

         var4[var3] = var1;
         String[] var10000;
         int var10001;
         String var10002;
         if (b()) {
            var10000 = var5;
            var10001 = var3;
            var10002 = class_5.a(283);
         } else {
            var10000 = var5;
            var10001 = var3;
            var10002 = field_193.toString();
         }

         var10000[var10001] = var10002;
         field_190[var0][var3] = field_191;
         field_191 = null;
         u();
      }

      return var3;
   }

   private static final boolean a(String[] var0, int[] var1, int[] var2) {
      if (var0 != null && var1 != null) {
         if (field_186 == null) {
            field_186 = new String[5];
            field_187 = new String[5];
         }

         int var3 = var1.length;

         for (int var4 = 0; var4 < 5; var4++) {
            String[] var10000;
            int var10001;
            String var10002;
            if (var4 < var3 && var1[var4] > 0) {
               String var5;
               int var6 = class_18.a(var5 = String.valueOf(var1[var4]), class_18.field_236);
               int var7 = var2 == null ? var4 + 1 : var2[var4];
               class_5.a(var7 + ". " + a(var0[var4], true), var4, F - var6 - 8, class_18.field_236);
               field_186[var4] = class_5.d(var4);
               var10000 = field_187;
               var10001 = var4;
               var10002 = var5;
            } else {
               field_186[var4] = class_5.a(284);
               var10000 = field_187;
               var10001 = var4;
               var10002 = null;
            }

            var10000[var10001] = var10002;
         }

         int var9;
         int var10;
         if (W > 0) {
            int var8 = W;
            class_5.a(38, String.valueOf(var8));
            var9 = 302;
            var10 = 38;
         } else {
            var9 = 302;
            var10 = 286;
         }

         class_5.b(var9, class_5.a(var10));
         a(49, 0, 302);
         return true;
      } else {
         return false;
      }
   }

   private static final void d(Graphics var0) {
      class_18.b(var0);
      var0.setClip(0, 0, class_18.method_126(), class_18.method_133());
      if (i != 0) {
         class_19.a(var0, -1);
      } else {
         var0.setColor(-11534336);
         var0.fillRect(0, 0, class_18.field_230, class_18.field_231);
      }

      M++;
      if (field_200 != null) {
         a(var0, class_18.c, -1, field_200, 5, class_18.field_231 - class_18.a(class_18.c) - 5, 20);
      }

      class_18.c(var0);
   }

   private static final void a(Graphics var0, int var1) {
      int var2 = method_86(var1);
      byte[] var3 = field_171[var1];
      byte[][] var4;
      if ((var4 = method_80(var1)) != null) {
         int var5 = var4.length;
         if (K >= 0) {
            var0.drawImage(class_5.method_6(K), class_18.field_230 - class_5.method_15(K) - 4, method_75() - class_5.method_20(K) - 4, 20);
         }

         class_19.a(var0, var1);
         if (ab > 0) {
            int var6 = (class_18.field_230 * ab * ac << 10) / 5 >> 10;
            var0.translate(var6, 0);
         }

         boolean var14 = class_19.a(var0, var1, l);
         int var7 = method_87(var1);
         int var8 = 2;
         byte var9;
         if ((var9 = var3[3]) > 0) {
            var8 = 2 + class_5.method_15(var9) + 1;
            c(var9, 2, 6);
         }

         if (var7 != -1) {
            if (field_201[0][0] != 0) {
               var8 = class_18.field_230 - a(field_201[0]);
            }

            a(var0, class_18.field_235, -1138688, class_5.a(var7), var8, 6, 20);
         }

         if (var5 > 0 && !var14) {
            b(k, true, false);
            int var15 = (n + 512 >> 10) + o;
            var0.setClip(4, o, F, p);
            if (var2 == 3) {
               if (class_5.a(584, field_212, 2) == 40) {
                  b(var0);
               } else {
                  a(var0, field_193, 41, 15);
               }
            } else if (var2 == 5) {
               b(var0, var15);
            } else if (var4[0][2] >= 0) {
               b(var0, var1, var4, var5, var15);
            } else {
               a(var0, var2, var4, var5, var15);
            }

            var0.setClip(0, 0, class_18.field_230, class_18.field_231);
            int var10 = (class_18.method_129(0) >> 1) - 1;
            int var11 = method_75() + var10;
            int var12 = field_198 + var10;
            boolean var13 = var2 != 2 && var2 != 3 && var2 != 5;
            if (!field_181 && var13 && l == 0) {
               class_18.b(0, class_18.field_230 >> 1, var11, 2);
            }

            if (!field_182 && var13 && l == var5 - 1) {
               class_18.b(0, class_18.field_230 >> 1, var12, 3);
            }

            if (field_181) {
               class_18.b(0, class_18.field_230 >> 1, var11, 0);
            }

            if (field_182) {
               class_18.b(0, class_18.field_230 >> 1, var12, 1);
            }
         }

         var0.translate(-var0.getTranslateX(), -var0.getTranslateY());
         var0.setClip(0, 0, class_18.field_230, class_18.field_231);
      }
   }

   public static void a(Graphics var0, int var1, int var2) {
      if (field_199 != null) {
         int var3 = class_18.method_126() - (G >> 10);
         a(var0, class_18.c, var1, field_199, var3, ++var2, 20);
         if (--J < 0) {
            G += 1536;
            if (G >= H) {
               G = G - H;
            }
         }
      }
   }

   private static final int g(int var0, int var1) {
      byte[][] var2 = field_172[var0];
      var1 = class_18.method_137(var1, 0, var2.length);
      int var3 = 0;

      for (int var4 = 0; var4 < var1; var4++) {
         if (var2[var4][5] != 0) {
            var3++;
         }
      }

      return var3;
   }

   private static final void j(int var0, int var1) {
      m = -(var1 == 1 ? g(k, l) : l) * var0;
      if (m < -q) {
         m = -q;
      }

      if (m > 0) {
         m = 0;
      }
   }

   private static final void b(int var0, boolean var1, boolean var2) {
      field_181 = false;
      field_182 = false;
      int var3 = method_86(var0);
      byte[][] var4;
      if ((var4 = method_80(var0)) != null) {
         int var5 = var4.length;
         if (var0 == 49) {
            var5 = 7;
         }

         int var6 = B - h() - 4;
         int var7 = h(var0);
         o = h() + 2;
         p = B - 2 - o;
         if (var6 >= var7) {
            m = var6 - var7 >> 1;
            n = m << 10;
            q = var7 - p;
         } else {
            int var8 = method_101(var4[0], var3);
            int var9 = p;
            int var10;
            p = (var10 = p / var8) * var8;
            o = o + (var9 - p) / 2;
            q = var7 - p;
            if (var3 != 2 && var3 != 5) {
               if (var2) {
                  j(var8, var3);
               }

               int var11 = l;
               if (var3 == 1) {
                  var11 = g(k, l);
               }

               int var12;
               label75: {
                  int var13;
                  int var14 = (var13 = (var12 = -m) / var8) + var10;
                  if (var10 > 2) {
                     if (var11 <= var13) {
                        var12 -= var8;
                     }

                     if (var11 < var14 - 1) {
                        break label75;
                     }
                  } else {
                     if (var11 < var13) {
                        var12 -= var8;
                     }

                     if (var11 <= var14 - 1) {
                        break label75;
                     }
                  }

                  var12 += var8;
               }

               if (var12 > q) {
                  var12 = q;
               }

               if (var12 < 0) {
                  var12 = 0;
               }

               m = -var12;
            } else {
               if (l > var5 - var10) {
                  l = var5 - var10;
               }

               j(var8, var3);
            }

            if (var1) {
               int var15;
               int var10000;
               int var10001;
               if ((var15 = (m << 10) - n) >= -3 && var15 <= 3) {
                  var10000 = n;
                  var10001 = var15;
               } else {
                  var10000 = n;
                  var10001 = var15 / 4;
               }

               n = var10000 + var10001;
            } else {
               n = m << 10;
            }

            field_181 = m < 0;
            field_182 = m > -q;
         }
      }
   }

   private static final void a(Graphics var0, int var1, byte[][] var2, int var3, int var4) {
      int var6 = class_18.field_230 >> 1;
      int var7 = var4;
      Font var10;
      int var11 = class_18.a(var10 = var1 != 2 ? class_18.field_236 : field_219);
      int[] var12 = field_201[1];
      boolean var13 = false;

      for (int var14 = 0; var14 < var3; var14++) {
         byte[] var5 = var2[var14];
         boolean var15 = var5[5] != 0;
         if (a(var1, var5)) {
            int var16;
            if (var7 > 0 && (var16 = a(var5)) != -1) {
               int var17 = var14 == l && var1 != 2 && var1 != 5 ? -1 : -1138688;
               var17 = var15 ? var17 : -10524839;
               if (var1 != 2) {
                  if (var14 == l) {
                     b(var0, var7, var11);
                  }

                  int var9;
                  Graphics var10000;
                  Font var10001;
                  int var10002;
                  String var10003;
                  if (var14 == l && var12[0] != 0) {
                     var9 = class_18.field_230 - a(var12);
                     var10000 = var0;
                     var10001 = var10;
                     var10002 = var17;
                     var10003 = class_5.a(var16);
                  } else {
                     int var8 = class_18.a(class_5.d(var14), var10);
                     var9 = var6 - (var8 >> 1);
                     var10000 = var0;
                     var10001 = var10;
                     var10002 = var17;
                     var10003 = class_5.d(var14);
                  }

                  a(var10000, var10001, var10002, var10003, var9, var7, 20);
               } else {
                  b(var0, field_219, var17, class_5.b(var16), var6, var7, 17);
               }
            }

            var7 += var11;
            var7 += 2;
         }

         if (var7 > var0.getClipY() + var0.getClipHeight()) {
            return;
         }
      }
   }

   private static void b(Graphics var0, int var1, int var2) {
      class_18.b(var0);
      var0.setClip(0, var0.getClipY(), class_18.field_230, var0.getClipHeight());
      var0.setColor(-8454144);
      var0.fillRect(0, var1 - 1, class_18.field_230, var2 + 2);
      class_18.c(var0);
   }

   // $VF: renamed from: b (int) boolean
   private static final boolean method_95(int var0) {
      return var0 == 1 || var0 == 4;
   }

   private static final boolean a(int var0, byte[] var1) {
      boolean var2 = var1[5] != 0;
      return !method_95(var0) || var2;
   }

   private static final int a(int[] var0) {
      int var1;
      int var2 = (var1 = var0[1]) >> 10;
      if (--var0[4] < 0) {
         int var3 = var0[2];
         int var4 = var0[3];
         var1 += 1536 * var0[5];
         var0[1] = var1;
         if (var1 >= var3 || var1 < var4) {
            var0[5] *= -1;
         }
      }

      return var2;
   }

   private static final void b(Graphics var0, int var1, byte[][] var2, int var3, int var4) {
      int var6 = method_86(var1);
      int var7 = var4;
      int var8;
      int var9 = (var8 = method_101(var2[0], var6)) - class_18.a(class_18.field_236) >> 1;
      int var11;
      int var12 = class_18.method_122(var11 = method_102(var2[0][2]));
      int var13 = class_18.method_129(var11);
      int var14 = 0;
      if (var13 < var8) {
         var14 = var8 - var13 >> 1;
      }

      int var15 = a(var6, var2) - var12 - 4;
      int var16 = class_18.field_230 - var15 >> 1;
      int var17 = var12 + 8;
      if (var16 < var17) {
         var16 = var17;
      }

      int[] var18 = field_201[1];
      boolean var19 = true;

      for (int var20 = 0; var20 < var3; var20++) {
         if (var7 > 0) {
            byte[] var5;
            int var21 = a(var5 = var2[var20]);
            boolean var22 = var2[var20][5] != 0;
            if (var19 = a(var6, var5)) {
               int var23 = var20 == l ? -1 : -1138688;
               var23 = var22 ? var23 : -10524839;
               if (var20 == l) {
                  int var24 = class_18.a(class_18.field_236);
                  int var25;
                  Graphics var10000;
                  int var10001;
                  int var10002;
                  if ((var25 = var8 - var24 >> 1) > 0) {
                     var10000 = var0;
                     var10001 = var7 + var25;
                     var10002 = var24;
                  } else {
                     var10000 = var0;
                     var10001 = var7;
                     var10002 = var8;
                  }

                  b(var10000, var10001, var10002);
               }

               byte var10;
               if ((var10 = var5[2]) >= 0) {
                  c(var10, var16 - 4, var7 + var14);
               }

               int var27 = var16;
               Graphics var28;
               Font var29;
               int var30;
               String var10003;
               if (var20 == l && var18[0] != 0) {
                  var27 = class_18.field_230 - a(var18);
                  var28 = var0;
                  var29 = class_18.field_236;
                  var30 = var23;
                  var10003 = class_5.a(var21);
               } else {
                  var28 = var0;
                  var29 = class_18.field_236;
                  var30 = var23;
                  var10003 = class_5.d(var20);
               }

               a(var28, var29, var30, var10003, var27, var7 + var9, 20);
            }
         }

         if (var7 > var0.getClipY() + var0.getClipHeight()) {
            return;
         }

         if (var19) {
            var7 += var8;
         }
      }
   }

   private static final void b(Graphics var0, int var1) {
      int var2 = var1;
      Font var3;
      int var4 = class_18.a(var3 = class_18.field_236);
      String var5 = class_5.a(284);

      for (int var6 = 0; var6 < 5; var6++) {
         String var7;
         Graphics var10000;
         Font var10001;
         int var10002;
         String var10003;
         int var10004;
         int var10005;
         int var10006;
         if ((var7 = field_186[var6]) == var5) {
            var10000 = var0;
            var10001 = var3;
            var10002 = -1138688;
            var10003 = var7;
            var10004 = class_18.field_230 >> 1;
            var10005 = var2;
            var10006 = 17;
         } else {
            a(var0, var3, -1138688, var7, 8, var2, 20);
            var10000 = var0;
            var10001 = var3;
            var10002 = -1138688;
            var10003 = field_187[var6];
            var10004 = class_18.field_230 - 4;
            var10005 = var2;
            var10006 = 24;
         }

         a(var10000, var10001, var10002, var10003, var10004, var10005, var10006);
         var2 += var4;
         var2 += 2;
      }

      a(var0, 2, field_185, field_185.length, var2);
   }

   public static final void a(Graphics var0, Font var1, int var2, String var3, int var4, int var5, int var6) {
      class_18.a(var0, var1, var2, var3, var4, var5, var6);
   }

   private static void b(Graphics var0, Font var1, int var2, String var3, int var4, int var5, int var6) {
      class_18.a(var0, var1, var2, var3, var4, var5, var6);
   }

   private static final void a(byte[] var0, int var1) {
      var0[0] = (byte)((var1 & 0xFF00) >> 8);
      var0[1] = (byte)(var1 & 0xFF);
   }

   // $VF: renamed from: c (int, int) void
   public static final void method_98(int var0, int var1) {
      field_171[var0][0] = (byte)((var1 & 0xFF00) >> 8);
      field_171[var0][1] = (byte)(var1 & 0xFF);
   }

   // $VF: renamed from: d (int, int) int
   public static final int method_90(int var0, int var1) {
      return field_172[var0][var1][3];
   }

   // $VF: renamed from: a (int, int) boolean
   public static final boolean method_85(int var0, int var1) {
      return field_172[var0][var1][5] != 0;
   }

   // $VF: renamed from: b (int) int
   public static final int method_96(int var0) {
      return field_172[var0].length;
   }

   // $VF: renamed from: e (int, int) int
   public static final int method_92(int var0, int var1) {
      return field_172[var0][var1][4];
   }

   private static final int a(byte[] var0) {
      return class_5.a(var0, 0);
   }

   // $VF: renamed from: h (int, int) int
   private static int method_78(int var0, int var1) {
      return class_5.a(field_172[var0][var1], 0);
   }

   public static final void a(int var0, int var1, int var2) {
      a(field_172[var0][var1], var2);
   }

   public static final void b(int var0, int var1, int var2) {
      field_172[var0][var1][4] = (byte)var2;
   }

   // $VF: renamed from: d (int, int) void
   public static final void method_91(int var0, int var1) {
      field_171[var0][2] = (byte)var1;
   }

   // $VF: renamed from: e (int, int) void
   public static final void method_93(int var0, int var1) {
      field_177[var0] = (byte)var1;
   }

   // $VF: renamed from: b () int
   public static final int method_68() {
      return k;
   }

   // $VF: renamed from: f (int) int
   private static int method_102(int var0) {
      return field_173[field_174[var0][0]];
   }

   private static void c(int var0, int var1, int var2) {
      class_18.b(field_173[field_174[var0][0]], var1, var2, field_174[var0][1]);
   }

   // $VF: renamed from: g (int) int
   private static int method_103(int var0) {
      return method_101(field_172[var0][0], method_86(var0));
   }

   public static final int f(int var0, int var1) {
      return method_103(var0) * (var1 + 1) + class_18.method_133() - field_198 + (method_75() - L) + 2;
   }

   // $VF: renamed from: a (byte[], int) int
   private static final int method_101(byte[] var0, int var1) {
      Font var2 = var1 != 2 && var1 != 5 ? class_18.field_236 : field_219;
      int var3 = a(var0);
      int var4 = class_18.a(var2);
      boolean var5 = false;
      byte var6;
      int var10000;
      if ((var6 = var0[2]) >= 0) {
         int var7 = class_18.method_129(method_102(var6));
         if (var3 == -1) {
            return var7 + 2;
         }

         var10000 = Math.max(var4, var7);
      } else {
         var10000 = var4;
      }

      int var8 = var10000;
      return var8 + 2;
   }

   // $VF: renamed from: a (int) byte[][]
   private static final byte[][] method_80(int var0) {
      return method_86(var0) != 2 ? field_172[var0] : field_185;
   }

   private static final int h(int var0) {
      byte[][] var1;
      if ((var1 = method_80(var0)) != null && var1.length > 0) {
         int var2;
         if (method_95(var2 = method_86(var0))) {
            int var3 = var1.length;
            int var4 = method_101(var1[0], var2);
            int var5 = 0;

            for (int var6 = 0; var6 < var3; var6++) {
               if (var1[var6][5] != 0) {
                  var5 += var4;
               }
            }

            return var5;
         } else {
            return var0 == 49 ? method_101(var1[0], var2) * (5 + field_185.length) : method_101(var1[0], var2) * var1.length;
         }
      } else {
         return class_18.a(class_18.field_236);
      }
   }

   private static final int h() {
      return method_75() + E;
   }

   // $VF: renamed from: c () int
   public static final int method_70() {
      return field_197;
   }

   // $VF: renamed from: d () int
   public static final int method_75() {
      int var0 = field_197 + L;
      if (K >= 0) {
         var0 += class_5.method_20(K);
         var0 += 4;
      }

      return var0;
   }

   private static final int a(int var0, byte[][] var1) {
      int var2 = 0;
      int var3 = var1.length;

      for (int var4 = 0; var4 < var3; var4++) {
         byte[] var5 = var1[var4];
         int var6;
         int var7;
         if (a(var0, var5) && (var6 = a(var1[var4])) != -1 && (var7 = class_18.a(var6, class_18.field_236)) > var2) {
            var2 = var7;
         }
      }

      return var2;
   }

   private static final void l(int var0) {
      byte[][] var1;
      int var2 = (var1 = field_172[var0]).length;
      int var3 = method_86(var0);

      for (int var4 = 0; var4 < var2; var4++) {
         byte[] var5 = var1[var4];
         int var6 = 4;
         if (a(var3, var5)) {
            byte var7;
            if ((var7 = var1[0][2]) >= 0) {
               var6 = class_18.method_122(method_102(var7)) + 4;
            }

            String var8;
            class_5.a(var8 = class_5.a(a(var5)), var4, F - var6, class_18.field_236);
            var6 += class_18.a(var8, class_18.field_236);
         }

         field_179[var4] = var6;
      }
   }

   // $VF: renamed from: f () boolean
   private static final boolean method_71() {
      int var0;
      if ((var0 = class_18.method_112()) == 0) {
         return false;
      }

      switch (i) {
         case 1:
            byte var1 = -1;
            if (var0 == 131072 && field_183) {
               var1 = 4;
            }

            if (var0 == 262144 && field_184) {
               var1 = 5;
            }

            if (var0 == 524288 && field_184) {
               var1 = 5;
               if (method_86(k) == 2 && field_171[k][5] < 0) {
                  var1 = 4;
               }
            }

            byte var2;
            if (var1 != -1 && (var2 = field_171[k][var1]) >= 0) {
               method_79(class_18.field_238[var2][3]);
            }
            break;
         case 2:
            if (var0 == 131072 || var0 == 524288) {
               w();
            }

            if (var0 == 262144) {
               a(1, false);
            }
            break;
         default:
            return false;
      }

      return true;
   }

   private static final void k(int var0, int var1) {
      class_18.b();
      if (var0 == 2) {
         field_180 = false;
         J();
         field_178[14] = 0;
         field_183 = true;
         field_184 = true;
         d(true);
      } else if (var0 == 1) {
         if (i == 2) {
            if (class_19.a(var1)) {
               J();
            }

            d(false);
         }
      } else if (var0 == 0) {
         class_18.c(-1, -1);
      }

      class_18.field_240 = var0 == 2 || var0 == 0;
      i = var0;
   }

   private static final void d(boolean var0) {
      class_19.c(var0);
   }

   private static final void a(String var0, String var1, int var2, int var3) {
      class_5.b(315, var0);
      class_5.b(316, var1);
      field_171[34][4] = (byte)var2;
      field_171[34][5] = (byte)var3;
   }

   private static final void a(String var0, String var1, int var2, int var3, int var4) {
      a(var0, var1, var2, var3);
      l(34, var4);
   }

   private static final void d(int var0, int var1, int var2) {
      a(class_5.a(var0), class_5.a(var1), var2);
   }

   private static void a(String var0, String var1, int var2) {
      a(var0, var1, 5, -1, var2);
   }

   private static void l(int var0, int var1) {
      a(var0, false);
      method_93(var0, var1);
   }

   public static final void a(int var0, boolean var1) {
      class_18.b();
      K = -1;
      L = 0;
      if (var1) {
         if (method_86(k) != 2) {
            field_178[k] = (byte)l;
         }

         if (var0 != k) {
            method_93(var0, k);
         }
      } else {
         byte var2 = (byte)(k != var0 ? 0 : l);
         if (field_171[k][2] == 4) {
            var2 = 0;
         }

         field_178[k] = var2;
      }

      if (k == 30) {
         field_178[0] = 0;
      }

      boolean var6;
      if (var6 = var0 != k || i != 1) {
         ab = 5;
      }

      m(k, var0);
      if (i != 1) {
         k(1, var0);
      }

      boolean var3 = false;
      if (var0 == 0) {
         var3 = true;
      }

      field_185 = (byte[][])null;
      class_5.method_5(0);
      if (method_86(var0) == 2 || var0 == 49) {
         boolean var5 = var0 == 21 || var0 == 23 || var0 == 24 || var0 == 25 || var0 == 28;
         a(var0, field_219, F - class_18.a('X', class_18.field_236), var5);
      }

      l(var0);
      a(var0, field_178[var0], 1, var6);
      b(var0, false, false);
      n(var0);
      k = var0;
      if (var3 && !field_206) {
         c(false);
      }
   }

   public static final void c(int var0) {
      if (var0 != L) {
         L = var0;
         b(k, true, true);
      }
   }

   private static final void m(int var0, int var1) {
      if (a == null && var1 == 33 && class_5.field_54 != 5) {
         field_178[33] = (byte)class_5.field_54;
      }

      if (var1 == 38 && var1 != var0) {
         aa = -1;
         b(37, 1);
      }

      int var2 = method_86(var1);
      if (var0 == 15 && var1 == field_177[15]) {
         method_72();
      }

      if (field_169 && var1 == 15) {
         A();
      }

      if (field_212 != 0) {
         int var3;
         if ((var3 = class_5.a(584, field_212, 3)) > 0 && var1 == var3) {
            int var4 = class_5.a(584, field_212, 4);
            method_104(var3, var4);
         }

         if (var1 == -1) {
            class_5.a(37, String.valueOf(t));
         }

         if (var2 == 3) {
            x();
            x = 0;
            field_193 = method_82(22, 15);
            if (b() && field_195 != null) {
               field_193 = a(field_195, -1, 15);
            }

            if (class_5.a(584, field_212, 2) == 40) {
               field_194 = method_82(38, 10);
               if (method_69() && field_196 != null) {
                  field_194 = a(field_196, -1, 10);
               }
            }
         } else if (var0 == 40) {
            field_195 = field_193.toString();
            field_196 = field_194.toString();
         } else if (var0 == 41) {
            field_195 = field_193.toString();
         }

         if (var1 == 47) {
            class_5.a(32, class_5.a(V));
         }
      }

      d(var1);
      class_19.c(var1, var0);
   }

   public static final void d(int var0) {
      byte[][] var1;
      int var3 = (var1 = field_172[var0]).length;

      for (int var6 = 0; var6 < var3; var6++) {
         byte[] var2 = var1[var6];
         byte var7 = var2[6];
         int var8 = var2[4] & 255;
         int var5 = method_89(var7, var8) ? 1 : 0;
         var2[5] = (byte)var5;
      }
   }

   private static final void L() {
      class_5.a(43, String.valueOf(aa + 1), String.valueOf(class_5.c()));
   }

   private static final void m(int var0) {
      class_5.f(var0);
   }

   // $VF: renamed from: f () void
   public static final void method_72() {
      int var10000;
      int[] var10001;
      if (field_217) {
         System.arraycopy(field_202, 0, field_203, 0, 7);
         var10000 = 0;
         var10001 = field_203;
      } else {
         var10000 = 0;
         var10001 = field_202;
      }

      class_5.a(var10000, var10001);
      m(0);
   }

   // $VF: renamed from: b (int, int) boolean
   public static final boolean method_89(int var0, int var1) {
      switch (var0) {
         case -1:
         case 0:
            return true;
         case 1:
         case 3:
         default:
            if (var0 == 3) {
               if (field_177[15] == 0) {
                  return true;
               }

               return false;
            }

            return class_19.method_153(var0, var1);
         case 2:
            if (!field_217 && field_177[15] == 0) {
               return true;
            }

            return false;
         case 4:
            return var1 == -1 ? t > 0 : field_189[var1][0] != 0;
      }
   }

   // $VF: renamed from: a (int) boolean
   public static final boolean method_81(int var0) {
      if (var0 > t) {
         t = var0;
         u();
         return true;
      } else {
         return false;
      }
   }

   // $VF: renamed from: f (int, int) void
   public static final void method_104(int var0, int var1) {
      field_178[var0] = (byte)var1;
   }

   private static final void a(int var0, int var1, int var2, boolean var3) {
      byte[][] var4 = field_172[var0];
      int var5 = -1;
      if (!var3) {
         var5 = l;
      }

      int var6;
      if ((var6 = method_86(var0)) == 2) {
         var4 = field_185;
      }

      int var7 = var4.length;
      if (var0 == 49) {
         var7 = 5 + field_185.length;
      }

      boolean var8;
      label109: {
         boolean var10000 = var6 != 2 && var6 != 5 && (var1 < 0 || var1 >= var7);
         var8 = var6 != 2 && var6 != 5 && (var1 < 0 || var1 >= var7);
         int var12;
         if (var10000) {
            if (var1 < 0) {
               var1 = var7 - 1;
            }

            if (var1 < var7) {
               break label109;
            }

            var12 = 0;
         } else {
            if (var1 < 0) {
               var1 = 0;
            }

            if (var1 < var7) {
               break label109;
            }

            var12 = var7 - 1;
         }

         var1 = var12;
      }

      label99:
      if (var6 != 2 && var0 != 49 && var1 >= 0) {
         int var13;
         while (true) {
            if (var4[var1][5] != 0) {
               break label99;
            }

            if (var2 == 0) {
               var2 = 1;
            }

            if ((var1 += var2) < 0) {
               if (!var3) {
                  var13 = var5;
                  break;
               }

               var1 = 0;
               var2 = -var2;
            }

            if (var1 >= var7) {
               if (!var3) {
                  var13 = var5;
                  break;
               }

               var1 = 0;
               var2 = -var2;
            }
         }

         var1 = var13;
      }

      l = var1;
      if (var8 || var3) {
         b(var0, false, true);
      }

      if (var6 == 3) {
         x = l == 0 ? y : 2;
         class_5.b(287, class_5.a(288 + x));
         x();
         z = 0;
         A = a(a());
      } else {
         field_183 = true;
         field_184 = true;
         if (var0 == 33 && field_177[var0] != 15) {
            field_184 = false;
         }

         byte[] var9 = field_171[var0];
         byte var10 = field_183 ? var9[4] : -1;
         byte var11 = field_184 ? var9[5] : -1;
         class_18.c(var10, var11);
      }

      o(var0);
   }

   private static final void n(int var0) {
      int var1;
      if ((var1 = method_87(var0)) != -1) {
         int var2 = 2;
         byte var3;
         if ((var3 = field_171[var0][3]) >= 0) {
            var2 = 2 + class_5.method_15(var3) + 1;
         }

         int var4 = class_18.a(var1, class_18.field_235);
         a(field_201[0], var4, var2);
      } else {
         field_201[0][0] = 0;
      }
   }

   private static final void o(int var0) {
      int var1;
      if ((var1 = method_86(var0)) != 2 && var1 != 5) {
         int var2 = 4;
         byte var3;
         if ((var3 = field_172[var0][0][2]) >= 0) {
            var2 = 4 + class_18.method_122(method_102(var3));
         }

         a(field_201[1], field_179[l], var2);
      } else {
         field_201[1][0] = 0;
      }
   }

   private static final void a(int[] var0, int var1, int var2) {
      var0[0] = 0;
      if (var1 > F) {
         var0[0] = 1;
         var0[2] = var1 + 2 + 8 - var2 << 10;
         var0[3] = class_18.field_230 - 4 - var2 << 10;
         var0[4] = 20;
         var0[1] = var0[3];
         var0[5] = 1;
      }
   }

   public static final void a(String var0) {
      if (var0 != field_199) {
         G = 0;
         J = Integer.MAX_VALUE;
      }

      if (var0 != null) {
         I = class_18.a(var0, class_18.c);
         H = class_18.field_230 + I << 10;
         if (I > F) {
            J = 20;
         } else {
            G = 4;
         }

         G = class_18.field_230 - 4 << 10;
      }

      field_199 = var0;
   }

   // $VF: renamed from: e (int) void
   public static final void method_94(int var0) {
      field_204 = true;
      field_200 = class_5.a(var0);
      class_18.c(-1, -1);
      class_18.field_240 = true;
      M = 0;
      if (i == 2) {
         d(false);
      }

      class_18.c();

      try {
         Thread.sleep(50L);
      } catch (Exception var2) {
      }
   }

   private static final void M() {
      field_204 = false;
      field_200 = null;
      class_18.b();
      class_18.field_240 = i == 2;
      if (i == 2) {
         d(true);
      } else {
         method_76();
      }
   }

   // $VF: renamed from: g () void
   public static final void method_73() {
      field_204 = false;
      field_200 = null;
      class_18.field_240 = i == 2;
      class_18.b();
      if (i == 2) {
         d(true);
      }
   }

   private static final int a(int var0, String var1, Font var2, int var3) {
      int var4 = var0;
      int var5 = var1.length();
      if (var0 >= var5) {
         return -1;
      }

      int var6 = var0;

      while (true) {
         while (var4 < var5) {
            char var7;
            if ((var7 = var1.charAt(var4)) <= ' ' && var7 != 147) {
               if (var4 >= var5 - 1) {
                  break;
               }

               if ((var7 = var1.charAt(var4 + 1)) != '!' && var7 != '?' && var7 != ':' && var7 != 187) {
                  if (var4 <= 0 || var1.charAt(var4 - 1) != 171) {
                     break;
                  }

                  var4++;
               } else {
                  var4 += 2;
               }
            } else {
               var4++;
            }
         }

         int var9 = class_18.a(var1, var6, var4 - var6, var2);
         if (var0 == var6 && var9 > var3) {
            while (class_18.a(var1, var6, --var4 - var6, var2) >= var3) {
            }

            var0 = var4;
            break;
         }

         if (var9 <= var3) {
            var0 = var4;
         }

         if (var9 > var3 || var4 >= var5 || var1.charAt(var4) == '\n') {
            break;
         }

         var4++;
      }

      if (var0 < var5) {
         var0++;
      }

      return var0;
   }

   private static final void a(int var0, Font var1, int var2, boolean var3) {
      if (var3) {
         method_94(205);
      }

      System.gc();
      field_219 = var1;
      Vector var4 = new Vector(10, 2);
      byte[][] var5;
      int var6 = (var5 = field_172[var0]).length;
      int var7 = 0;

      for (int var9 = 0; var9 < var6; var9++) {
         int var10 = 0;
         String var11 = class_5.a(a(var5[var9]));

         int var12;
         while (var10 >= 0 && (var12 = a(var10, var11, var1, var2)) >= 0) {
            int var8;
            String var13;
            if ((var8 = (var13 = var11.substring(var10, var12).trim()).length()) > 0 || var7 > 0) {
               var4.addElement(var13.replace('\u0093', ' '));
            }

            var7 = var8;
            var10 = var12;
         }

         if (var7 > 0) {
            var4.addElement("");
            var7 = 0;
         }
      }

      byte[] var16;
      int var17 = (var16 = field_172[var0][0]).length;

      int var18;
      for (int var19 = (var18 = var4.size()) - 1; var19 >= 0; var19--) {
         if (((String)var4.elementAt(var19)).length() > 0) {
            var18 = var19 + 1;
            break;
         }
      }

      byte[][] var20 = new byte[var18][var17];
      class_5.method_5(var18);

      for (int var14 = 0; var14 < var18; var14++) {
         byte[] var21 = var20[var14];
         System.arraycopy(var16, 0, var21, 0, var17);
         int var15 = class_5.a((String)var4.elementAt(var14));
         a(var21, var15);
      }

      field_185 = var20;
      if (var3) {
         method_73();
      }
   }

   public static final void f(int var0) {
      ad = var0;
      ad += 120;
      class_18.c();
   }

   public static final void g(int var0) {
      ae = var0;
      if (class_5.method_4() > e(0) && f < 0) {
         h(0, 2000);
      }

      if ((var0 & 31) == 0) {
         class_18.c();
      }

      class_18.d();
   }

   // $VF: renamed from: h () void
   public static final void method_106() {
      m();
   }

   public static final void i() {
      field_170[0] = method_107("MIDlet-Name") + "";
      field_170[1] = method_107("MIDlet-Version") + "";
      a = method_107("UNITYFORCELANGUAGE");
      if (a == null) {
         a = method_107("UNITYLANGUAGE");
      }

      if (a != null && a.length() != 2) {
         a = null;
      }

      e = a("UNITYDEMOMODE", 0) != 0;
      if (!e) {
         String var0;
         if ((var0 = method_107("OPERATORCOMMUNITY")) != null && !"NONE".equals(var0) && a == null && !"IPC".equals(var0)) {
            a = "EN";
         }

         d = a("UNITYDEPLOYED", 0);
         field_215 = (d & 1) != 0;
         field_216 = (d & 2) != 0;
      }

      int var4 = class_18.field_230;
      int var1 = class_18.field_231;
      b = method_107("UNITYGAMECATALOGURL");
      field_168 = a("SOUNDDEFAULTOFF", 1) == 0;
      field_169 = a("SOUNDNOTPRESENT", 0) == 0;
      int var2 = a("FORCEDSCREENWIDTH", var4);
      int var3 = a("FORCEDSCREENHEIGHT", var1);
      class_18.a(var2, var3);
      class_18.field_241 = a("SOFTKEYSWAP", 0) != 0;
   }

   // $VF: renamed from: a (java.lang.String) java.lang.String
   public static final String method_107(String var0) {
      String var1;
      if ((var1 = class_3.a.getAppProperty(var0)) != null) {
         var1 = var1.trim();
      }

      return var1;
   }

   public static final int a(String var0, int var1) {
      String var2 = method_107(var0);
      int var3 = var1;
      if (var2 != null) {
         try {
            var3 = Integer.parseInt(var2);
         } catch (NumberFormatException var5) {
            byte var10000;
            if ("Y".equals(var2)) {
               var10000 = 1;
            } else {
               if (!"N".equals(var2)) {
                  return var3;
               }

               var10000 = 0;
            }

            var3 = var10000;
         }
      }

      return var3;
   }

   public static final void a(MIDlet var0) {
      field_209 = new class_10(var0);
      if (class_5.field_53 != null) {
         class_10.a(var0, class_5.field_53);
      }
   }

   public static final void j() {
      field_209.a();
   }

   private static void b(String var0) {
      field_202[49] = -1;
      a(class_5.a(265), var0, field_177[48]);
      M();
   }

   private static void N() {
      d(247, 267, field_177[48]);
      M();
   }

   private static void O() {
      if (class_10.field_141 > 0) {
         W = class_10.field_140;
         if (!a(class_10.field_142, class_10.field_143, class_10.field_144)) {
            P();
            return;
         }

         l(49, 44);
      } else {
         d(method_87(49), 278, 44);
      }

      method_73();
   }

   private static void P() {
      d(247, 266, 44);
      M();
   }

   private static void c(String var0) {
      field_193 = a(var0, 22, 15);
      method_72();
      if (j == 9) {
         method_73();
         m();
      }

      field_192 = true;
   }

   private static void p(int var0) {
      if (j == 9) {
         if (var0 == -40) {
            r();
            s();
            method_72();
         } else {
            field_218 = b();
         }

         method_73();
         m();
      } else {
         M();
      }
   }

   private static void Q() {
      a(47, true);
      M();
   }

   private static void R() {
      d(247, 266, 44);
      M();
   }

   private static void a(Vector var0) {
      int var1;
      short var10000;
      if ((var1 = var0.size()) > 0) {
         StringBuffer var3 = new StringBuffer();

         for (int var4 = 0; var4 < var1; var4++) {
            String var5 = (String)var0.elementAt(var4);
            if (var4 > 0) {
               var3.append(class_5.a(277));
            }

            var3.append(var5);
         }

         class_5.a(35, var3.toString());
         var10000 = 35;
      } else {
         var10000 = 276;
      }

      int var2 = var10000;
      a(class_5.a(271), class_5.a(var2), -1, 18, 44);
      M();
   }

   private static void S() {
      d(247, 266, 44);
      M();
   }

   private static void d(String var0) {
      field_193 = a(field_193.toString(), 22, 15);
      field_194 = a(field_194.toString(), 38, 10);
      method_72();
      m();
      a(class_5.a(279), var0, 253);
      M();
   }

   private static void a(int var0, String var1) {
      int var2 = class_5.a(584, field_212, 2);
      if (var0 == 0) {
         b(6, 39);
      } else {
         a(class_5.a(246), var1, -1, 18, var2);
      }

      M();
   }

   private static void q(int var0) {
      int var10000;
      switch (var0) {
         case 1:
            var10000 = 243;
            break;
         case 2:
            var10000 = 244;
            break;
         case 3:
            var10000 = 245;
            break;
         default:
            return;
      }

      method_94(var10000);
   }

   // $VF: renamed from: g (int, int) void
   public static final void method_100(int var0, int var1) {
      while (var1 >= 32) {
         var1 -= 32;
         var0--;
      }

      int var2 = a(var0) | 1 << var1;
      a(var0, var2);
   }

   // $VF: renamed from: c (int, int) boolean
   public static final boolean method_99(int var0, int var1) {
      while (var1 >= 32) {
         var1 -= 32;
         var0--;
      }

      return (a(var0) & 1 << var1) != 0;
   }

   // $VF: renamed from: e () int
   public static int method_77() {
      return i;
   }

   public final void a(int var1, int var2, int var3, String var4, Vector var5) {
      Q = var1;
      P = var2;
      R = var3;
      field_210 = var4;
      field_211 = var5;
   }

   // $VF: renamed from: h (int) void
   public final void method_105(int var1) {
      O = var1;
   }
}
