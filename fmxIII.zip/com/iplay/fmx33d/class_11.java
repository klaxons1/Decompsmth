package com.iplay.fmx33d;

import javax.microedition.lcdui.Font;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;

// $VF: renamed from: k
public final class class_11 {
   private static char[] a;
   // $VF: renamed from: a byte[]
   private static byte[] field_150;
   private static byte[] b;
   // $VF: renamed from: a byte[][]
   private static byte[][] field_151;

   public static void a() {
      if (a == null) {
         a = " !\"#$%&'()+,-./0123456789:;?@ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz¡£©ª«º»¿ÀÁÂÄÇÈÉÊËÌÍÎÏÑÒÓÔÖÙÚÛÜßàáâäçèéêëìíîïñòóôöùúûü“„€*½¼¾  \u0082\u200b\n \u00ad"
            .toCharArray();
      }

      field_150 = new byte[4];
      b = new byte[4];
      field_151 = new byte[4][];

      for (int var0 = 0; var0 < 4; var0++) {
         int var1 = class_5.a(6, var0, 0);
         int var2 = class_5.a(6, var0, 1);
         field_150[var0] = (byte)(class_5.method_15(var1) / 16);
         b[var0] = (byte)(class_5.method_20(var1) / 9);
         field_151[var0] = class_5.method_8(var2);
      }
   }

   private static final int a(char var0) {
      char[] var1 = a;

      for (int var2 = 0; var2 < var1.length; var2++) {
         if (var0 == var1[var2]) {
            return var2;
         }
      }

      return -1;
   }

   public static final int a(Font var0) {
      int var1 = b(var0);
      return b[var1];
   }

   public static final int a(Font var0, char var1) {
      byte var2;
      int var3;
      label18: {
         var2 = 0;
         byte var10000;
         if (var1 == 147) {
            var10000 = 0;
         } else {
            switch (var3 = a(var1)) {
               case 144:
               case 145:
               case 146:
               case 148:
                  var10000 = -1;
                  break;
               case 147:
               default:
                  break label18;
            }
         }

         var3 = var10000;
      }

      if (var3 != -1) {
         int var4 = b(var0);
         var2 = field_151[var4][var3];
      }

      return var2;
   }

   public static final int a(Font var0, String var1) {
      return a(var0, var1, 0, var1.length());
   }

   public static final int a(Font var0, String var1, int var2, int var3) {
      int var4 = 0;
      int var5 = var1.length();
      int var6;
      if ((var6 = var2 + var3) > var5) {
         var6 = var5;
      }

      for (int var7 = var2; var7 < var6; var7++) {
         char var8 = var1.charAt(var7);
         int var9;
         if ((var9 = a(var0, var8)) > 0) {
            var4 += var9;
         }
      }

      return var4;
   }

   public static void a(Graphics var0, Font var1, int var2, String var3, int var4, int var5, int var6) {
      a(var0, var1, var2, var3, var4, var5, 0, 0, var3.length(), var6);
   }

   private static void a(Graphics var0, Font var1, int var2, String var3, int var4, int var5, int var6, int var7, int var8, int var9) {
      label60:
      if (var9 != 0) {
         label58: {
            int var10000;
            int var10001;
            if ((var9 & 1) != 0) {
               var10000 = var4;
               var10001 = a(var1, var3) >> 1;
            } else {
               if ((var9 & 8) == 0) {
                  break label58;
               }

               var10000 = var4;
               var10001 = a(var1, var3);
            }

            var4 = var10000 - var10001;
         }

         int var21;
         int var23;
         if ((var9 & 32) != 0) {
            var21 = var5;
            var23 = a(var1);
         } else {
            if ((var9 & 64) == 0) {
               break label60;
            }

            var21 = var5;
            var23 = a(var1) - 2;
         }

         var5 = var21 - var23;
      }

      int var10 = a(var1, var2);
      Image var11 = class_5.method_6(class_5.a(6, var10, 0));
      byte var12 = field_150[var10];
      byte var13 = b[var10];
      byte[] var14 = field_151[var10];
      if (var8 > var3.length()) {
         var8 = var3.length();
      }

      class_18.b(var0);

      for (int var15 = var7; var15 < var8; var15++) {
         int var17;
         label44: {
            char var16;
            byte var22;
            if ((var16 = var3.charAt(var15)) == 147) {
               var22 = 0;
            } else {
               switch (var17 = a(var16)) {
                  case 144:
                  case 145:
                  case 146:
                  case 148:
                     var22 = -1;
                     break;
                  case 147:
                  default:
                     break label44;
               }
            }

            var17 = var22;
         }

         byte var18;
         if (var17 != -1 && (var18 = var14[var17]) > 0) {
            int var19 = var17 & 15;
            int var20 = var17 >> 4;
            if (class_18.a(var0, var4, var5, var12, var13)) {
               var0.drawImage(var11, var4 - var19 * var12, var5 - var20 * var13, 20);
            }

            var4 += var18 + var6;
         }
      }

      class_18.c(var0);
   }

   private static final int b(Font var0) {
      int var1;
      if ((var1 = var0.getSize()) == 0) {
         var1++;
      }

      for (int var2 = 0; var2 < 4; var2++) {
         int var3 = class_5.a(6, var2, 2);
         if ((var1 & var3) != 0) {
            return var2;
         }
      }

      return 0;
   }

   private static final int a(Font var0, int var1) {
      int var2;
      if ((var2 = var0.getSize()) == 0) {
         var2++;
      }

      for (int var3 = 0; var3 < 4; var3++) {
         if (class_5.a(6, var3, 3) == var1) {
            int var5 = class_5.a(6, var3, 2);
            if ((var2 & var5) != 0) {
               return var3;
            }
         }
      }

      return b(var0);
   }
}
